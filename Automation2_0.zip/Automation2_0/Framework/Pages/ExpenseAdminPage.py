from Framework.Utilities.Driver import Driver
from Framework.Utilities.Environment import Environment


class ExpenseAdminPage:

    def __init__(self):
        pass

    @classmethod
    def is_at(cls):
        return Driver.wait_for_element_visible(Locators.left_logo)

    @classmethod
    def navigate_to(cls):
        Driver.navigate_to_url(Environment.get_osc_url() + "/ExpenseAdmin/")
        return cls.is_at()

    @classmethod
    def enable_expense_reporting(cls, entity, email, settings_dict, tpa="Other"):
        if not cls.is_at():
            print("\nERROR: Not at the ExpenseAdmin tool page")
            return False

        if not Driver.wait_for_element_visible(Locators.select_entity_text):
            print("\nERROR: Unable to find the select client-entity text box")
            return False
        Driver.enter_text(Locators.select_entity_text, entity)

        if not Driver.alt_wait_for_element(Locators.select_results):
            print("\nERROR: No results returned for " + entity)
            return False
        Driver.click(Locators.select_results)

        if not Driver.wait_for_element_visible(Locators.enable_expense_chk):
            print("\nERROR: Enable expense reporting checkbox not found")
            return False

        if not Driver.wait_for_element_not_visible(Locators.pending_overlay):
            print("\nERROR: Entity is still pending")
            return False

        Driver.set_checkbox(Locators.enable_expense_chk, True)

        if not Driver.wait_for_element_visible(Locators.email_text):
            print("\nERROR: Entity expense settings section not found")
            return False

        if Driver.wait_for_element_visible(Locators.disabled_email_text, wait=1):
            print("\nWARNING: Email address field is already set and disabled")
        else:
            Driver.enter_text(Locators.email_text, email)

        Driver.set_checkbox(Locators.approval_process_chk, settings_dict["Approval_Process"])
        Driver.set_checkbox(Locators.roles_chk, settings_dict["Roles"])
        Driver.set_checkbox(Locators.tax_profiles_chk, settings_dict["Tax_Profiles"])
        Driver.set_checkbox(Locators.expense_types_chk, settings_dict["Expense_Types"])
        Driver.set_checkbox(Locators.branding_chk, settings_dict["Branding"])
        Driver.set_checkbox(Locators.expense_currencies_chk, settings_dict["Expense_Currencies"])

        # Driver.set_checkbox(Locators.intacct_chk, intacct)

        Driver.select_dropdown_option(Locators.tpa_dropdown, tpa)

        Driver.click(Locators.save_button)

        if not Driver.wait_for_element_visible(Locators.success_toast):
            print("\nERROR: Success message has not appeared")
            return False
        if not Driver.wait_for_element_not_visible(Locators.success_toast):
            print("\nERROR: Success message has not disappeared")
            return False

        return True

    @classmethod
    def disable_expense_reporting(cls, entity):
        if not cls.is_at():
            print("\nERROR: Not at the ExpenseAdmin tool page")
            return False

        if not Driver.wait_for_element_visible(Locators.select_entity_text):
            print("\nERROR: Unable to find the select client-entity text box")
            return False
        Driver.enter_text(Locators.select_entity_text, entity)

        if not Driver.alt_wait_for_element(Locators.select_results):
            print("\nERROR: No results returned for " + entity)
            return False
        Driver.click(Locators.select_results)

        if not Driver.wait_for_element_visible(Locators.enable_expense_chk):
            print("\nERROR: Enable expense reporting checkbox not found")
            return False

        if not Driver.wait_for_element_not_visible(Locators.pending_overlay):
            print("\nERROR: Entity is still pending")
            return False

        Driver.set_checkbox(Locators.enable_expense_chk, False)

        if not Driver.wait_for_element_not_visible(Locators.email_text):
            print("\nERROR: Entity expense settings section is still seen")
            return False
        Driver.click(Locators.save_button)

        if not Driver.wait_for_element_visible(Locators.success_toast):
            print("\nERROR: Success message has not appeared")
            return False
        if not Driver.wait_for_element_not_visible(Locators.success_toast):
            print("\nERROR: Success message has not disappeared")
            return False

        return True


class Locators:

    def __init__(self):
        pass

    left_logo = """img[alt="ExpenseAdmin Tool"]"""
    expense_tab = "div.btn-group > button:nth-of-type(1)"
    select_entity_text = "input#typeahead"
    select_results = "ul.dropdown-menu li a"

    enable_expense_chk = "input#enable-expense-reporting"
    email_text = "input#distribution-list-email-address"
    disabled_email_text = "input#distribution-list-email-address.input_disabled"
    approval_process_chk = "input#hasCustomApprovalProcess"
    expense_types_chk = "input#hasCustomExpenseTypes"
    roles_chk = "input#hasCustomRoles"
    branding_chk = "input#hasCustomBranding"
    tax_profiles_chk = "input#hasCustomTaxProfiles"
    expense_currencies_chk = "input#hasCustomExpenseCurrencies"

    # intacct_chk = "input#intacct-enabled"
    tpa_dropdown = "select#accounting-system"

    save_button = """button[submit-callback="save()"]"""

    success_toast = "div.toast.toast-success"

    pending_overlay = "div.overlap"
