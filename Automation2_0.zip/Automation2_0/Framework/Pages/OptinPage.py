from Framework.Utilities.Driver import Driver
from Framework.Utilities.Environment import Environment
from Framework.Utilities.DatabaseManager import DatabaseManager


class OptinPage:

    def __init__(self):
        pass

    @classmethod
    def is_at(cls):
        return Driver.wait_for_element_visible(OptinPageLocators.toc_submit_button)

    @classmethod
    def go_to(cls, optin_key):
        Driver.navigate_to_url(Environment.get_optin_url(optin_key))
        if not cls.is_at():
            return Driver.error("Unable to go to Optin page")

    @classmethod
    def optin_as(cls, username, password):
        # Query to grab the optin key
        db_name = "Identity%s" % Environment.get_db_env()
        query = """
            select u.OptinKey from SecurityAccount sa
            INNER JOIN [User] u
            on sa.Id = u.Id
            where sa.Name = '%s';
            """ % username
        fetchall = DatabaseManager.fetchall_query(query, db_name)

        # Goto optin url
        cls.go_to(fetchall[0][0])

        # Accept ToC and continue to password set
        if not Driver.click(OptinPageLocators.toc_accept_chk):
            return Driver.error("Unable to click the accept toc checkbox")
        if not Driver.click(OptinPageLocators.toc_submit_button):
            return Driver.error("Unable to click the submit button")

        # Enter new password and save it
        if not Driver.enter_text(OptinPageLocators.password_text, password):
            return Driver.error("Unable to enter text into the password field")
        if not Driver.enter_text(OptinPageLocators.password_confirm_text, password):
            return Driver.error("Unable to enter text into the confirm password field")

        if not Driver.click(OptinPageLocators.set_password_button):
            return Driver.error("Unable to click the set password button")

        return Driver.wait_for_element_visible(OptinPageLocators.password_success_link)


class OptinPageLocators:

    def __init__(self):
        pass

    toc_accept_chk = "input.checkbox"
    toc_submit_button = """button[ng-click="acceptTermsAndConditions()"]"""

    password_text = """input[ng-model="model.password"]"""
    password_confirm_text = """input[ng-model="model.passwordConfirm"]"""
    set_password_button = """button[ng-click="setPassword()"]"""
    # password_success_link = "a"
    password_success_link = "div.left:nth-of-type(3) a"
