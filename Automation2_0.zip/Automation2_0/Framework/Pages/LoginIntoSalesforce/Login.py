from selenium.webdriver.common.by import By

from Framework.Utilities.Driver import Driver

class LoginInToSalesforce():

    @classmethod
    def login_Into_Salesforce(cls, Profile):
        #Driver.maximize()
        if not Driver.enter_text(Locators.User_Name, Profile["Username"], by=By.ID):
            return Driver.error("\nError: Unable to enter text in Username field")
        if not Driver.enter_text(Locators.Password, Profile["Password"], by=By.ID):
            return Driver.error("\nError: Unable to enter text in Password field")
        if not Driver.click(Locators.Login, by=By.ID):
            return Driver.error("\nError: Click on Login button")


        #If Reminder is present then click
        if Driver.wait_for_element_present(Locators.Reminder_Click, by=By.XPATH, wait=5):
            Driver.click(Locators.Reminder_Click, by=By.XPATH)

        return True


class Locators:

    def __init__(self):
        pass
    User_Name="username"
    Password="password"
    Login="Login"
    Reminder_Click="//a[text()='Remind Me Later']"


