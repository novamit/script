from Framework.Utilities.Environment import Environment
from Framework.Utilities.Driver import Driver
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
import subprocess


class LoginPage:
    username = ""
    password = ""

    def __init__(self):
        pass

    @classmethod
    def is_at(cls):
        return Driver.wait_for_element_visible(Locators.username_field)

    @classmethod
    def go_to(cls, user_type="external", username=None, password=None, alt_user=False):
        if username is not None:
            cls.username = username
        if password is not None:
            cls.password = password

        if user_type == "external":
            Driver.navigate_to_url(Environment.get_osc_url() + "/web/forcests/")
            if not cls.is_at():
                return Driver.error("Unable to navigate to the external login page")
            return True
        else:
            if alt_user:
                subprocess.call('cmdkey.exe /add:adfs.hsp.com /user:%s /pass:%s' % (cls.username, cls.password))
                subprocess.call('cmdkey.exe /add:adfs.nairco.loc /user:%s /pass:%s' % (cls.username, cls.password))

            Driver.navigate_to_url(Environment.get_osc_url() + "/web/forceadfs/")
            
            if not OsCDashboardPage.is_at_dashboard():
                return Driver.error("Unable to navigate to the OsC dashboard page")
            return True

    @classmethod
    def login_as(cls, username):
        cls.username = username
        return cls

    @classmethod
    def with_password(cls, password):
        cls.password = password
        return cls

    @classmethod
    def login(cls, username=None, password=None):
        if username is None:
            username = cls.username
        if password is None:
            password = cls.password

        # Enter Username in text
        for x in range(0, 3):
            if not Driver.click(Locators.username_field):
                return Driver.error("Unable to access the username field")
            Driver.hard_wait(1)
            if not Driver.enter_text(Locators.username_field, username):
                return Driver.error("Unable to enter text into the username field")

            # Enter Password in text field
            if not Driver.enter_text(Locators.password_field, password):
                continue

            # Click Login button
            if not Driver.click(Locators.login_button, wait=10):
                return Driver.error("Unable to click the login button")

            if not Driver.wait_for_element_not_visible(Locators.login_button, wait=5):
                continue
            else:
                break

        return Driver.wait_for_element_not_visible(Locators.login_button)

    @classmethod
    def set_security_question(cls, answer="Vistra"):

        if not Driver.click(Locators.select_question):
            return Driver.error("Unable to click the select questions dropdown")

        if not Driver.click(Locators.select_question_option):
            return Driver.error("Unable to click the question option")

        if not Driver.enter_text(Locators.answer_text, answer):
            return Driver.error("Unable to enter text into the answer field")

        if not Driver.click(Locators.question_submit_button):
            return Driver.error("Unable to click the submit button")
        
        return Driver.wait_for_element_not_visible(Locators.question_submit_button)


class Locators:

    def __init__(self):
        pass

    username_field = "input#username"
    password_field = "input#password"
    login_button = ".left > button"

    select_question = "div.challenge-form > select"
    select_question_option = "div.challenge-form > select option:nth-child(2)"
    answer_text = "div.challenge-form > input"
    question_submit_button = """button[ng-click="submitAnswer()"]"""
    pg_not_found = "div#login h1"
