import time
from _ast import Global
import time
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from Framework.Utilities.Driver import Driver
import time


class CreateAccountScreen():

    @classmethod
    def select_recordtype_create_account(cls, create_account_details):
        if Driver.wait_for_element_present(Locators.Account_Tab, by=By.XPATH, wait=5):
            Driver.press_Return(Locators.Account_Tab, by=By.XPATH)

        if not Driver.click(Locators.New_Button, by=By.XPATH):
            return Driver.error("\nError: Click on New button")

        if create_account_details["Record_Type"].lower() == "affiliates":
            CreateAccountScreen.Create_Account_Affiliates(create_account_details)


        elif create_account_details["Record_Type"].lower() == "client/prospect":
            if not Driver.click(Locators.ClientProspectRadio, by=By.XPATH):
                return Driver.error("\nError: Selecting Record Type button")
            if not CreateAccountScreen.Create_Account_ClientProspect(create_account_details):
                #Driver.click(Locators.Account_Name, by=By.XPATH)
                Driver.click(Locators.Save_Button, by=By.XPATH)
                time.sleep(1)
                #Driver.action_pageup()
                #time.sleep(1)
                return Driver.error("\nError: Error occured in Account Creation")


        elif create_account_details["Record_Type"].lower() == "company formation":
            if not Driver.click(Locators.CompFormRadio, by=By.XPATH):
                return Driver.error("\nError: Selecting Record Type button")

        elif create_account_details["Record_Type"].lower() == "intermediaries/partners":
            if not Driver.click(Locators.InterM_Partners, by=By.XPATH):
                return Driver.error("\nError: Selecting Record Type button")

        return True

    @classmethod
    def Account_Created_Successfully(cls, create_account_details):
        Account_Name_Element = "//span[text()='"+create_account_details["Account_Name"]+"']"
        #"+create_account_details["Account_Name"]+"
        if Account_Name_Element is not None:
            pass

        return Driver.wait_for_element_present(Account_Name_Element, by=By.XPATH)

    @classmethod
    def Create_Account_Affiliates(cls, create_account_details):

        # if not Driver.click(Locators.ClientProspectRadio, by=By.XPATH):
        #     return Driver.error("\nError: Click on Client/Prospect button")
        # time.sleep(10)
        if not Driver.click(Locators.Affiliates, by=By.XPATH):
            return Driver.error("\nError: Unable to Click Affiliates")

        if not Driver.click(Locators.Next_Button, by=By.XPATH):
            return Driver.error("\nError: Click on Next button")

        if not Driver.enter_text(Locators.Account_Name, create_account_details["Account_Name"], by=By.XPATH):
            return Driver.error("\nError: Unable to enter text in Account Name field")



        if not Driver.click(Locators.Sector, by=By.XPATH):
            return Driver.error("\nError: Click on Sector button")

        if not Driver.select_dropdown_option(Locators.Options_Sector, create_account_details["Sector"], by=By.XPATH):
            return Driver.error("\nError: Select the Sector dropdown")

        if not Driver.click(Locators.Industry, by=By.XPATH):
            return Driver.error("\nError: Click on Industry")

        if not Driver.select_dropdown_option(Locators.Options_Industry, create_account_details["Industry"], by=By.XPATH):
            return Driver.error("\nError: Select the Industry dropdown")


        if not Driver.click(Locators.Account_Type, by=By.XPATH):
             return Driver.error("\nError: Click on Account Type")

        if not Driver.select_dropdown_option(Locators.Options_Account_Type, create_account_details["Account_Type"], by=By.XPATH):
            return Driver.error("\nError: Select the Account Type dropdown")


        #Driver.take_screenshot("C:\\temp_automation_downloads\\NewAccountSS1.png")


        if not Driver.enter_text(Locators.Phone_Number, create_account_details["Phone_Number"], by=By.XPATH):
            return Driver.error("\nError: Unable to enter text in Account Name field")
        #Driver.take_screenshot("C:\\temp_automation_downloads\\JSON.png")
        # Entering Account Source
        # AccountSource=driver.find_element(By.XPATH, "//*[contains(@id,'511')]/div/div/a")
        # AccountSource.click()
        # SelectAccountSource = driver.find_element(By.XPATH, "//a[@title='Website']")
        # SelectAccountSource.click()
        if not Driver.click(Locators.Country_Affiliates, by=By.XPATH):
            return Driver.error("\nError: Click on Country")
        time.sleep(2)
        if not Driver.select_dropdown_option(Locators.Options_CountryAff, create_account_details["Country"], by=By.XPATH,wait=2):
            return Driver.error("\nError: Selecting the Country")

        if not Driver.click(Locators.Save_Button, by=By.XPATH):
            return Driver.error("\nError: Click on Save button")

    @classmethod
    def Create_Account_ClientProspect(cls, create_account_details):
        # if not Driver.click(Locators.ClientProspectRadio, by=By.XPATH):
        #     return Driver.error("\nError: Click on Client/Prospect button")
        # time.sleep(10)
        if not Driver.click(Locators.Next_Button, by=By.XPATH):
            return Driver.error("\nError: Click on Next button")

        if not Driver.enter_text(Locators.Account_Name, create_account_details["Account_Name"], by=By.XPATH):
            return Driver.error("\nError: Unable to enter text in Account Name field")

        if not Driver.click(Locators.Sector, by=By.XPATH):
            return Driver.error("\nError: Click on Sector button")

        if not Driver.select_dropdown_option(Locators.Options_Sector, create_account_details["Sector"], by=By.XPATH):
            return Driver.error("\nError: Select the Sector dropdown")

        if not Driver.click(Locators.Industry, by=By.XPATH):
            return Driver.error("\nError: Click on Industry")

        if not Driver.select_dropdown_option(Locators.Options_Industry, create_account_details["Industry"],
                                             by=By.XPATH):
            return Driver.error("\nError: Select the Industry dropdown")

        if not Driver.click(Locators.Account_Type, by=By.XPATH):
            return Driver.error("\nError: Click on Account Type")

        if not Driver.select_dropdown_option(Locators.Options_Account_Type, create_account_details["Account_Type"],
                                             by=By.XPATH):
            return Driver.error("\nError: Select the Account Type dropdown")

        #Driver.take_screenshot("C:\\temp_automation_downloads\\NewAccountSS1.png")

        if not Driver.enter_text(Locators.Phone_Number, create_account_details["Phone_Number"], by=By.XPATH):
            return Driver.error("\nError: Unable to enter text in Account Name field")
        #Driver.take_screenshot("C:\\temp_automation_downloads\\JSON.png")
        time.sleep(2)
        if not Driver.click(Locators.Account_Source, by=By.XPATH):
            return Driver.error("\nError: Click on Account Source")
        if not Driver.select_dropdown_option(Locators.Options_Account_Source, create_account_details["Account_Source"],
                                             by=By.XPATH):
            return Driver.error("\nError: Selecting the Account Source")


        if not Driver.click(Locators.Country_Client, by=By.XPATH):
            return Driver.error("\nError: Click on Country")
        

        if not Driver.select_dropdown_option(Locators.Options_Country_Client, create_account_details["Country"], by=By.XPATH,wait=1):
           return Driver.error("\nError: Selecting the Country")


        if not Driver.click(Locators.Save_Button, by=By.XPATH):
            return Driver.error("\nError: Click on Save button")

        return True

    @classmethod
    def Verifying_Internal_Error(cls):
        if Driver.wait_for_element_present(Locators.MainPage_error, by=By.XPATH):
            return Driver.error("\nError: Verifying main error in page")

        #if not Driver.wait_for_element_present(Locators.Internal_Referral_Source_Field_Error, by=By.XPATH):
        #    return Driver.error("\nError: Verifying field error in page")
        #Driver.take_screenshot("C:\\temp_automation_downloads\\VerifyingInternalReferralSourceError\\MainErrorSuccess.png")
        #Driver.scroll_element_into_view(Locators.Internal_Referral_Source, by=By.XPATH)
        #Driver.take_screenshot("C:\\temp_automation_downloads\\VerifyingInternalReferralSourceError\\FieldErrorSuccess.png")


        return True



class Locators:

    def __init__(self):
        pass

    Affiliates="//span[contains(text(),'Affiliates')]"
    ClientProspectRadio="//span[contains(text(),'Client/Prospect')]"
    CompFormRadio="//span[contains(text(),'Company Formation')]"
    InterM_Partners="//span[contains(text(), 'Intermediaries/Partners')]"

    Account_Tab = "//a[@title='Accounts']"
    #Options_Sector="//a[@title='Capital Market']"
    New_Button = "//div[text()='New']"
    Next_Button = "//button[@class='slds-button slds-button--neutral slds-button slds-button_brand uiButton']"
    Account_Name = "//input[contains(@id,'11')]"
    Sector = "//*[contains(@id,'317')]/div/div/a"
    Options_Sector="//*[contains(@id,'338')]/div/ul/li"
    Industry="//*[contains(@id,'394')]/div/div/a"
    Options_Industry="//*[contains(@id,'415')]/div/ul/li"
    #Environmental/Clean Technology, Agriculture
    Account_Type="//*[contains(@id,'171')]/div/div/a"
    Options_Account_Type="//*[contains(@id,'192')]/div/ul/li"
    Phone_Number = "//input[contains(@id,'290')]"
    Account_Source = "//h3/span[contains(text(),'Source')]/../../div/div/div/div/div/div/div/div/div/div/div/a"
    Options_Account_Source="//*[contains(@id,'598')]/div/ul/li"
    #e.g=Website, CSD Referral, Intermediaries Referral
    Internal_Referral_Source="//*[contains(@id,'562')]"
    External_Referral_Source="//*[contains(@id,'698')]"
    Country_Affiliates = "//span[contains(text(),'Billing Country')]/../../div/div/div/div/a"
    Options_CountryAff="//*[contains(@id,'783')]/div/ul/li"
    Country_Client="//span[contains(text(),'Billing Country')]/../../div/div/div/div/a"
    Options_Country_Client="//*[contains(@id,'175156')]/div/ul/li"
    Save_Button = "//button[@title='Save']"
    #Account_Name_Element = "//span[text()='SeleniumAccount']"
    MainPage_error="//span[text()='Review the errors on this page.']"
    Internal_Referral_Source_Field_Error="//*[text()='An Internal Referral Source " \
                                   "must be selected when Account Source is CSD Referral.']"
    External_Referral_Source_Field_Error="//*[text()='An External Referral Source " \
                                         "must be selected when the Account Source is Intermediaries Referral']"
    scrollable_element='//div[@class="modal-body scrollable slds-modal__content slds-p-around--medium"]'
    newaccount_pop='//h2[text()="New Account: Client/Prospect"]'



