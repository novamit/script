from Framework.Utilities.Driver import Driver
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Utilities.Environment import Environment
from Framework.Utilities.DatabaseManager import DatabaseManager


# This class holds a series of functions that can do some of the heavy lifting for grabbing user information
class UserHelper:
    
    def __init__(self):
        self.env_array = dict()
        self.osc_navigation = OsCNavigation()

    def get_user_current_entity_app_tabs(self, user_data):
        user_app_tabs = []
        wildcard = user_data["Roles_Info"]["Wildcard_Choice"]
        username = user_data["User_Info"]["Username"]

        if wildcard == "AllRolesAllEntities":
            user_app_tabs.append(self.osc_navigation.APP_PAYROLL)
            user_app_tabs.append(self.osc_navigation.APP_EXPENSES)
            user_app_tabs.append(self.osc_navigation.APP_CASH_MGMT)
            user_app_tabs.append(self.osc_navigation.APP_COMPLIANCE)
            user_app_tabs.append(self.osc_navigation.APP_HR)
            user_app_tabs.append(self.osc_navigation.APP_ADVISORY)
            user_app_tabs.append(self.osc_navigation.APP_SETUP_AND_ADMIN)
            user_app_tabs.append(self.osc_navigation.APP_FINANCIALS)
        else:
            user_entity_permissions = self.get_user_permissions_for_current_entity(username)

            for permission in user_entity_permissions:
                permission_structure = []
                if permission["ParentName4"] is not None:
                    permission_structure.append(permission["ParentName4"])
                if permission["ParentName3"] is not None:
                    permission_structure.append(permission["ParentName3"])
                if permission["ParentName2"] is not None:
                    permission_structure.append(permission["ParentName2"])
                if permission["ParentName1"] is not None:
                    permission_structure.append(permission["ParentName1"])
                if permission["Name"] is not None:
                    permission_structure.append(permission["Name"])

                for name in permission_structure:
                    if name == "Payroll" and self.osc_navigation.APP_PAYROLL not in user_app_tabs:
                        user_app_tabs.append(self.osc_navigation.APP_PAYROLL)
                        break
                    elif name == "Expenses" and self.osc_navigation.APP_EXPENSES not in user_app_tabs:
                        user_app_tabs.append(self.osc_navigation.APP_EXPENSES)
                        break
                    elif name == "Cash Management" and self.osc_navigation.APP_CASH_MGMT not in user_app_tabs:
                        user_app_tabs.append(self.osc_navigation.APP_CASH_MGMT)
                        break
                    elif name == "Compliance" and self.osc_navigation.APP_COMPLIANCE not in user_app_tabs:
                        user_app_tabs.append(self.osc_navigation.APP_COMPLIANCE)
                        break
                    elif name == "HR" and self.osc_navigation.APP_HR not in user_app_tabs:
                        user_app_tabs.append(self.osc_navigation.APP_HR)
                        break
                    elif name == "Advisory" and self.osc_navigation.APP_ADVISORY not in user_app_tabs:
                        user_app_tabs.append(self.osc_navigation.APP_ADVISORY)
                        break
                    elif name == "Country Entities" and self.osc_navigation.APP_SETUP_AND_ADMIN not in user_app_tabs:
                        user_app_tabs.append(self.osc_navigation.APP_SETUP_AND_ADMIN)
                        break
                    elif name == "Financials" and self.osc_navigation.APP_FINANCIALS not in user_app_tabs:
                        user_app_tabs.append(self.osc_navigation.APP_FINANCIALS)
                        break
        return user_app_tabs

    def get_user_permissions_for_current_entity(self, username):

        all_entity_permissions = []
        split_url = Driver.return_current_url().split("/")
        db_env_string = Environment.get_db_env()

        # If the url has more than 6 sections then we should be on an entity
        if 'entity' in split_url:
            n = 1
            for item in split_url:
                if 'entity' in item:
                    break
                n += 1
            entity_id = split_url[n]
        else:
            entity_id = 0

        # First part grabs the permission name and then the names of their parents up the tree
        # entity_id == 0 used to indicate global
        db_name = "Identity%s" % db_env_string
        query = """Select Id
                    From SecurityAccount
                    Where Name like '%s'""" % username
        user_id = DatabaseManager.fetchall_query(query, db_name)[0][0]

        db_name = "Authorization%s" % db_env_string
        if entity_id == 0:
            query = """select pa1.Id, pa1.Name, pa2.Name AS ParentName1, pa3.Name AS ParentName2,
                pa4.Name As ParentName3, pa5.Name As ParentName4
                from PermissionAction AS pa1
                LEFT OUTER JOIN PermissionAction AS pa2 ON pa1.PermissionActionParentId=pa2.Id
                LEFT OUTER JOIN PermissionAction AS pa3 ON pa2.PermissionActionParentId=pa3.Id
                LEFT OUTER JOIN PermissionAction AS pa4 ON pa3.PermissionActionParentId=pa4.Id
                LEFT OUTER JOIN PermissionAction AS pa5 ON pa4.PermissionActionParentId=pa5.Id
                Where pa1.Id in
                (select PermissionActionId from SecurityRolePermissionAction where SecurityRoleId in
                (select Id from SecurityRole where id in
                (select SecurityRoleId from SecurityAccountRole where SecurityAccountId = %s)))
                """ % user_id
        else:
            # Where clause filters by the permissions granted by the roles that user has for an entity or wildcard role
            query = """select pa1.Id, pa1.Name, pa2.Name AS ParentName1, pa3.Name AS ParentName2,
                pa4.Name As ParentName3, pa5.Name As ParentName4
                from PermissionAction AS pa1
                LEFT OUTER JOIN PermissionAction AS pa2 ON pa1.PermissionActionParentId=pa2.Id
                LEFT OUTER JOIN PermissionAction AS pa3 ON pa2.PermissionActionParentId=pa3.Id
                LEFT OUTER JOIN PermissionAction AS pa4 ON pa3.PermissionActionParentId=pa4.Id
                LEFT OUTER JOIN PermissionAction AS pa5 ON pa4.PermissionActionParentId=pa5.Id
                Where pa1.Id in
                (select PermissionActionId from SecurityRolePermissionAction where SecurityRoleId in
                (select Id from SecurityRole where id in
                (select SecurityRoleId from SecurityAccountRole where SecurityAccountId = %s
                AND(CompanyEntityId=%s OR IsCompanyEntityWildcard=1))))
                """ % (user_id, entity_id)

        entity_permission_results = DatabaseManager.fetchall_query(query, db_name)
        if not entity_permission_results:
            raise Exception("No results returned from query")
        else:
            for entity_permission in entity_permission_results:
                temp_permission = dict()
                temp_permission["Id"] = entity_permission[0]
                temp_permission["Name"] = entity_permission[1]
                temp_permission["ParentName1"] = entity_permission[2]
                temp_permission["ParentName2"] = entity_permission[3]
                temp_permission["ParentName3"] = entity_permission[4]
                temp_permission["ParentName4"] = entity_permission[5]

                all_entity_permissions.append(temp_permission)

            return all_entity_permissions

    # Returns a list of the entity tabs that a user should see based off of the roles they have set
    def return_user_entity_tabs_from_roles_info(self, roles_info):

        entities = []
        all_db_entities = []

        n = 1
        split_url = Driver.return_current_url().split("/")
        for item in split_url:
            if 'company' in item:
                break
            n += 1
        company_id = split_url[n]

        # Pulls the list of entities the user should have access to
        # If diff roles and entities then we need to loop through each entity and grab its DB data
        if roles_info["Wildcard_Choice"] == "DiffRolesDiffEntities":
            entities = list(roles_info["Entity_Roles"].keys())

            t = dict()

            if "Company Applicable Roles" in entities:
                entities.remove("Company Applicable Roles")
            for entity in entities:
                # Ignore Global Documents for now
                if entity == 'Global Documents':
                    continue

                temp_entity = self.osc_navigation.get_company_entities_from_db(company_id, entity)
                all_db_entities.append(temp_entity[0])

            if "Global Documents" not in entities and len(entities) > 1:
                entities.append('Global Documents')

        # If same role for all entities we need to handle the all entities section
        elif roles_info["Wildcard_Choice"] == "SameRolesAllEntities":
            entities = list(roles_info["Entity_Roles"].keys())

            if "All Entities" in entities:  # If All Entities is used
                entities.remove("All Entities")
                if "Global Documents" not in entities:  # We should see the global tab if we use all entities
                    entities.append('Global Documents')

                all_db_entities = self.osc_navigation.get_company_entities_from_db(company_id)

        elif roles_info["Wildcard_Choice"] == "AllRolesAllEntities":
            all_db_entities = self.osc_navigation.get_company_entities_from_db(company_id)
            if "Global Documents" not in entities:  # We should see the global tab
                entities.append('Global Documents')

        # Pull out the Global Docs entity and add the correct text to db_entities
        if "Global Documents" in entities:
            entities.remove("Global Documents")
            all_db_entities.append("Global Overview")

        # Always see Notifications tab
        all_db_entities.append("Notifications")

        return all_db_entities

    def has_sec_admin_access(self, roles_info):
                # If the user has User Admin Full then they should see the security admin link
        check_sec_admin = False
        if roles_info["Wildcard_Choice"] == "AllRolesAllEntities":
            check_sec_admin = True
        else:
            entities = list(roles_info["Entity_Roles"].keys())
            if "Company Applicable Roles" in entities:
                if "User Administrator Full" in roles_info["Entity_Roles"]["Company Applicable Roles"]:
                    check_sec_admin = True

        return check_sec_admin
