import jenkins
import unicodedata
import sys

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    view = "Daily_Runs"
    report_job = "Daily_Run_Report"

    i = 0
    for arg in sys.argv:
        if "-view=" in arg:
            view = arg[6:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-report=" in arg:
            report_job = arg[8:]
            sys.argv.remove(arg)
            break
        i += 1

    path = """C:\\QA\\Automation2_0\\Tests\\Jenkins Jobs\\""" + view + ".groovy"

    server = jenkins.Jenkins('http://jenkins.hsp.com:8080', username='sleboeuf', password='Password1')
    jobs = server.get_jobs(view_name=view)
    with open(path, 'w') as groovy_file:
        groovy_file.writelines("""import jenkins.model.Jenkins\n\n"""
                               "\n")

        for job in jobs:

            job_string = "testWrapper('%s')\n" % job['fullname']
            groovy_file.writelines(job_string)

        groovy_file.writelines("\n"
                               "\ndef testWrapper(test_name){\n"
                               "\ttry{\n"
                               "\t\tretry(3){\n"
                               "\t\t\tif(browser == 'default'){\n"
                               "\t\t\t\tresult = build job: test_name, parameters: [[$class: 'StringParameterValue', name: 'env', value: env_flag]], propagate: false\n"
                               "\t\t\t}\n"
                               "\t\t\telse{\n"
                               "\t\t\t\tresult = build job: test_name, parameters: [[$class: 'StringParameterValue', name: 'env', value: env_flag], [$class: 'StringParameterValue', name: 'browser', value: browser]], propagate: false\n"
                               "\t\t\t}\n"
                               "\t\t\tif(result.result != 'SUCCESS'){\n"
                               "\t\t\t\terror 'test'\n"
                               "\t\t\t}\n"
                               "\t\t}\n"
                               "\t} catch(error) {\n"
                               """\t\techo "test failed 3 times"\n"""
                               "\t}\n"
                               "}")
