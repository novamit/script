import pyotp
import keyring


class MfaManager(object):

    # Get the users that will be used to login to VFunds QA or PROD environment
    @classmethod
    def get_code(cls, environment, username):
        return pyotp.TOTP(keyring.get_password(environment, username)).now()

    # Set the users that will be used to login to VFunds QA or PROD environment
    # TODO: SL Note - We shouldn't be exposing our 2fa codes in plain text like this here. The reason we use keyrings
    # TODO: in this instance is to keep these passwords hidden.
    @classmethod
    def set_code(cls):
        pass

