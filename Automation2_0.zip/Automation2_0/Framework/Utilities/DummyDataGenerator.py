import random
import time
import datetime


class DummyDataGenerator:

    person_names = ["tom2", "tomson2", "barry2", "barryson2", "craig2", "craigson2", "lisa2", "lisason2"]
    email_suffix = ["@gmail.com", "@yahoo.com", "@outlook.com", "@dummy.com"]
    job_title = ["Tester", "Manager", "Janitor", "Accountant"]

    def __init__(self):
        pass

    @classmethod
    def random_name(cls):
        return random.choice(cls.person_names)

    @classmethod
    def random_title(cls):
        return random.choice(cls.job_title)

    @classmethod
    def random_number(cls, start=1, end=999):
        return random.randint(start, end)

    @classmethod
    def random_email_suffix(cls):
        return random.choice(cls.email_suffix)

    @classmethod
    def current_datetime(cls):
        return time.strftime("%m%d%Y_%H%M%S", time.localtime())

    @classmethod
    def current_year(cls):
        year = datetime.date.today().strftime("%Y")
        return year

    @classmethod
    def current_month(cls):
        month = datetime.date.today().strftime("%m")
        return month

    @classmethod
    def current_date(cls):
        current_date = datetime.date.today().strftime("%m/%d/%Y")
        return current_date

    @classmethod
    def add_days(cls, days):
        new_date = (datetime.date.today() + datetime.timedelta(days=days)).strftime("%m/%d/%Y")
        return new_date

    @classmethod
    def sub_days(cls, days):
        new_date = (datetime.date.today() - datetime.timedelta(days=days)).strftime("%m/%d/%Y")
        return new_date

    @classmethod
    def get_weekday_name(cls, given_date):
        weekday_name = datetime.datetime.strptime(given_date, "%m/%d/%Y")
        return weekday_name.strftime('%A')

    @classmethod
    def get_day(cls, given_date):
        day = datetime.datetime.strptime(given_date, "%m/%d/%Y")
        return day.strftime('%d')

    @classmethod
    def current_weekday_name(cls):
        weekday_name = datetime.date.today().strftime('%A')
        return weekday_name