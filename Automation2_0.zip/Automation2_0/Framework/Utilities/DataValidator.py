from Framework.Utilities.Driver import Driver

class DataValidator:

    def __init__(self):
        pass

    @classmethod
    def validate_dicts(cls, d1, d2):
        result = dict()
        d1_keys = set(d1.keys())
        d2_keys = set(d2.keys())
        intersect_keys = d1_keys.intersection(d2_keys)
        result["Added"] = d1_keys - d2_keys
        result["Removed"] = d2_keys - d1_keys
        result["Modified"] = {o: (d1[o], d2[o]) for o in intersect_keys if d1[o] != d2[o]}
        result["Same"] = set(o for o in intersect_keys if d1[o] == d2[o])
        return result

    @classmethod
    def validate_lists(cls, l1, l2, validate_order=False):
        if not len(l1) == len(l2):
            return False

        if validate_order:
            for x in range(0, len(l1)):
                if not l1[x] == l2[x]:
                    return False
        else:
            for item in l2:
                if item not in l1:
                    return False

        return True

    @classmethod
    def validate_list_dicts(cls, l1, l2):
        result = list()
        if not len(l1) == len(l2):
            return False

        for x in range(0, len(l1)):
            result.append(cls.validate_dicts(l1[x], l2[x]))

        return result

    @classmethod
    def base_get_column_values(cls, locator, all_pages=False):
        values = list()

        if all_pages:

            if not Driver.alt_wait_for_element(locator):
                print("\nERROR: Unable to find column values")
                return None
            elements = Driver.return_elements(locator)
            for element in elements:
                values.append(element.text.replace('\n', ''))

        else:
            if not Driver.alt_wait_for_element(locator):
                print("\nERROR: Unable to find column values")
                return None
            elements = Driver.return_elements(locator)
            for element in elements:
                Driver.scroll_element_into_view(element, None)
                values.append(element.text.replace('\n', ''))

        return values

    @classmethod
    def base_get_all_column_values(cls, all_locators, all_pages=False):
        values = dict()

        for column in all_locators.keys():
            values[column] = list()

        if all_pages:

            while True:
                for column in all_locators.keys():
                    values[column] = values[column] + cls.base_get_column_values(all_locators[column])

        elif not all_pages:
            for column in all_locators.keys():
                values[column] = cls.base_get_column_values(all_locators[column], all_pages)

        return values
