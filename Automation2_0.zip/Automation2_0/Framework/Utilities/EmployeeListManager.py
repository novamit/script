import csv
from Framework.Utilities.DummyDataGenerator import DummyDataGenerator


class EmployeeListManager:
    # "C:\\QA\\Automation2_0\\Tests\\Data\\EmployeeImportTemplate.csv"

    employee_list = list()
    path = None
    base_path = "C:\\QA\\Automation2_0\\Tests\\Data\\EmployeeImportTemplate_BASE.csv"

    def __init__(self):
        pass

    @classmethod
    def setup(cls, path, base_path=None):
        cls.employee_list = list()
        if base_path is not None:
            cls.base_path = base_path
        cls.path = path

        with open(cls.base_path) as csvfile:
            csv_reader = csv.reader(csvfile)
            for row in csv_reader:
                cls.employee_list.append(row)

    @classmethod
    def make_employees_unique(cls, substring=None):
        employee_id_num = None
        first_name_num = None
        last_name_num = None
        email_num = None

        if substring is None:
            substring = DummyDataGenerator.current_datetime()

        n = 0
        for header in cls.employee_list[0]:
            if header == "Employee Id":
                employee_id_num = n
            elif header == "First Name":
                first_name_num = n
            elif header == "Last Name":
                last_name_num = n
            elif header == "E-mail Address":
                email_num = n

            n += 1

        i = 0
        for row in cls.employee_list:
            if i != 0:
                if not cls.employee_list[i][employee_id_num] == "":
                    row[employee_id_num] = cls.employee_list[i][employee_id_num] + substring

                if not cls.employee_list[i][first_name_num] == "":
                    row[first_name_num] = cls.employee_list[i][first_name_num] + substring

                if not cls.employee_list[i][last_name_num] == "":
                    row[last_name_num] = cls.employee_list[i][last_name_num] + substring

                if not cls.employee_list[i][email_num] == "":
                    row[email_num] = substring + cls.employee_list[i][email_num]

            i += 1

        with open(cls.path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(cls.employee_list)

        return cls.employee_list

    @classmethod
    def get_column_number(cls, column_name):

        n = 0
        for header in cls.employee_list[0]:
            if header.lower() == column_name.lower():
                return n
            n += 1

        return None
