import json
from Tests.BaseTest import BaseTest
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Utilities.DatabaseManager import DatabaseManager
from Framework.Utilities.Environment import Environment
from Framework.Utilities.Driver import Driver
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Pages.PatPages.PatPage import PatPage
from Framework.Pages.PatPages.SelectEntityPage import SelectEntityPage
from Framework.Pages.PatPages.DataFieldsPage import DataFieldsPage
from Framework.Pages.PatPages.EmployeeDocsPage import EmployeeDocsPage
from Framework.Pages.PatPages.UsagesPage import UsagesPage
from Framework.Pages.PatPages.CalendarPage import CalendarPage
from Framework.Workflows.UserGenerator import UserGenerator


class PayrollSetup(BaseTest):

    def payroll_setup(self):
        db_env = Environment.get_db_env()
        db_name = "Main%s" % db_env
        sql = """SELECT Lsp.ProviderGroupId
                            FROM [Company]
                            JOIN [LSP] ON Company.Id=Lsp.Id
                            where Company.Id=4169"""
        # if DatabaseManager.fetchall_query(sql, db_name)[0][0] is not None:
        #     return True

        self.user_generator = UserGenerator()
        # self.__enable_payroll()

        data_folder = 'C:\\QA\\Automation2_0\\Tests\\Payroll Tests\\Data\\'
        with open(data_folder + 'payroll.json') as user_data:
            value = json.load(user_data)["Test1"]
        affiliate_data = value["Affiliate_Data"]

        # Navigate to PAT
        self.assertTrue(PatPage.go_to(), "\nFAIL: Unable to load PAT")
        print("\nPASS: Able to load PAT")

        # Configure Affiliate
        self.__configure_affiliate(affiliate_data)

        # Configure Client-Entity
        self.__configure_client_entity(value)

        # Create Payroll admin and Lsp processor users
        self.__create_users(value)

        Driver.restart_browser()

    def __enable_payroll(self):
        db_env = Environment.get_db_env()

        db_name = "Main%s" % db_env
        sql = """update customerentity
                        set IsNextGenPayrollEnabled = 1
                        where Id=10504"""
        DatabaseManager.execute_query(sql, db_name)

        db_name = "Payroll%s" % db_env
        sql = """INSERT INTO [PayrollFileFormatType]([LspId], [PayrollFileContentTypeId], [FormatType], [__Version])
                VALUES(4169, 2, '.xlsx', 1)"""
        DatabaseManager.execute_query(sql, db_name)

        sql = """INSERT
                INTO[dbo].[PayrollFileFormatType]([LspId], [PayrollFileContentTypeId], [FormatType], [__Version])
                VALUES(4169, 6, '.xlsx', 1)"""
        DatabaseManager.execute_query(sql, db_name)

        sql = """INSERT
                INTO[dbo].[PayrollFileFormatType]([LspId], [PayrollFileContentTypeId], [FormatType], [__Version])
                VALUES(4169, 28, '.xlsx', 1)"""
        DatabaseManager.execute_query(sql, db_name)

        sql = """INSERT
                INTO[dbo].[PayrollFileFormatType]([LspId], [PayrollFileContentTypeId], [FormatType], [__Version])
                VALUES(4169, 1, '.xlsx', 1)"""
        DatabaseManager.execute_query(sql, db_name)

        # db_name = "Hr%s" % db_env
        # sql = """insert into EmployeeImportCustomerEntity (Id,Code,NotificationEmail,__Version)
        #                 values(10504,'QAP1111','steven.leboeuf@radiusww.com',1)"""
        # DatabaseManager.execute_query(sql, db_name)

        # db_name = "ShiRow%s" % db_env
        # sql = """select CorrelationId from keycorrelation
        #         where TableTypeId=14 and PrimaryKeyValue=10504"""
        # correlation_id = DatabaseManager.fetchall_query(sql, db_name)[0][0]
        #
        # sql = """insert into KeyCorrelation (TableTypeId,PrimaryKeyValue,CorrelationId,__Version)
        #         values(108,'10504','%s',1)""" % str(correlation_id)
        # DatabaseManager.execute_query(sql, db_name)

    def __configure_affiliate(self, affiliate_data):
        full_name = affiliate_data["Name"] + " - " + affiliate_data["Country"]

        # Make sure we're on the client-entity tab and create a new payroll definition
        self.assertTrue(PatPage.navigate_to_tab(PatPage.Tabs.AFFILIATE_CONFIGURATION),
                        "\nFAIL: Unable to navigate to Affiliate section")
        print("\nPASS: Arrived at Affiliate section")

        # Enter Affiliate name and continue
        self.assertTrue(PatPage.select_affiliate(affiliate_data),
                        "\nFAIL: Unable to select affiliate")
        print("\nPASS: Affiliate selected. Entering Data Fields section")

        # Verify data field title
        self.assertTrue(DataFieldsPage.return_title_text() ==
                        full_name,
                        "\nFAIL: Data Fields affiliate name is incorrect")
        print("\nPASS: Data Fields title is correct")

        # Add a new field
        data_fields = affiliate_data["Data_Fields"].keys()
        for data_field in data_fields:
            self.assertTrue(DataFieldsPage.add_data_field(affiliate_data["Data_Fields"][data_field]),
                            "\nFAIL: data field " + affiliate_data["Data_Fields"][data_field]["Field_Name"] +
                            " creation failed")
            print("\nPASS: data field " + affiliate_data["Data_Fields"][data_field]["Field_Name"] + " created")

        # Save data fields section
        self.assertTrue(DataFieldsPage.save(),
                        "\nFAIL: Data field section save failed")
        print("\nPASS: Data fields section saved. Entering Employee Docs section")

        # Verify employee docs title
        self.assertTrue(EmployeeDocsPage.return_title_text() ==
                        full_name,
                        "\nFAIL: Employee Docs affiliate name is incorrect")
        print("\nPASS: Employee Docs title is correct")

        # Add Employee Doc
        doc_data = affiliate_data["Doc"]
        doc_result = EmployeeDocsPage.add_document(doc_name=doc_data["Doc_Name"],
                                                   doc_code=doc_data["Doc_Code"],
                                                   tooltip=doc_data["Tooltip"],
                                                   soft_copy=doc_data["Soft_Copy"])

        self.assertTrue(doc_result,
                        "\nFAIL: Failed to create doc type " + doc_data["Doc_Name"])
        print("\nPASS: " + doc_data["Doc_Name"] + " doc type created")

        # Save employee docs section
        self.assertTrue(EmployeeDocsPage.save(),
                        "\nFAIL: Employee Docs section save failed")
        print("\nPASS: Employee Docs section saved. Entering Usages section")

        # Verify usages title
        self.assertTrue(UsagesPage.return_title_text() ==
                        full_name,
                        "\nFAIL: Usages affiliate name is incorrect")
        print("\nPASS: Usages title is correct")

        # Save Usages section
        self.assertTrue(UsagesPage.save("a"), "\nFAIL: Usages section save failed")
        print("\nPASS: Usages section saved. Affiliate configuration complete")

    def __configure_client_entity(self, value):
        entity_data = value["Entity_Data"]
        affiliate_data = value["Affiliate_Data"]
        full_title = entity_data["Name"] + " : " + entity_data["Payroll_Definition"]

        # Make sure we're on the client-entity tab and create a new payroll definition
        self.assertTrue(PatPage.navigate_to_tab(PatPage.Tabs.CLIENT_ENTITY_CONFIGURATION),
                        "\nFAIL: Unable to navigate to Client Entity section")
        print("\nPASS: Arrived at Client Entity section")

        self.assertTrue(SelectEntityPage.create_payroll_definition(entity=entity_data["Name"],
                                                                   payroll_definition=entity_data["Payroll_Definition"],
                                                                   affiliate=affiliate_data["Name"],
                                                                   payroll_type=entity_data["Payroll_Type"]),
                        "\nFAIL: Unable to select entity and create definition")
        print("\nPASS: Entity selected and payroll definition created")

        self.assertTrue(SelectEntityPage.save(),
                        "\nFAIL: Select entity section save failed")
        print("\nPASS: Client Entity section saved. Entering Data Fields section")

        # 2. Verify data field title
        self.assertTrue(DataFieldsPage.return_title_text() == full_title,
                        "\nFAIL: Data Fields affiliate name is incorrect")
        print("\nPASS: Data Fields title is correct")

        # 3. Save data fields section
        self.assertTrue(DataFieldsPage.save(),
                        "\nFAIL: Data field section save failed")
        print("\nPASS: Data Fields section saved. Entering Usages section")

        # 4. Verify usage title
        self.assertTrue(UsagesPage.return_title_text() == full_title,
                        "\nFAIL: Usages affiliate name is incorrect")
        print("\nPASS: Usages title is correct")

        # 5. Configure usages
        self.assertTrue(UsagesPage.configure_usages(entity_data["Usages"]),
                        "\nFAIL: Unable to configure Usages")
        print("\nPASS: Usages configured")

        # 6. Save usages section
        self.assertTrue(UsagesPage.save(),
                        "\nFAIL: Usages section save failed")
        print("\nPASS: Usages section saved. Entering Cash Mgmt section")

        # 9 Verify Calendar title
        self.assertTrue(CalendarPage.return_title_text() == full_title,
                        "\nFAIL: Calendar affiliate name is incorrect")
        print("\nPASS: Calendar title is correct")

        # 9 Configure and complete setup
        self.assertTrue(CalendarPage.configure_calendar(entity_data["Calendar"]),
                        "\nFAIL: Calendar section save failed")
        print("\nPASS: Calendar upload and save successful. Client Entity configuration completed.")

    def __create_users(self, value):
        payroll_user = value["Payroll_User"]
        LoginPage.go_to("internal")
        if not OsCDashboardPage.is_at_dashboard():
            return False
        OsCNavigation.change_client(payroll_user["Company_Info"]["Company_Name"])

        self.user_generator.generate(username=payroll_user["User_Info"]["Username"],
                                     password=payroll_user["User_Info"]["Password"],
                                     roles=payroll_user["Roles_Info"])