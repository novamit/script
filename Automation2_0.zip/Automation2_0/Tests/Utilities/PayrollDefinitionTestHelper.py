import time
from Tests.BaseTest import BaseTest
from Framework.Utilities.Driver import Driver
from Framework.Pages.PatPages.PatPage import PatPage
from Framework.Pages.PatPages.SelectEntityPage import SelectEntityPage
from Framework.Pages.PatPages.DataFieldsPage import DataFieldsPage
from Framework.Pages.PatPages.UsagesPage import UsagesPage
from Framework.Pages.PatPages.CalendarPage import CalendarPage
from Framework.Pages.OsCPages.OsCPayrollPage import OsCPayrollPage
from Framework.Pages.OsCPages.OsCHrPage import OsCHrPage
from Framework.Pages.NextgenPages.NextgenHrPage import NextgenHrPage
from Framework.Pages.NextgenPages.NextgenPayrollPage import NextgenPayrollPage
from Framework.Pages.NextgenPages.AffiliateDashboardPage import AffiliateDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Navigation.NextgenNavigation import NextgenNavigation
from Framework.Utilities.PayrollCalendarManager import PayrollCalendarManager
from Framework.Pages.LoginPage import LoginPage


class PayrollDefinitionTestHelper(BaseTest):

    def __init__(self, env, browser, ws, parent, method_name='runTest'):
        super(PayrollDefinitionTestHelper, self).__init__(method_name=method_name, env=env, browser=browser)
        self.parent_test = parent
        self.ws = ws
        # self.pt_helper = pt_helper

    def entity_configuration(self, value):
        entity_data = value["Entity_Data"]
        self.payroll_calendar = PayrollCalendarManager(entity_data["Calendar"])

        # Navigate to PAT
        if not PatPage.go_to():
            Driver.restart_browser()
            Driver.hard_wait(45)
            # Verify that you load into OsC
            self.assertTrue(LoginPage.go_to("internal", username="HSP\\svc_qa_jenkins", password="Password0", alt_user=True),
                            "Internal OsC user login")
            self.assertTrue(PatPage.go_to(),
                            "Loading PAT")

        # Configure Client-Entity
        print("\nINFO: ----------Starting Client Entity Configuration-----------")
        self.configure_client_entity(value)
        # self.__configure_client_entity(value)

        self.__class__.failed_flag = False

    def configure_client_entity(self, value):
        entity_data = value["Entity_Data"]
        affiliate_data = value["Affiliate_Data"]
        full_title = entity_data["Name"] + " : " + entity_data["Payroll_Definition"]

        # Make sure we're on the client-entity tab and create a new payroll definition
        self.assertTrue(PatPage.navigate_to_tab(PatPage.Tabs.CLIENT_ENTITY_CONFIGURATION),
                        "Navigation to Client Entity section")

        self.assertTrue(SelectEntityPage.create_payroll_definition(entity=entity_data["Name"],
                                                                   payroll_definition=entity_data["Payroll_Definition"],
                                                                   affiliate=affiliate_data["Name"],
                                                                   payroll_type=entity_data["Payroll_Type"]),
                        "Entity selection and definition creation")

        self.assertTrue(SelectEntityPage.save(),
                        "Select entity section save")

        # 2. Verify data field title
        self.assertTrue(DataFieldsPage.return_title_text() == full_title,
                        "Data Fields affiliate name")

        # 3. Save data fields section
        self.assertTrue(DataFieldsPage.save(),
                        "Data field section save")

        # 4. Verify usage title
        self.assertTrue(UsagesPage.return_title_text() == full_title,
                        "Usages affiliate name")

        # 5. Configure usages
        self.assertTrue(UsagesPage.configure_usages(entity_data["Usages"]),
                        "Usage configuration")

        # 6. Save usages section
        self.assertTrue(UsagesPage.save(),
                        "Usages section save")

        # 9 Verify Calendar title
        self.assertTrue(CalendarPage.return_title_text() == full_title,
                        "Calendar affiliate name")

        # 9 Configure and complete setup
        self.assertTrue(CalendarPage.configure_calendar(entity_data["Calendar"]),
                        "Calendar section save")
