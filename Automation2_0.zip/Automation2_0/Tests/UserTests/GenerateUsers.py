import unittest
import sys
import datetime
from Tests.BaseTest import BaseTest
from Framework.Utilities.Driver import Driver
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Workflows.UserGenerator import UserGenerator
from Framework.Pages.SecurityAdminPages.UsersPage import UsersPage
from Framework.Utilities.DummyDataGenerator import DummyDataGenerator
from Framework.Utilities.UserHelper import UserHelper

environment_flag = "stg"
browser_flag = "chrome"


class GenerateUsers(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        super(GenerateUsers, self).begin(environment_flag, browser_flag)

        self.user_generator = UserGenerator()
        self.user_helper = UserHelper()

        # Verify that you load into OsC

    def tearDown(self):

        # Closes the browser
        super(GenerateUsers, self).tearDown()

    def login(self):
        username = "HSP\\svc_qa_jenkins"
        password = "Password0"
        self.assertTrue(LoginPage.login_as(username).with_password(password).go_to("internal", alt_user=True),
                        "Login successfully")
        # LoginPage.go_to('internal')
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "External OsC user login")

        self.assertTrue(OsCNavigation.change_client('Rothesay'),
                        "External OsC user login")

    def test_verify_user_tabs(self):

        username = "RothesayLoad22" + DummyDataGenerator.current_datetime()
        value = dict()
        value["Roles_Info"] = dict()
        value["Roles_Info"]["Wildcard_Choice"] = "AllRolesAllEntities"
        Driver.restart_browser()
        self.login()
        # Generate and then log in a new user
        self.assertTrue(self.user_generator.generate(username=username,
                                     roles=value["Roles_Info"]), "User is generated")
        self.assertTrue(self.user_generator.delete_user(username=username), "\nPass: User is deleted")
        self.assertFalse(UsersPage.search_for_user(username=username), "\nPass: DeletedUser not found")


# ------------------------------------------er---------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1

    unittest.main(warnings='ignore')
