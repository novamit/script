import os
import unittest
import sys
from Tests.BaseTest import BaseTest
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Utilities.Driver import Driver
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Workflows.UserGenerator import UserGenerator
from Framework.Utilities.UserHelper import UserHelper
from ddt import ddt, file_data

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


@ddt
class UserEntityAndAppTabs(BaseTest):

    json_file = "Data/Users.json"

    def setUp(self):
        global environment_flag
        global browser_flag
        super(UserEntityAndAppTabs, self).begin(environment_flag, browser_flag)

        self.user_generator = UserGenerator()
        self.user_helper = UserHelper()

        # Verify that you load into OsC
        self.assertTrue(self.login(),
                        "External OsC user login")

    def tearDown(self):
        Driver.restart_browser()
        # Verify that you load into OsC
        self.assertTrue(self.login(),
                        "External OsC user login")

        self.assertTrue(self.user_generator.delete_user(),
                        "User Deletion")

        # Closes the browser
        super(UserEntityAndAppTabs, self).tearDown()

    @staticmethod
    def login():
        username = "automationadmin"
        password = "Password0"
        LoginPage.go_to()
        return LoginPage.login(username=username, password=password)

    @file_data(json_file)
    def test_verify_user_tabs(self, value):

        user_info = value["User_Info"]
        roles_info = value["Roles_Info"]

        # Generate and then log in a new user
        result = self.user_generator.generate(username=user_info["Username"],
                                              password=user_info["Password"],
                                              roles=roles_info)

        self.assertTrue(result,
                        "User generation")

        # Verify the user's tabs
        # find out what entities we should have access to
        db_entities = self.user_helper.return_user_entity_tabs_from_roles_info(roles_info)

        # Verify we don't have too many or too few tabs
        tab_count = OsCNavigation.get_entity_tab_count()
        self.assertTrue(len(db_entities) == tab_count,
                        "Expected " + str(len(db_entities)) + " tabs. Found " + str(tab_count))

        # loop through every entity
        for db_entity in db_entities:
            combined_apps = []

            # Check if the entity tab exists and click on it
            tab_found = OsCNavigation.navigate_to_entity_with_db_data(db_entity)
            self.assertTrue(tab_found, "Visibility of tab " + str(db_entity))

            if db_entity != "Notifications":
                # Find out what apps the entity should have
                entity_apps = OsCNavigation.get_entity_available_app_tabs()
                # Find out what apps the user should see
                user_apps = self.user_helper.get_user_current_entity_app_tabs(value)

                # Creates a list of apps that are in both sections
                for entity_app in entity_apps:
                    if entity_app in user_apps:
                        combined_apps.append(entity_app)

                # We should always see a dashboard / overview tab so add it to the combined apps list
                if db_entity == "Global Overview":
                    combined_apps.append("dashboard")
                else:
                    combined_apps.append("overview")

                # Verify the entity's app tabs by looping through each one
                for combined_app in combined_apps:
                    app_found = OsCNavigation.get_app_tab(combined_app)
                    self.assertTrue(app_found is not None,
                                    "Visibility of app tab " + combined_app)

                # Verify that we don't have too many or too few app tabs
                self.assertTrue(len(combined_apps) == OsCNavigation.get_app_tab_count(),
                                "App tab count matching")

        # If the user has User Admin Full then they should see the security admin link
        if self.user_helper.has_sec_admin_access(roles_info):
            self.assertTrue(OsCDashboardPage.sec_admin_access(),
                            "Visibility of Security Admin link")


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(UserEntityAndAppTabs, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
