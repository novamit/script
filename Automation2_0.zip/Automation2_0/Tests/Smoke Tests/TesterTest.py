import unittest
import sys
import os
import json
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCAdvisoryPage import OsCAdvisoryPage
from Framework.Pages.GlobalAdvisoryPages.GlobalAdvisoryPage import GlobalAdvisoryPage
from Framework.Pages.ThirdPartyPages.SalesforcePage import SalesforcePage
# from Framework.Utilities.ShiEventHelper import ShiEventHelper

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class TesterTest(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        super(TesterTest, self).begin(environment_flag, browser_flag)

    def tearDown(self):
        """ Closes the browser """
        super(TesterTest, self).tearDown()

    def est_galist(self):
        # Navigate to the internal Login
        LoginPage.go_to("internal")

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "Internal OsC user login")

        # test_dict_list is a list of dicts containing data from country compliance alerts
        test_dict_list = OsCDashboardPage.get_country_compliance_alerts_data()

        # This will print out the data grabbed from the first row of the list. Note that lists start at 0 and not 1
        print(test_dict_list[0])

        # This will print out the title from the first row of the list.
        print(test_dict_list[0]["Title"])

        # This will loop through each dict in the test_dict_list. Ex. In the first loop row will be equal to
        # test_dict_list[0]. The next loop row will equal test_dict_list[1] and so on until the end of the list is
        # reached
        for row in test_dict_list:
            print(row)

        OsCNavigation.navigate_to_application(OsCNavigation.APP_ADVISORY)

        OsCAdvisoryPage.navigate_to_advisory()

        other_dict_list = GlobalAdvisoryPage.DYKWidget.get_all_rows()

        print(test_dict_list)
        print(other_dict_list)

    def test_salesforce_login(self):

        SalesforcePage.go_to_login()
        SalesforcePage.login("tushar.bane@radiusww.com.uat", "Tushar@6138")
        SalesforcePage.is_at()
        SalesforcePage.go_to_page_by_id(page_id="0014000000kdwPl")
        SalesforcePage.fetch_opportunity_from_list("The Trade Desk Inc - Advisory - Australia | AU | AUD", "AR3Test")
        SalesforcePage.accept_reject_advisory_record(comment="Trying to execute the code", accept=True)

        print("m here")


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(TesterTest, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
