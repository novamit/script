import unittest
import sys
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Pages.SecurityAdminPages.UsersPage import UsersPage
from Framework.Utilities.DummyDataGenerator import DummyDataGenerator
from ddt import ddt, file_data

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


@ddt
class InvalidEmailTest(BaseTest):

    json_file = "Data/InvalidEmails.json"

    def setUp(self):
        global environment_flag
        global browser_flag
        username = "automationadmin"
        password = "Password0"
        super(InvalidEmailTest, self).begin(environment_flag, browser_flag)

        LoginPage.go_to()
        LoginPage.login_as(username)\
            .with_password(password)\
            .login()

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "\nFAIL: External OsC user login failed")
        print("\nPASS: External OsC user login success")

    def tearDown(self):
        """ Closes the browser """
        super(InvalidEmailTest, self).tearDown()

    @file_data(json_file)
    def test_invalid_email(self, value):

        first_name = DummyDataGenerator.random_name()
        last_name = DummyDataGenerator.random_name()
        username = first_name + last_name
        office_number = DummyDataGenerator.random_number()
        mobile_number = DummyDataGenerator.random_number()
        skype_id = DummyDataGenerator.random_name()

        intacct_user_id = ""

        # Navigate to Sec Admin. Defaults to Users section
        OsCDashboardPage.navigate_to_sec_admin()
        self.assertTrue(UsersPage.is_at(),
                        "\nFAIL: External System Administration page failed")
        print("\nPASS: External System Administration page success")

        result = UsersPage.create_user(username)\
            .with_first_name(first_name)\
            .with_last_name(last_name)\
            .with_email(value)\
            .with_office_number(office_number)\
            .with_mobile_number(mobile_number)\
            .with_skype_id(skype_id)\
            .with_intacct_user_id(intacct_user_id)\
            .create(valid=False)

        if not result:
            print("\nFAIL: Invalid email " + value + " was accepted")
            UsersPage.search_for_user(username)
            UsersPage.delete_top_user()
            failstr = "\nFAIL: Invalid email " + value + " was accepted"
            self.assertTrue(result, failstr.encode('utf-8'))
        passstr = "\nPASS: Invalid email " + value + " was not accepted"
        print(passstr.encode('utf-8'))

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(InvalidEmailTest, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
