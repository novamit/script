import unittest
import sys
import os
from Tests.BaseTest import BaseTest
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Utilities.Driver import Driver
from Framework.Pages.LoginPage import LoginPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Pages.OsCPages.OsCPayrollPage import OsCPayrollPage
from Framework.Pages.SetupAdminPages.SetupAdminPage import SetupAdminPage
from Framework.Navigation.NextgenNavigation import NextgenNavigation


environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class SetupAdminNavigation(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        super(SetupAdminNavigation, self).begin(environment_flag, browser_flag)

    def teardown(self):
        super(SetupAdminNavigation, self).tearDown()

    def test01_navigation(self):
        self.__login_as_admin()

        self.assertTrue(OsCNavigation.change_client("QA Payroll Automation Customer"),
                        "Changing client")

        self.assertTrue(OsCNavigation.navigate_to_entity("United States"),
                        "Navigation to country tab UK")

        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_PAYROLL),
                        "Navigation to application tab %s" % OsCNavigation.APP_PAYROLL)

        self.assertTrue(OsCPayrollPage.navigate_to_nextgen_payroll(), "Navigation to payroll application")

        self.assertTrue(NextgenNavigation.menu_navigation(page="hr"),
                        "Navigation to Next gen HR page from Payroll")

        self.assertTrue(NextgenNavigation.menu_navigation(page="payroll"),
                        "Navigation to Next gen Payroll page from HR")

        self.assertTrue(NextgenNavigation.menu_navigation(page="global compliance"),
                        "Navigation to Next gen Global Compliance page from Payroll")

        self.assertTrue(NextgenNavigation.menu_navigation(page="reports"),
                        "Navigation to Next gen Reports page from Global Compliance")

        self.assertTrue(NextgenNavigation.menu_navigation(page="osc"),
                        "Navigation to Next gen OsC page from Reports")

    def test02_switching_client(self):
        self.__login_as_admin()

        self.assertTrue(OsCNavigation.change_client("QA Payroll Automation Customer"),
                        "Changing client")

        self.assertTrue(OsCNavigation.navigate_to_entity("United States"),
                        "Navigation to country tab UK")

        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_PAYROLL),
                        "Navigation to application tab %s" % OsCNavigation.APP_PAYROLL)

        self.assertTrue(OsCPayrollPage.navigate_to_nextgen_payroll(), "Navigation to payroll application")

        self.assertTrue(NextgenNavigation.switching_client(client_name="DesignText Inc."), "Client switched successfully")

    def __login_as_admin(self):
        username = "hsp\\svc_qa_jenkins"
        password = "Password0"

        # Driver.restart_browser()

        LoginPage.login_as(username) \
            .with_password(password) \
            .go_to('internal', alt_user=True)

        self.assertTrue(OsCDashboardPage.is_at_dashboard())


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(SetupAdminNavigation, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
