import unittest
import sys
from openpyxl import load_workbook
import datetime
from Framework.Utilities.Driver import Driver
from Framework.Utilities.Environment import Environment
from Tests.BaseTest import BaseTest
import subprocess

environment_flag = "dev"
browser_flag = "chrome"


class PageLoadTests(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        super(PageLoadTests, self).begin(environment_flag, browser_flag)

    def tearDown(self):
        """ Closes the browser """
        super(PageLoadTests, self).tearDown()

    def test_external_user_login_osc(self):
        file_location = """\\\\qa-bos-wrk-001\\QA_Shared\\LoadTimes.xlsx"""

        wb = load_workbook(file_location)
        self.ws = wb.active
        current_row = str(self.ws.max_row + 1)
        date_row = "A" + current_row
        login_row = "B" + current_row
        dashboard_row = "C" + current_row
        payroll_row = "D" + current_row
        hr_row = "E" + current_row
        ct_row = "F" + current_row

        # Write current date and hour
        self.ws[date_row] = datetime.datetime.now().strftime("%m/%d/%Y %I%p")

        # Navigate to the external Login page
        self.__login_page(login_row)

        Driver.restart_browser()

        # Verify that you load into OsC
        self.__dashboard_page(dashboard_row)

        Driver.hard_wait(2)
        Driver.navigate_to_url("https://osc-dev.radiusworldwide.com/poc/web/#/company/596/entity/978/payroll")
        Driver.navigate_to_url("https://osc-dev.radiusworldwide.com/poc/web/#/company/596/entity/978/payroll")

        self.__payroll_page(payroll_row)

        Driver.hard_wait(2)
        Driver.navigate_to_url("https://osc-dev.radiusworldwide.com/poc/web/#/company/596/entity/978/hr")

        self.__hr_page(hr_row)

        self.__ct_page(ct_row)

        wb.save(file_location)

    def __enter_cell(self, dif, row):
        s = dif.seconds
        m = s // 60
        s -= (m * 60)

        if m == 0:
            self.ws[row] = "%s sec" % s
        else:
            self.ws[row] = "%s min %s sec" % (m, s)

    def __login_page(self, row):
        username_field = "input#username"
        result = True
        start = datetime.datetime.now()
        Driver.navigate_to_url(Environment.get_osc_url() + "/web/forcests/")
        if not Driver.wait_for_element_visible(username_field):
            result = False
        self.assertTrue(result, "FAIL: Unable to navigate to the login page")
        end = datetime.datetime.now()
        dif = end - start
        self.__enter_cell(dif, row)
        print("\nLogin page complete")

    def __dashboard_page(self, row):
        pg_not_found = "div#login h1"
        page_header = "div.pageHeader"
        unexpected_error_logo = """img[src="../../ErrorPages/images/Radius_Logo_HybridWeb.png"]"""

        result = True
        start = datetime.datetime.now()
        subprocess.call('cmdkey.exe /add:adfs.hsp.com /user:%s /pass:%s' % ("nairco\\sleboeuf", "Joerstmi9"))
        Driver.navigate_to_url(Environment.get_osc_url() + "/web/forceadfs/")
        subprocess.call('cmdkey.exe /delete:adfs.hsp.com')
        # if not Driver.wait_for_element_visible(pg_not_found):
        #    print("\n WARNING: Page not found message not seen after using forceadfs")
        # fetch current URL & edit the URL in the same manner we do it manually
        # Driver.navigate_to_url(Environment.get_osc_url() + "/web/")

        if not Driver.wait_for_element_visible(page_header):
            if Driver.low_wait_action(Driver.wait_for_element_visible, unexpected_error_logo):
                print("\nWarning: Unexpected error page seen")
                result = False
        else:
            result = Driver.wait_for_element_visible(page_header)

        self.assertTrue(result, "\nFAIL: External OsC user login failed")
        end = datetime.datetime.now()
        dif = end - start
        self.__enter_cell(dif, row)
        print("\nDashboard page complete")

    def __payroll_page(self, row):
        launch_payroll_button = """input[value="Launch Payroll"]"""
        payroll_logo = "div.header-logo-wrapper-global-payroll div.header-app-name img"
        payroll_title = "span.period-title"

        result = True
        start = datetime.datetime.now()

        if Driver.wait_for_element_visible(launch_payroll_button):
            Driver.click(launch_payroll_button)
            if Driver.wait_for_element_visible(payroll_logo):
                if Driver.alt_wait_for_element(payroll_title):
                    result = True
                else:
                    result = False
            else:
                result = False
        else:
            result = False

        self.assertTrue(result, "\nFAIL: Unable to navigate to payroll")
        end = datetime.datetime.now()
        dif = end - start
        self.__enter_cell(dif, row)
        print("\nPayroll page complete")

    def __hr_page(self, row):
        launch_hr_button = """input[value="Launch Employee Setup"]"""
        hr_logo = """img[alt="Employee Setup"]"""

        start = datetime.datetime.now()

        if Driver.wait_for_element_visible(launch_hr_button):
            Driver.click(launch_hr_button)
            result = Driver.alt_wait_for_element(hr_logo)
        else:
            result = False

        self.assertTrue(result, "\nFAIL: Unable to navigate to the hr page")
        end = datetime.datetime.now()
        dif = end - start
        self.__enter_cell(dif, row)
        print("\nHr page complete")

    def __ct_page(self, row):
        homepage_title = """img.ng-scope[ng-if="isHomePage"]"""
        transition_image = "div.transition-background img"

        Driver.hard_wait(5)
        start = datetime.datetime.now()

        Driver.navigate_to_url(Environment.get_osc_url() + "/ComplianceTracker/#/home")
        if Driver.wait_for_element_visible(homepage_title):
            result = Driver.wait_for_element_not_visible(transition_image)
        else:
            result = False
        self.assertTrue(result, "\nFAIL: Unable to navigate to the compliance tracker page")
        end = datetime.datetime.now()
        dif = end - start
        self.__enter_cell(dif, row)
        print("\nCT page complete")


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1

    unittest.main(warnings='ignore')
