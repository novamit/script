import unittest
import sys
import os
import json
from Tests.BaseTest import BaseTest
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Pages.DxpPlatformPages.LoginPage import LoginPage
from Framework.Pages.DxpPlatformPages.VistraApplicationsPage import VistraApplicationsPage
from Framework.Pages.DxpPlatformPages.MyFundsPages.LandingOverviewPage import LandingOverviewPage
from Framework.Pages.DxpPlatformPages.MyFundsPages.FundSummaryPage import FundSummaryPage
from Framework.Pages.DxpPlatformPages.MyFundsPages.SoiPage import SoiPage
from ddt import ddt

environment_flag = "prod"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


@ddt
class MyFundsNavigationTest(BaseTest):
    json = "C:\\QA\\Automation2_0\\Tests\\MyFundsTests\\Data\\Users_MyFunds.json"

    def setUp(self):
        global environment_flag
        global browser_flag
        super(MyFundsNavigationTest, self).begin(environment_flag, browser_flag)

    def test_navigation_admin_user(self):
        user_type = "admin"

        self.my_funds_login(user_type)

        # Go to Landing Overview page
        self.assertTrue(VistraApplicationsPage.navigate_to_my_funds(),
                        "Navigated to My Funds Landing Overview page")

        # Verify if at Landing Overview page
        self.assertTrue(LandingOverviewPage.is_at(),
                        "Currently at My Funds Landing Overview page")

        # Go to Fund Summary page from Landing Overview page "More Details"
        self.assertTrue(LandingOverviewPage.click_fund_overview_more_details_link(),
                        "Navigated to Fund Summary page")

        # Verify if at Fund Summary page
        self.assertTrue(FundSummaryPage.is_at(),
                        "Currently at Fund Summary page")

        # Go to Landing Overview page from Fund Summary page
        self.assertTrue(FundSummaryPage.navigate_to_my_funds_overview(from_page="fund summary"),
                        "Navigated to My Funds Landing Overview page")

        # Go to SOI page from Landing Overview page "More Details"
        self.assertTrue(LandingOverviewPage.click_soi_overview_more_details_link(),
                        "Navigate to SOI page")

        # Verify if at SOI page
        self.assertTrue(SoiPage.is_at(),
                        "Currently at SOI page")

        # Go to Landing Overview page from SOI page
        self.assertTrue(SoiPage.navigate_to_my_funds_overview(),
                        "Navigated to My Funds Landing Overview page")

        # Verify if at Landing Overview page
        self.assertTrue(LandingOverviewPage.is_at(),
                        "Currently at My Funds Landing Overview page")

        # Go to Fund Summary page from Landing Overview page
        self.assertTrue(LandingOverviewPage.navigate_to_fund_summary(),
                        "Navigated to the Fund Summary page")

        # Verify if at Fund Summary page
        self.assertTrue(FundSummaryPage.is_at(),
                        "Currently at Fund Summary page")

        # Go to Fund Summary Investor page from Fund Summary page
        self.assertTrue(FundSummaryPage.navigate_to_fund_summary_investor(),
                        "Navigated to Fund Summary Investor")

        # Go to Fund Drilldown page from Fund Summary Investor page
        self.assertTrue(FundSummaryPage.navigate_to_fund_drilldown(user=user_type),
                        "Navigated to Fund Drilldown")

        # Go to SOI page from Fund Drilldown page
        self.assertTrue(FundSummaryPage.navigate_to_schedule_of_investments(from_page="fund drilldown"),
                        "Navigated to SOI page")

        # Verify if at SOI page
        self.assertTrue(SoiPage.is_at(),
                        "Currently at SOI page")

        # Go to SOI Drilldown page from SOI page
        self.assertTrue(SoiPage.navigate_to_soi_drilldown(),
                        "Navigated to SOI Drilldown page")

        # TODO: Need to get a Fund Manager user for PROD
        """
        def test_navigation_fund_manager_user(self):
            pass
        """

        # TODO: Need to get a Investor user for PROD
        """
        def test_navigation_investor_user(self):
            pass
        """

    def test_navigation_multi_investor_user(self):
        user_type = "multiinvestor"

        self.my_funds_login(user_type)

        # Go to Landing Overview page
        self.assertTrue(VistraApplicationsPage.navigate_to_my_funds(),
                        "Navigated to My Funds Landing Overview page")

        # Verify if at Landing Overview page
        self.assertTrue(LandingOverviewPage.is_at(),
                        "Currently at My Funds Landing Overview page")

        # Go to Fund Summary page from Landing Overview page "More Details"
        self.assertTrue(LandingOverviewPage.click_fund_overview_more_details_link(),
                        "Navigated to Fund Summary page")

        # Verify if at Fund Summary page
        self.assertTrue(FundSummaryPage.is_at(),
                        "Currently at Fund Summary page")

        # Go to Landing Overview page from Fund Summary page
        self.assertTrue(FundSummaryPage.navigate_to_my_funds_overview(from_page="fund summary"),
                        "Navigated to My Funds Landing Overview page")

        # Go to SOI page from Landing Overview page "More Details"
        self.assertTrue(LandingOverviewPage.click_soi_overview_more_details_link(),
                        "Navigate to SOI page")

        # Verify if at SOI page
        self.assertTrue(SoiPage.is_at(),
                        "Currently at SOI page")

        # Go to Landing Overview page from SOI page
        self.assertTrue(SoiPage.navigate_to_my_funds_overview(),
                        "Navigated to My Funds Landing Overview page")

        # Verify if at Landing Overview page
        self.assertTrue(LandingOverviewPage.is_at(),
                        "Currently at My Funds Landing Overview page")

        # Go to Fund Summary page from Landing Overview page
        self.assertTrue(LandingOverviewPage.navigate_to_fund_summary(),
                        "Navigated to the Fund Summary page")

        # Verify if at Fund Summary page
        self.assertTrue(FundSummaryPage.is_at(),
                        "Currently at Fund Summary page")

        # Go to Fund Summary Investor page from Fund Summary page
        self.assertTrue(FundSummaryPage.navigate_to_fund_summary_investor(),
                        "Navigated to Fund Summary Investor")

        # Go to Fund Drilldown page from Fund Summary Investor page
        self.assertTrue(FundSummaryPage.navigate_to_fund_drilldown(user=user_type),
                        "Navigated to Fund Drilldown")

        # Go to SOI page from Fund Drilldown page
        self.assertTrue(FundSummaryPage.navigate_to_schedule_of_investments(from_page="fund drilldown"),
                        "Navigated to SOI page")

        # Verify if at SOI page
        self.assertTrue(SoiPage.is_at(),
                        "Currently at SOI page")

        # Go to SOI Drilldown page from SOI page
        self.assertTrue(SoiPage.navigate_to_soi_drilldown(),
                        "Navigated to SOI Drilldown page")

    @staticmethod
    def get_user_details(value, user_type):

        if environment_flag == 'prod':
            user_details = value["Test"]["Prod_Users"][user_type]
        else:
            user_details = value["Test"]["QA_Users"][user_type]

        return user_details

    def my_funds_login(self, user_type):

        with open(self.json) as data:
            value = json.load(data)

        user_details = self.get_user_details(value, user_type)

        username = user_details["username"]
        password = user_details["password"]
        environment = environment_flag

        # Navigate to the My Funds login page
        self.assertTrue(LoginPage.go_to(),
                        "Navigated to the My Funds Login page")

        # Login to My Funds
        self.assertTrue(LoginPage.login(username=username, password=password, environment=environment),
                        "Logged in as Fund Manager user")

        # Enter 2FA code
        self.assertTrue(LoginPage.enter_2fa_code(environment=environment, username=username),
                        "Entered 2FA code successfully")

        # Verify if at application page
        self.assertTrue(VistraApplicationsPage.is_at(),
                        "Navigated to Vistra Applications page")

    def tearDown(self):
        """ Closes the browser """
        super(MyFundsNavigationTest, self).tearDown()


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(MyFundsNavigationTest, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
