import sys
import unittest
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Pages.ExpenseAdminPage import ExpenseAdminPage
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCExpensePage import OsCExpensePage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Utilities.Driver import Driver
from Framework.Utilities.Environment import Environment
from Tests.BaseTest import BaseTest

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class ExpenseAdminTests(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        super(ExpenseAdminTests, self).begin(environment_flag, browser_flag)

        self.db_env = Environment.get_db_env()

        LoginPage.go_to("internal")

        # Verify if the browser loads into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(), "\nFAIL: Internal OsC user login failed")
        print("\nPASS: Internal OsC user login success")

    def tearDown(self):
        super(ExpenseAdminTests, self).tearDown()

    def test_expense_admin(self):
        company = "QA Payroll Automation Customer"
        entity = "QA Payroll Automation Customer - United Kingdom (SU)"
        email = "steven.leboeuf@radiusww.com"

        settings = dict()
        settings["Approval_Process"] = True
        settings["Roles"] = True
        settings["Tax_Profiles"] = False
        settings["Expense_Types"] = False
        settings["Branding"] = False
        settings["Expense_Currencies"] = True
        tpa = "Other"
        self.assertTrue(ExpenseAdminPage.navigate_to(), "\nFAIL: Unable to navigate to the ExpenseAdmin page")
        print("\nPASS: Navigated to the ExpenseAdmin page")

        result = ExpenseAdminPage.enable_expense_reporting(entity=entity,
                                                           email=email,
                                                           settings_dict=settings,
                                                           tpa=tpa)
        self.assertTrue(result, "\nFAIL: Unable to enable expense reporting for " + entity)
        print("\nPASS: Expense reporting enabled for " + entity)

        LoginPage.go_to("internal")
        self.assertTrue(OsCDashboardPage.is_at_dashboard(), "\nFAIL: OsC navigation failed")
        print("\nPASS: OsC navigation successful")

        self.assertTrue(OsCNavigation.change_client(company), "\nFAIL: Unable to navigate to " + company)
        print("\nPASS: Navigated to " + company)
        OsCNavigation.navigate_to_entity("United Kingdom")
        OsCNavigation.navigate_to_application(OsCNavigation.APP_EXPENSES)

        self.assertTrue(OsCExpensePage.config_btn_located(), "\nFAIL: Unable to find expense config button")
        print("\nPASS: Expense config button found")

        self.assertTrue(ExpenseAdminPage.navigate_to(), "\nFAIL: Unable to navigate to the ExpenseAdmin page")
        print("\nPASS: Navigated to the ExpenseAdmin page")

        self.assertTrue(ExpenseAdminPage.disable_expense_reporting(entity),
                        "\nFAIL: Unable to disable expense reporting for " + entity)
        print("\nPASS: Expense reporting disabled for " + entity)

        LoginPage.go_to("internal")
        self.assertTrue(OsCDashboardPage.is_at_dashboard(), "\nFAIL: OsC navigation failed")
        print("\nPASS: OsC navigation successful")

        self.assertTrue(OsCNavigation.change_client(company), "\nFAIL: Unable to navigate to " + company)
        print("\nPASS: Navigated to " + company)
        OsCNavigation.navigate_to_entity("United Kingdom")
        OsCNavigation.navigate_to_application(OsCNavigation.APP_EXPENSES)

        for x in range(0, 10):
            if OsCExpensePage.config_btn_located():
                Driver.hard_wait(10)
            else:
                break

        self.assertFalse(OsCExpensePage.config_btn_located(),
                         "\nFAIL: Expense config button found")
        print("\nPASS: Expense config button not found")


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(ExpenseAdminTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
