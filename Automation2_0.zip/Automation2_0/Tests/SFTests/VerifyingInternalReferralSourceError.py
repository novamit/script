import os
import sys
import time
import unittest

from ddt import ddt, file_data

# from Framework.Pages import LoginIntoSalesforce
# from Framework.Pages.Account.CreateAccountPages import CreateAccount
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner

# from Framework.Pages.LoginIntoSalesforce import Login
from Framework.Pages.Account.CreateAccountPagesjson import Locators
from Framework.Pages.Account.CreateAccountPagesjson import CreateAccountScreen
from Framework.Pages.LoginIntoSalesforce.Login import LoginInToSalesforce
from Framework.Utilities.DummyDataGenerator import DummyDataGenerator
from Tests.BaseTest import BaseTest

import os as os1

environment_flag = "stg"
browser_flag = "chrome"
workspace = os1.getcwd()+"\\Screenshots"


@ddt
class Create_Account1(BaseTest):

    json=os1.getcwd()+"\\Tests\\SFTests\\Data\\VerifyingInternalReferralSourceError.json"

    def setUp(self):
        global browser_flag
        super(Create_Account1, self).begin(browser_flag)

    def teardown(self):
        super(Create_Account1, self).tearDown()

    @file_data(json)
    def test_0_VeryfyingInternalRefSource(self, value):
        create_account_details = value["Create_Account_Details"]
        Profile = value["Credentials"]
        create_account_details["Account_Name"]="SeleniumAccount"+DummyDataGenerator.current_datetime()
        self.assertTrue(LoginInToSalesforce.login_Into_Salesforce(Profile), "Logged in Successfully")
        self.assertTrue1(CreateAccountScreen.select_recordtype_create_account(create_account_details), Locators.scrollable_element ,"Account Saved successfully")
        self.assertTrue1(CreateAccountScreen.Verifying_Internal_Error(),Locators.scrollable_element, "Verifying Internal error.Account Not Created Successfully")
        # time.sleep(40)



# Create_Account.setUp()
# Create_Account.test_Create_Account_Affiliates()
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(Create_Account1, environment_flag, browser_flag, workspace))
    t = runner.run(suite)
    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")

