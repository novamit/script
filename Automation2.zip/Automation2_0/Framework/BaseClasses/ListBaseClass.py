from abc import ABCMeta, abstractmethod


class ListBase:

    __metaclass__ = ABCMeta

    ALL_COLUMNS = list()
    COLUMN_LOCATORS = dict()

    def __init__(self):
        pass

    @classmethod
    def search(cls, filters):
        """ This method handles setting the search filters for the list and then starting the search
        :param filters:
        :return:
        """
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def find_row(cls, filters):
        """ This method returns the number of the first row that contains all of the values given in kwargs
        :param filters: dict of values you're looking for in a row
        :return: int+
        """
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def get_row(cls, row_num):
        """This method returns the values of a requested row
        :param row_num:
        :return: dict
        """
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def get_all_rows(cls):
        """This method returns the values of all visible rows
        :return:
        """
        raise NotImplementedError

    @classmethod
    def select_row(cls, row_num):
        """This method will click to select the requested row
        :param row_num:
        :return:
        """
        raise NotImplementedError
