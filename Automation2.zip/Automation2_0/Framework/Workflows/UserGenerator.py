from Framework.Utilities.Driver import Driver
from Framework.Pages.SecurityAdminPages.UsersPage import UsersPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Utilities.DummyDataGenerator import DummyDataGenerator
from Framework.Pages.OptinPage import OptinPage
from Framework.Pages.LoginPage import LoginPage


# Class used for generating and deleting a user
# This class assumes you're signed in with a user that has access to Sec. Admin
class UserGenerator:

    def __init__(self):
        self.username = ""
        self.password = ""

        self.roles = dict()

    def reset_values(self):

        self.username = ""
        self.password = ""

        self.roles = dict()

    def generate(self, username, roles, password="Password1"):
        self.username = username
        self.password = password
        OsCDashboardPage.navigate_to_sec_admin()

        # Create the user and send the welcome email
        result = UsersPage.create_user(username=username,
                                       first_name=DummyDataGenerator.random_name(),
                                       last_name=DummyDataGenerator.random_name(),
                                       email="sleboeuf@hsp.com",
                                       office_number=DummyDataGenerator.random_number(),
                                       mobile_number=DummyDataGenerator.random_number(),
                                       skype=DummyDataGenerator.random_name(),
                                       roles=roles)

        if not result:
            return Driver.error("User creation failed")

        # Close the browser and reopen
        Driver.restart_browser()

        # Navigate to the user's Optin page
        if not OptinPage.optin_as(username=username, password=password):
            return Driver.error("Optin workflow failed")

        # Close the browser and reopen
        Driver.restart_browser()

        # Log in with this user and wait for the question selection to appear
        LoginPage.go_to()
        if not LoginPage.login(username=username, password=password):
            return Driver.error("Unable to login with the new user")

        # Set Security Question
        if not LoginPage.set_security_question():
            return Driver.error("Unable to set the security question")

        return OsCDashboardPage.is_at_dashboard()

    def delete_user(self, username=None):

        if username is None:
            if len(self.username) < 3:
                print("\nNo user to delete")
                return False
        else:
            self.username = username

        # If we're not at security admin page then navigate to it
        if not Driver.low_wait_action(UsersPage.is_at):
            if not OsCDashboardPage.navigate_to_sec_admin():
                return Driver.error("Unable to navigate to security admin")

        # Search for user and verify it returns
        if not UsersPage.search_for_user(self.username):
            return Driver.error("Unable to find the user to delete")
        # Delete the user
        if not UsersPage.delete_top_user():
            return Driver.error("Unable to delete the user")

        return True
