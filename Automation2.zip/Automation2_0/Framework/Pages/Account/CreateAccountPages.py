import time

from selenium.webdriver.common.by import By
from Framework.Utilities.Driver import Driver


class CreateAccount():

    @classmethod
    def Create_AccountAffiliates(cls, create_account_details):

        if Driver.wait_for_element_present(Locators.Account_Tab, by=By.XPATH, wait=5):
            Driver.press_Return(Locators.Account_Tab, by=By.XPATH)

        if not Driver.click(Locators.New_Button, by=By.XPATH):
            return Driver.error("\nError: Click on New button")

        # if not Driver.click(Locators.ClientProspectRadio, by=By.XPATH):
        #     return Driver.error("\nError: Click on Client/Prospect button")

        if not Driver.click(Locators.Next_Button, by=By.XPATH):
            return Driver.error("\nError: Click on Next button")

        # time.sleep(10)
        if not Driver.enter_text(Locators.Account_Name, create_account_details["Account_Name"], by=By.XPATH):
            return Driver.error("\nError: Unable to enter text in Account Name field")

        if not Driver.click(Locators.Sector, by=By.XPATH):
            return Driver.error("\nError: Click on Sector button")

        if not Driver.select_dropdown_option(Locators.Options_Sector, create_account_details["Sector"], by=By.XPATH):
            return Driver.error("\nError: Select the Sector dropdown")

        if not Driver.click(Locators.Industry, by=By.XPATH):
            return Driver.error("\nError: Click on Industry")

        if not Driver.select_dropdown_option(Locators.Options_Industry, create_account_details["Industry"],
                                             by=By.XPATH):
            return Driver.error("\nError: Select the Industry dropdown")

        if not Driver.click(Locators.Account_Type, by=By.XPATH):
            return Driver.error("\nError: Click on Account Type")

        if not Driver.select_dropdown_option(Locators.Options_Account_Type, create_account_details["Account_Type"],
                                             by=By.XPATH):
            return Driver.error("\nError: Select the Account Type dropdown")

        Driver.take_screenshot("C:\\temp_automation_downloads\\NewAccountSS1.png")

        if not Driver.enter_text(Locators.Phone_Number, create_account_details["Phone_Number"], by=By.XPATH):
            return Driver.error("\nError: Unable to enter text in Account Name field")
        Driver.take_screenshot("C:\\temp_automation_downloads\\JSON.png")
        # Entering Account Source
        # AccountSource=driver.find_element(By.XPATH, "//*[contains(@id,'511')]/div/div/a")
        # AccountSource.click()
        # SelectAccountSource = driver.find_element(By.XPATH, "//a[@title='Website']")
        # SelectAccountSource.click()
        if not Driver.click(Locators.Country, by=By.XPATH):
            return Driver.error("\nError: Click on Country")

        if not Driver.select_dropdown_option(Locators.Options_Country, create_account_details["Country"], by=By.XPATH):
            return Driver.error("\nError: Selecting the Country")

        if not Driver.click(Locators.Save_Button, by=By.XPATH):
            return Driver.error("\nError: Click on Save button")

        Account_Name_Element = "//span[text()='" + create_account_details["Account_Name"] + "']"
        if Account_Name_Element is not None:
            pass

        return Driver.wait_for_element_present(Account_Name_Element, by=By.XPATH)


class Locators:
    def __init__(self):
        pass

    Affiliates = "//span[contains(text(),'Affiliates')]"
    ClientProspectRadio = "//span[contains(text(),'Client/Prospect')]"
    CompFormRadio = "//span[contains(text(),'Company Formation')]"
    InterM_Partners = "//span[contains(text(), 'Intermediaries/Partners')]"

    Account_Tab = "//*[@id='oneHeader']/div[3]/one-appnav/div/one-app-nav-bar/nav/div/one-app-nav-bar-item-root[2]/a"
    # Options_Sector="//a[@title='Capital Market']"
    New_Button = "//div[text()='New']"
    Next_Button = "//button[@class='slds-button slds-button--neutral slds-button slds-button_brand uiButton']"
    Account_Name = "//input[contains(@id,'11')]"
    Sector = "//*[contains(@id,'317')]/div/div/a"
    Options_Sector = "//*[contains(@id,'338')]/div/ul/li"
    Industry = "//*[contains(@id,'394')]/div/div/a"
    Options_Industry = "//*[contains(@id,'415')]/div/ul/li"
    # Environmental/Clean Technology, Agriculture
    Account_Type = "//*[contains(@id,'171')]/div/div/a"
    Options_Account_Type = "//*[contains(@id,'192')]/div/ul/li"
    Phone_Number = "//input[contains(@id,'290')]"
    Account_Source = "//*[contains(@id,'511')]/div/div/a"
    Options_Account_Source = "//*[contains(@id,'534')]/div/ul/li"
    Internal_Referral_Source = "//*[contains(@id,'562')]"
    External_Referral_Source = "//*[contains(@id,'698')]"
    Country = "//*[contains(@id,'698')]/div/div/a"
    Options_Country = "//*[contains(@id,'719')]/div/ul/li"
    Save_Button = "//button[@title='Save']"
    # Account_Name_Element = "//span[text()='SeleniumAccount']"




