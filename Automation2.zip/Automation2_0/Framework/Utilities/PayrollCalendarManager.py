import csv
import datetime


class PayrollCalendarManager:
    # 'C:\\QA\\Automation2_0\\Tests\\Data\\1yrCalendar.csv'

    def __init__(self, path):
        self.calendar = list()
        self.payroll_close = list()
        with open(path) as csvfile:
            csv_reader = csv.reader(csvfile)
            n = 0
            for row in csv_reader:
                if n > 0:
                    date = datetime.datetime.strptime(row[0], '%m/%d/%Y').date()

                    if n > 1:
                        close_date = date - datetime.timedelta(days=1)
                        self.payroll_close.append(close_date.strftime('%m/%d/%Y'))

                    for num in range(0, 7):
                        temp_date = datetime.datetime.strptime(row[num], '%m/%d/%Y').date()
                        row[num] = temp_date.strftime('%m/%d/%Y')
                    self.calendar.append(row)
                n += 1
            n = 0
            for item in self.payroll_close:
                self.calendar[n].append(item)
                n += 1

    def return_period(self, num):
        return self.calendar[num - 1]
