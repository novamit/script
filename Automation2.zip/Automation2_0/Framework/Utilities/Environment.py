import os


class Environment:

    env_array = dict()
    env_array["url_env"] = None
    env_array["db_env"] = None
    
    def __init__(self):
        pass
        
    @classmethod
    def setup(cls, env="stg"):

        # Use poc by default
        if env is None or env.lower() == 'build':
            cls.env_array["url_env"] = 'build'
        else:
            cls.env_array["url_env"] = env

        if cls.env_array["url_env"].lower() == 'build':
            cls.env_array["db_env"] = 'Build'
        elif cls.env_array["url_env"].lower() == 'qa':
            cls.env_array["db_env"] = 'QA'
        elif cls.env_array["url_env"].lower() == 'smoke':
            cls.env_array["db_env"] = 'SmokeTesting'



    @classmethod
    def __get_url(cls, prefix):
        base_url = None
        url = None
    
        if prefix == "sts":
            base_url = "https://sts%s.vistra.com%s"
        elif prefix == "osc":
            base_url = "https://osc%s.vistra.com%s"

        if cls.env_array["url_env"] == 'poc':
            url = base_url % ("-dev", "/stg")
        elif cls.env_array["url_env"] == 'stg':
            url = base_url % ("-dev", "/stg")
        elif cls.env_array["url_env"] == 'env01':
            url = base_url % ("-dev", "/env01")
        elif cls.env_array["url_env"] == 'env02':
            url = base_url % ("-dev", "/env02")
        elif cls.env_array["url_env"] == 'env03':
            url = base_url % ("-dev", "/env03")
        elif cls.env_array["url_env"] == 'env04':
            url = base_url % ("-dev", "/env04")
        elif cls.env_array["url_env"] == 'env05':
            url = base_url % ("-dev", "/env05")
        elif cls.env_array["url_env"] == 'smoke':
            url = base_url % ("-smoke", "")
        elif cls.env_array["url_env"] == 'prod':
            url = base_url % ("", "")
        return url

    # TODO: This is a temporarily solution to use My Funds QA and PROD environment
    @classmethod
    def __temp_get_url(cls, project):
        base_url = None
        url = None

        if project == "myfunds":
            #base_url = "https://%s.vistra.com/"
            base_url = "https://%s.vistra.com/login/login.htm"

        if cls.env_array["url_env"] == 'prod':
            url = base_url % ("id")
        if cls.env_array["url_env"] == 'qa':
            url = base_url % ("qa-id")
        return url

    @classmethod
    def __temp_get_eu_substance_url(cls):
        base_url = None
        url = None

        base_url = "https://%s.myformations.vistra.com/"

        if cls.env_array["url_env"] == 'prod':
            url = base_url % "ppd"
        if cls.env_array["url_env"] == 'qa':
            url = base_url % "uat"
        return url

    @classmethod
    def get_url_env(cls):
        return cls.env_array["url_env"]

    @classmethod
    def get_db_env(cls):
        return cls.env_array["db_env"]

    @classmethod
    def get_optin_url(cls, optin_key):
        return cls.__get_url("osc") + "/sts/href/confirmAccount/" + optin_key

    @classmethod
    def get_employee_import_result_url(cls, company, entity, report):
        return cls.__get_url("osc") + "/Hr/EmployeeImportResult/href/company/%s/entity/%s/id/%s" % (company, entity, report)

    @classmethod
    def get_osc_url(cls):
        return cls.__get_url("osc")

    # TODO: Temporarily solution to access QA environment for My Funds
    @classmethod
    def get_myfunds_url(cls):
        return cls.__temp_get_url("myfunds")

    @classmethod
    def get_eu_substance_url(cls):
        return cls.__temp_get_eu_substance_url()
