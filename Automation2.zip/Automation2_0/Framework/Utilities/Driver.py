from selenium import webdriver
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.remote.errorhandler import TimeoutException
from selenium.webdriver.remote.errorhandler import UnexpectedAlertPresentException
from selenium.webdriver.remote.errorhandler import WebDriverException
from selenium.webdriver.remote.errorhandler import StaleElementReferenceException
from selenium.webdriver.common.action_chains import ActionChains
from Framework.Utilities.Environment import Environment
from Screenshot import Screenshot_Clipping
from PIL import Image
import time
import os
import glob
import pickle
from selenium.webdriver.common.keys import Keys
import webbrowser


# This class is used to abstract away interactions with the web driver
class Driver:
    
    timeout = 15
    page_load_timeout = 20
    retries = 3
    delay = 0.10
    file_download_folder = "/home/ssm-user/Downloads/selenium_scripts/screenshots"
    browser = None
    web_driver = None

    @classmethod
    def set_delay(cls, x=0.10):
        cls.delay = x
    
    @classmethod
    def success(cls, msg):
        print("\nPASS: %s" % msg)
        return True

    @classmethod
    def failure(cls, msg, return_none=False, ss=None):
        print("\nFAIL: %s" % msg)
        if ss is not None:
            cls.take_screenshot(ss)

        if return_none:
            return None
        else:
            return False

    @classmethod
    def failure1(cls, msg,element, return_none=False, ss=None):
        print("\nFAIL: %s" % msg)
        if ss is not None:
            cls.take_screenshot1(ss,element)

        if return_none:
            return None
        else:
            return False

    @classmethod
    def error(cls, msg, return_none=False):
        print("\nERROR: %s" % msg)

        if return_none:
            return None
        else:
            return False

    @classmethod
    def warning(cls, msg):
        print("\nWARNING: %s" % msg)
        return True

    @classmethod
    def info(cls, msg):
        print("\nINFO: %s" % msg)
        return True

    @classmethod
    def setup(cls, browser="chrome"):
        """ this method is used for the initial setup of the web_driver and related browser preferences
        :param browser: Used for indicating what browser the driver should use
        :return: None
        """
        cls.timeout = 8
        cls.browser = browser
        if browser.lower() == "firefox":
            profile = webdriver.FirefoxProfile()
            profile.set_preference('network.negotiate-auth.delegation-uris', 'https://adfs.hsp.com')
            profile.set_preference('network.automatic-ntlm-auth.trusted-uris', 'https://adfs.hsp.com')
            profile.set_preference('network.automatic-ntlm-auth.allow-proxies', 'True')
            profile.set_preference('network.negotiate-auth.allow-proxies', 'True')

            profile.set_preference('browser.download.folderList', 2)
            profile.set_preference('browser.download.dir', cls.file_download_folder)
            profile.set_preference('browser.helperApps.neverAsk.saveToDisk',
                                   'text/csv,application/pdf,application/msword,application/vnd.ms-excel,' +
                                   'application/vnd.openxmlformats-officedocument.wordprocessingml.document,' +
                                   'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,' +
                                   'image/jpeg')

            profile.update_preferences()
            cls.web_driver = webdriver.Firefox(profile)
        elif browser.lower() == "chrome":
            chrome_options = webdriver.ChromeOptions()
            prefs = dict()
            prefs["download.default_directory"] = cls.file_download_folder
            prefs['safebrowsing.enabled'] = 'true'
            chrome_options.add_experimental_option("prefs", prefs)
            #chrome_options.add_experimental_option("excludeSwitches",['enable-automation'])
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--disable-notifications')
            chrome_options.add_argument('--safebrowsing-disable-download-protection')
            # chrome_options.add_argument("user-data-dir=selenium")
            cls.web_driver = webdriver.Chrome("/home/ssm-user/Downloads/chromedriver.exe",chrome_options=chrome_options)
            cls.web_driver.maximize_window()
            print(cls.web_driver.get_window_size())
            cls.web_driver.get("https://vistramain--1sfdvbun01.my.salesforce.com")
        elif browser.lower() == "ie":
            cls.web_driver = webdriver.Ie()

        cls.web_driver.set_page_load_timeout(cls.page_load_timeout)
        cls.web_driver.set_window_size(1382, 744)

    def __init__(self):
        pass

    # @classmethod
    # def get_cookies(cls):
    #     return cls.web_driver.get_cookies()
    #
    # @classmethod
    # def set_cookies(cls, cookie_file_name):
    #
    #     cookies = pickle.load(open(cookie_file_name, "rb"))
    #     for cookie in cookies:
    #         cls.web_driver.add_cookie(cookie)
    #
    #     return True

    @classmethod
    def navigate_to_url(cls, url, blind=False):
        """ Navigates to a specified URL
        :param url: (str) URL for the browser to navigate to.
        :param blind: (bool) If true we set a low page load timeout and catch the TimeoutException
        :return: (bool) True if blind=True or if there was no timeout exception
        """
        success = True
        if blind:
            cls.web_driver.set_page_load_timeout(2)
        try:
            cls.web_driver.get(url)
        except TimeoutException:
            success = False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            success = False

        cls.web_driver.set_page_load_timeout(cls.page_load_timeout)

        return blind or success

    @classmethod
    def quit(cls):
        """ Quits the web_driver causing the browser to be closed
        :return: None
        """
        cls.web_driver.close()
        cls.web_driver.quit()

    @classmethod
    def hover_over_element(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Finds a web element and moves the cursor over it
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
                    None indicates that the selector parameter is a web element.
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: True if action is successful. False if the element to hover can't be found
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    if not cls.wait_for_element_present(selector=selector, by=by, wait=wait):
                        return cls.error("Element is not clickable")

                    element = cls.return_element(by=by, selector=selector, wait=wait)
                    if element is None:
                        return cls.error("Unable to obtain element")

                cls.hard_wait(cls.delay)
                actions = ActionChains(cls.web_driver)
                actions.move_to_element(element) \
                    .perform()
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to move the mouse over the element")

    @classmethod
    def hover_click(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Move the cursor over the element before preforming the click action
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
                    None indicates that the selector parameter is a web element.
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: False if the element can't be found. True if the click is successful
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    if not cls.wait_for_element_clickable(selector=selector, by=by, wait=wait):
                        return cls.error("Element is not clickable")

                    element = cls.return_element(by=by, selector=selector, wait=wait)
                    if element is None:
                        return cls.error("Unable to obtain element")

                cls.hard_wait(cls.delay)
                actions = ActionChains(cls.web_driver)
                actions.move_to_element(element) \
                    .click(element) \
                    .perform()
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to click element")

    @classmethod
    def get_text(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Returns a web element's visible text
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
                    None indicates that the selector parameter is a web element
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (str) Element's visible text
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    element = cls.return_element(by=by, selector=selector, wait=wait)
                    if element is None:
                        return cls.error("Unable to obtain element", return_none=True)

                cls.hard_wait(cls.delay)

                t = element.text
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return t

        return cls.error("Unable to get element text", return_none=True)

    @classmethod
    def click(cls, selector, by=By.CSS_SELECTOR, unstable=False, wait=None):
        """ Click a web element.
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
                    None indicates that the selector parameter is a web element
        :param unstable: Set to true if you want to click without checking if the element is clickable first
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if the click is successful. False otherwise.
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    if not unstable:
                        if not cls.wait_for_element_clickable(selector=selector, by=by, wait=wait):
                            return cls.error("Element is not clickable")

                    element = cls.return_element(by=by, selector=selector, wait=wait)
                    if element is None:
                        return cls.error("Unable to obtain element")

                cls.hard_wait(cls.delay)
                if not unstable:
                    cls.scroll_element_into_view(selector=selector, by=by)
                element.click()
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to click element")

    @classmethod
    def maximize(cls):

        return cls.web_driver.maximize_window()

    @classmethod
    def action_pageup(cls):
        action = ActionChains(cls.web_driver)
        action.send_keys(Keys.PAGE_UP).perform()



    @classmethod
    def drag_and_drop(cls, starting_selector, ending_selector, by=By.CSS_SELECTOR, unstable=False, wait=None):
        """ Clicks the starting element, moves the mouse to the ending element, and then releases the mouse click
        :param starting_selector: (str) Selector the web_driver should use to find the web element
        :param ending_selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
                    None indicates that the selector parameter is a web element
        :param unstable: Set to true if you want to click without checking if the element is clickable first
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if the drag and drop is successful. False otherwise.
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    starting_element = starting_selector
                    ending_element = ending_selector
                else:
                    if not unstable:
                        if not cls.wait_for_element_clickable(selector=starting_selector, by=by, wait=wait):
                            return cls.error("Element is not clickable")

                    starting_element = cls.return_element(by=by, selector=starting_selector, wait=wait)
                    ending_element = cls.return_element(by=by, selector=ending_selector, wait=wait)
                    if starting_element is None or ending_element is None:
                        return cls.error("Unable to obtain element")

                cls.hard_wait(cls.delay)
                actions = ActionChains(cls.web_driver)
                actions.drag_and_drop(starting_element, ending_element)\
                    .perform()
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to drag and drop element")

    @classmethod
    def clear_text(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """Clear a text web element.
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
                    None indicates that the selector parameter is a web element
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) False if the element can't be found. True otherwise
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    element = cls.return_element(by=by, selector=selector, wait=wait)
                    if element is None:
                        return cls.error("Unable to obtain element")

                element.clear()
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to enter text into the field")

    @classmethod
    def enter_text(cls, selector, text, by=By.CSS_SELECTOR, clear=True, visible=True, wait=None):
        """Click a web element.
        :param selector: (str) Selector the web_driver should use to find the web element
        :param text: (str) String to enter into the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
                    None indicates that the selector parameter is a web element
        :param clear: (bool) Indicates if we should try to clear the field first. Default is True
        :param visible: (bool) Indicates if the field we're using is visible or not. Default is True
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) False if the element can't be found. True otherwise
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    element = cls.return_element(by=by, selector=selector, visible=visible, wait=wait)
                    if element is None:
                        return cls.error("Unable to obtain element")

                if clear:
                    try:
                        element.clear()
                    except (WebDriverException, StaleElementReferenceException):
                        return cls.error("Unable to clear the text field")

                cls.hard_wait(cls.delay)

                element.send_keys(text)
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to enter text into the field")

    @classmethod
    def press_enter(cls, selector=None, by=By.CSS_SELECTOR):
        """ Sends an Enter keystroke to the given selector
        :param selector: (str) Selector the web_driver should use to find the web element. Default is None
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
                    None indicates that the selector parameter is a web element
        :return: None
        """
        if selector is None:
            selector = "html"
        return cls.enter_text(selector=selector, text=Keys.ENTER, by=by, clear=False)

    @classmethod
    def press_Return(cls, selector=None, by=By.CSS_SELECTOR):
        """ Sends an Enter keystroke to the given selector
        :param selector: (str) Selector the web_driver should use to find the web element. Default is None
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
                    None indicates that the selector parameter is a web element
        :return: None
        """
        if selector is None:
            selector = "html"
        return cls.enter_text(selector=selector, text=Keys.RETURN, by=by, clear=False)

    @classmethod
    def press_tab(cls, selector=None, by=By.CSS_SELECTOR):
        """ Sends a Tab keystroke to the given selector
        :param selector: (str) Selector the web_driver should use to find the web element. Default is None
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
                    None indicates that the selector parameter is a web element
        :return: None
        """
        if selector is None:
            selector = "html"
        return cls.enter_text(selector=selector, text=Keys.TAB, by=by, clear=False)

    @classmethod
    def set_checkbox(cls, selector, value=True, by=By.CSS_SELECTOR, wait=None):
        """ Sets a checkbox to be checked or unchecked based on the value parameter
        :param selector: (str) Selector the web_driver should use to find the web element.
        :param value: (bool) True means the box should be checked. False is unchecked
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if the checkbox was set successfully. False otherwise
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    if not cls.wait_for_element_clickable(selector, by=by, wait=wait):
                        return cls.error("Checkbox is not clickable")
                    element = cls.return_element(by=by, selector=selector)
                    if element is None:
                        return cls.error("Unable to obtain element")

                cls.scroll_element_into_view(selector=element, by=None)
                selected = cls.is_selected(selector=element, by=None)

                # Click the role if its not selected and you want to add it or if it is selected
                # and you want to remove it
                if (not selected and value) or (selected and not value):
                    cls.hard_wait(cls.delay)
                    element.click()

            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to click element")

    @classmethod
    def select_dropdown_option(cls, selector, option_text, by=By.CSS_SELECTOR, strict=True, wait=None):
        """ This method will select the requested option from a dropdown list.
        There are multiple types of dropdown implementations used throughout OsC and they're covered with the use of
        the standard and strict parameters.
        :param selector: (str) Selector the web_driver should use to find the web element.
        :param option_text: (str) Text we are using to find the option to click
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param strict: Indicates if we should look for the exact option_text or just partial
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if the dropdown selection was successful. False otherwise
        """
        for x in range(0, cls.retries):
            try:
                if by is None:
                    elements = selector
                else:
                    if not cls.alt_wait_for_element(selector=selector, by=by, wait=wait):
                        return cls.error("Unable to locate the requested element(s)")

                    elements = cls.return_elements(by=by, selector=selector)

                if isinstance(elements, list):
                    first_tag = elements[0]
                else:
                    first_tag = elements

                cls.hard_wait(cls.delay)
                if first_tag.tag_name.lower() == "select":
                    my_select = Select(first_tag)
                    try:
                        my_select.deselect_all()
                    except NotImplementedError:
                        pass
                    except UnexpectedAlertPresentException:
                        cls.wait_for_and_accept_alert()

                    my_select.select_by_visible_text(option_text)
                    return True
                else:
                    for option in elements:
                        element_text = cls.get_text(option, by=None)
                        if element_text is None:
                            continue
                        if option_text.lower() == element_text.lower() \
                                or (option_text.lower() in element_text.lower() and not strict):
                            return cls.click(option, by=None)
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()

        return cls.error("Unable to find the requested option %s" % option_text)

    @classmethod
    def alt_wait_for_element(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """
        Alternate wait for element that relies on counting the number of elements returned for a selector.
        Instead of watching for a particular element's property (visibility, presence, etc.
        :param selector: (str) Selector the web_driver should use to find the web elements
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True returned if any elements are found. False otherwise
        """

        if wait is None:
            timeout = cls.timeout
        else:
            timeout = wait

        for n in range(0, timeout):
            elements = cls.return_elements(selector=selector, by=by, wait=1)
            if len(elements) != 0:
                return True
        return False

    # Waits for an object to go stale.
    # Because an object needs to exist before it can go stale we can't just pass a locator
    @classmethod
    def wait_for_staleness(cls, element, wait=None):
        """ Takes a web element and waits for it to become stale
        :param element: Web element to watch for staleness
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if element has become stale within the time frame. False otherwise.
        """
        if wait is None:
            timeout = cls.timeout
        else:
            timeout = wait

        # if WebDriverWait times out we catch the exception and return False
        try:
            WebDriverWait(cls.web_driver, timeout).until(
                ec.staleness_of(element)
            )
        except TimeoutException:
            return False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            return False

        return True

    @classmethod
    def wait_for_element_visible(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Waits for a web element to become visible
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if element has become visible within the time frame. False otherwise.
        """
        if wait is None:
            timeout = cls.timeout
        else:
            timeout = wait

        # if WebDriverWait times out we catch the exception and return False
        try:
            WebDriverWait(cls.web_driver, timeout).until(
                ec.visibility_of_element_located((by, selector))
            )
        except TimeoutException:
            return False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            return False

        return True

    @classmethod
    def wait_for_element_present(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Waits for a web element to become present
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if element has become present within the time frame. False otherwise.
        """
        if wait is None:
            timeout = cls.timeout
        else:
            timeout = wait

        # if WebDriverWait times out we catch the exception and return False
        try:
            WebDriverWait(cls.web_driver, timeout).until(
                ec.presence_of_element_located((by, selector))
            )
        except TimeoutException:
            return False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            return False

        return True

    @classmethod
    def wait_for_element_not_visible(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Waits for a web element to disappear
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if element has disappeared within the time frame. False otherwise.
        """
        if wait is None:
            timeout = cls.timeout
        else:
            timeout = wait

        # if WebDriverWait times out we catch the exception and return False
        try:
            WebDriverWait(cls.web_driver, timeout).until(
                ec.invisibility_of_element_located((by, selector))
            )
        except TimeoutException:
            return False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            return False

        return True

    @classmethod
    def wait_for_element_clickable(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Waits for a web element to become clickable
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if element has become clickable within the time frame. False otherwise.
        """
        if wait is None:
            timeout = cls.timeout
        else:
            timeout = wait

        # if WebDriverWait times out we catch the exception and return False
        try:
            WebDriverWait(cls.web_driver, timeout).until(
                ec.element_to_be_clickable((by, selector))
            )
        except TimeoutException:
            return False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            return False

        return True

    @classmethod
    def wait_for_and_accept_alert(cls, wait=None):
        """ Waits for a browser alert message and clicks the accept or ok option
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if alert is found and accepted within the timeframe. False otherwise
        """
        if wait is None:
            timeout = cls.timeout
        else:
            timeout = wait

        try:
            WebDriverWait(cls.web_driver, timeout).until(
                ec.alert_is_present()
            )
        except TimeoutException:
            return False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            return False

        for x in range(0, cls.retries):
            try:
                cls.web_driver.switch_to.alert.accept()
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            else:
                return True

        return cls.error("Unable to find and accept alert")

    @classmethod
    def wait_for_and_dismiss_alert(cls, wait=None):
        """ Waits for a browser alert message and clicks the dismiss or cancel option
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if alert is found and dismissed within the timeframe. False otherwise
        """
        if wait is None:
            timeout = cls.timeout
        else:
            timeout = wait

        try:
            WebDriverWait(cls.web_driver, timeout).until(
                ec.alert_is_present()
            )
        except TimeoutException:
            return False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            return False

        for x in range(0, cls.retries):
            try:
                cls.web_driver.switch_to.alert.dismiss()
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            else:
                return True

        return cls.error("Unable to find and dismiss alert")

    @classmethod
    def refresh_page(cls):
        """ Causes the browser to refresh the page.
        :return: None
        """
        cls.web_driver.refresh()

    @classmethod
    def switch_to_new_tab(cls, old_handles):
        """ Waits for a new tab to appear and then switches focus to that tab
        :param old_handles: (Handle) Initial handles grabbed before whatever action should cause a new tab to appear
        :return: (bool) True if the switch was successful. False otherwise
        """
        try:
            WebDriverWait(cls.web_driver, cls.timeout)\
                .until(lambda z: len(old_handles) != len(cls.web_driver.window_handles))
        except TimeoutException:
            return False
        except UnexpectedAlertPresentException:
            cls.wait_for_and_accept_alert()
            return False
        for x in range(0, cls.retries):
            cls.hard_wait(cls.delay)
            try:
                cls.web_driver.switch_to.window(cls.web_driver.window_handles[1])
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("New tab not found")

    @classmethod
    def close_tab(cls):
        cls.web_driver.close()
        cls.web_driver.switch_to.window(cls.web_driver.window_handles[0])

    @classmethod
    def switch_to_frame(cls, frame, by=By.CSS_SELECTOR):
        """ Waits for a new frame to appear and then switches focus to that frame
        :param frame: (str) selector that defines the frame we want to switch to
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :return: (bool) True if frame switch is successful. False otherwise
        """
        for x in range(0, cls.retries):
            try:
                if not cls.wait_for_element_visible(frame, by=by):
                    return cls.error("Unable to find the requested frame")

                cls.hard_wait(cls.delay)
                cls.web_driver.switch_to.frame(cls.web_driver.find_element(by=by, value=frame))
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to switch to the requested frame")

    @classmethod
    def switch_to_default_frame(cls):
        """ Returns focus to the default frame """
        for x in range(0, cls.retries):
            cls.hard_wait(cls.delay)
            try:
                cls.web_driver.switch_to.default_content()
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
                return False
            else:
                return True
        return cls.error("Unable to switch back to the default frame")

    @classmethod
    def return_elements(cls, selector, by=By.CSS_SELECTOR, visible=False, wait=None):
        """ Returns a list of WebElement objects
        :param selector: (str) Selector the web_driver should use to find the web elements.
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param visible: (bool) Indicates if we should check for the element to be visible instead of just present
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (WebElement) list
        """
        elements = []

        if visible:
            if not cls.wait_for_element_visible(selector=selector, by=by, wait=wait):
                return elements
        if cls.wait_for_element_present(selector, by=by, wait=wait):
            for x in range(0, cls.retries):
                try:
                    elements = cls.web_driver.find_elements(by=by, value=selector)
                except (WebDriverException, StaleElementReferenceException):
                    cls.hard_wait(1)
                except UnexpectedAlertPresentException:
                    cls.wait_for_and_accept_alert()
                else:
                    break

        return elements

    @classmethod
    def return_element(cls, selector, by=By.CSS_SELECTOR, visible=False, wait=None):
        """ Returns a single WebElement object
        :param selector: (str) Selector the web_driver should use to find the web element.
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param visible: (bool) Indicates if we should check for the element to be visible instead of just present
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (WebElement)
        """
        element = None

        if visible:
            if not cls.wait_for_element_visible(selector=selector, by=by, wait=wait):
                return element
        if cls.wait_for_element_present(selector, by=by, wait=wait):
            for x in range(0, cls.retries):
                cls.hard_wait(cls.delay)
                try:
                    element = cls.web_driver.find_element(by=by, value=selector)
                except (WebDriverException, StaleElementReferenceException):
                    cls.hard_wait(1)
                except UnexpectedAlertPresentException:
                    cls.wait_for_and_accept_alert()
                else:
                    break

        return element

    @classmethod
    def is_selected(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Indicates if an element is checked or not. Used for determining the status of checkboxes
        :param selector: (str) Selector the web_driver should use to find the web element.
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: (bool) True if the element is checked. False otherwise
        """
        if by is None:
            element = selector
        else:
            element = cls.return_element(by=by, selector=selector, wait=wait)

        if element is None:
            return None
        return element.is_selected()

    @classmethod
    def return_window_handles(cls):
        """ Returns the current window handles """
        return cls.web_driver.window_handles

    @classmethod
    def return_current_url(cls):
        """ Returns the URL of the current page"""
        return cls.web_driver.current_url

    @classmethod
    def return_element_attribute(cls, selector, attribute, by=By.CSS_SELECTOR, wait=None):
        """
        :param selector: (str) Selector the web_driver should use to find the web element
        :param attribute: (str) Name of the attribute we want to have returned
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
                    None indicates that the selector parameter is a web element.
        :param wait: (int) Seconds to wait before failing an action
        :return: (str) Value of the requested WebElement's attribute
        """

        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    element = cls.return_element(by=by, selector=selector, wait=wait)

                cls.hard_wait(cls.delay)
                if element is None:
                    return None
                att = element.get_attribute(attribute)
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return att
        return None

    @classmethod
    def get_select_value(cls, selector, by=By.CSS_SELECTOR, wait=None):

        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    element = cls.return_element(by=by, selector=selector, wait=wait)
                my_select = Select(element)
                cls.hard_wait(cls.delay)

                att = my_select.first_selected_option.get_attribute("label")
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return att
        return None

    @classmethod
    def hard_wait(cls, seconds):
        """ Forces execution to pause for the indicated number of seconds"""
        time.sleep(seconds)

    @classmethod
    def adjust_timeout(cls, seconds):
        """ Adjusts the class level timeout to the given number of seconds"""
        cls.timeout = seconds

    @classmethod
    def reset_timeout(cls):
        """ Resets the class level timeout to 90 seconds"""
        cls.timeout = 90

    @classmethod
    def low_wait_action(cls, method, value=None, low_timeout=2):
        """DEPRECIATED. We can now set custom wait times on each individual wait method
        :param method: Method to execute after adjusting the class level timeout
        :param value: Parameter to send to the method. Default is None
        :param low_timeout: (int) Time in seconds to set the class level timeout to
        :return: Returns the result of the method parameter
        """
        cls.adjust_timeout(low_timeout)
        if value is not None:
            result = method(value)
        else:
            result = method()
        cls.reset_timeout()
        return result

    @classmethod
    def delete_all_cookies(cls):
        return cls.web_driver.delete_all_cookies()

    @classmethod
    def restart_browser(cls):
        """ Closes and reopens the browser"""
        cls.delete_all_cookies()

        cls.web_driver.close()
        cls.web_driver.quit()
        cls.setup(cls.browser)

    @classmethod
    def take_screenshot(cls, ss):
        """ Takes a screenshot of the browser and saves it with the date and time attached"""
        # date_string = time.strftime("%Y-%m-%d_%H%M%S", time.localtime())
        cls.web_driver.save_screenshot(ss)

    @classmethod
    def take_screenshot1(cls, ss,element):
        """ Takes a screenshot of the browser and saves it with the date and time attached"""
        # date_string = time.strftime("%Y-%m-%d_%H%M%S", time.localtime())

        #action=ActionChains(cls.web_driver)
        ob=Screenshot_Clipping.Screenshot()
        l = []
        element1 = cls.web_driver.find_element_by_xpath(element)

        for i in range(4):
            action = ActionChains(cls.web_driver)
            img_url1 = ob.get_element(cls.web_driver, element1, r'.')
            # driver.get_screenshot_as_file("screenshot" + str(i) + ".png")
            l.append(img_url1)
            #cls.web_driver.execute_script("arguments[0.scrollIntoView()]",element1)
            action.send_keys(Keys.PAGE_DOWN).perform()
            time.sleep(2)

        imgs = [Image.open(i) for i in l]

        # If you're using an older version of Pillow, you might have to use .size[0] instead of .width
        # and later on, .size[1] instead of .height
        min_img_width = min(i.width for i in imgs)

        total_height = 0
        for i, img in enumerate(imgs):
            # If the image is larger than the minimum width, resize it
            if img.width > min_img_width:
                imgs[i] = img.resize((min_img_width, int(img.height / img.width * min_img_width)), Image.ANTIALIAS)
            total_height += imgs[i].height

        # I have picked the mode of the first image to be generic. You may have other ideas
        # Now that we know the total height of all of the resized images, we know the height of our final image
        img_merge = Image.new(imgs[0].mode, (min_img_width, total_height))
        y = 0
        for img in imgs:
            img_merge.paste(img, (0, y))

            y += img.height
        img_merge.save(ss)
        #cls.web_driver.save_screenshot(ss)



    @classmethod
    def make_element_visible(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Executes javascript to force the given element to be visible
        This is normally used in conjunction with make_element_hidden
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: None
        """
        element = cls.return_element(by=by, selector=selector, wait=wait)
        if element is None:
            return cls.error("Unable to find the element to make visible")
        cls.web_driver.execute_script("""arguments[0].style.visibility="visible";""", element)
        return True

    @classmethod
    def force_element_click(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Executes javascript to force click the given element
        This is normally used in conjunction with make_element_hidden
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: None
        """
        element = cls.return_element(by=by, selector=selector, wait=wait)
        if element is None:
            return cls.error("Unable to find the element to make visible")
        cls.web_driver.execute_script("arguments[0].click();", element)
        return True

    @classmethod
    def make_element_hidden(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Executes javascript to force the given element to be invisible
        This is normally used in conjunction with make_element_visible
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: None
        """
        element = cls.return_element(by=by, selector=selector, wait=wait)
        if element is None:
            return cls.error("Unable to find the element to make hidden")
        cls.web_driver.execute_script("""arguments[0].style.visibility="hidden";""", element)
        return True

    @classmethod
    def scroll_element_into_view(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Executes javascript to force the browser to scroll the given element into view
        :param selector: (str) Selector the web_driver should use to find the web element
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
        :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
        :return: None
        """

        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    element = cls.return_element(by=by, selector=selector, wait=wait)
                    if element is None:
                        return cls.error("Unable to find the element to scroll into view")

                # cls.hard_wait(cls.delay)
                cls.web_driver.execute_script("return arguments[0].scrollIntoView();", element)
                # cls.web_driver.execute_script("window.scrollBy(0, -150);")

                # actions = ActionChains(cls.web_driver)
                # actions.move_to_element(element) \
                #     .perform()

            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to find any options under the given selector")

    @classmethod
    def scroll_left(cls, selector, by=By.CSS_SELECTOR, wait=None):
        """ Executes javascript to force the browser to scroll the given element into view
                :param selector: (str) Selector the web_driver should use to find the web element
                :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
                :param wait: (int) Time to wait in seconds. None will cause the default wait time to be used
                :return: None
                """

        for x in range(0, cls.retries):
            try:
                if by is None:
                    element = selector
                else:
                    element = cls.return_element(by=by, selector=selector, wait=wait)
                    if element is None:
                        return cls.error("Unable to find the element to scroll into view")

                # cls.hard_wait(cls.delay)
                # cls.web_driver.execute_script("return arguments[0].scrollTop = 0;", element)
                cls.web_driver.execute_script("return arguments[0].scrollLeft = 0;", element)

            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Unable to find any options under the given selector")

    @classmethod
    def return_file_download(cls, selector, file_name=None, partial=False, by=By.CSS_SELECTOR, delete=False):
        """ Clicks the given element to start a file download.
        Verifies that the requested file was downloaded
        :param selector: (str) Selector the web_driver should use to find the web element
        :param file_name: (str) Name of the file that we're verifying has been downloaded. If the default of None
            is used then the method will attempt to use the .text value of the element as the file name
        :param partial: (bool) If True then the file_name parameter only contains part of the file name we're looking
            for. If False then the file_name parameter contains the exact file name we're looking for. Default is False
        :param by: (By) Indicates what type of selector we're using. CSS_SELECTOR by default.
        :param delete: (bool) Flag to determine if you should delete the file or not
        :return: True if the file was downloaded and deleted successfully. False otherwise
        """
        if file_name is None:
            file_name = cls.get_text(selector, by)

        for x in range(0, 3):
            if not cls.click(selector=selector, by=by):
                cls.hard_wait(2)
                continue
            for y in range(0, int(cls.timeout / 3)):
                cls.hard_wait(1)
                if partial:
                    full_path = cls.file_download_folder + "\\*" + file_name + "*"
                    result = glob.glob(full_path)

                    if len(result) >= 1:
                        for item in result:
                            if delete:
                                if not cls.delete_file(item):
                                    continue
                            return item
                else:
                    full_path = cls.file_download_folder + "\\" + file_name

                    if os.path.isfile(full_path):
                        if delete:
                            if not cls.delete_file(full_path):
                                continue
                        return full_path

        return cls.error("File not found", return_none=True)

    @classmethod
    def delete_file(cls, full_path):
        """ Deletes a file at the given full path
        :param full_path: (str) Full path of the file to delete
        :return: (bool) True if delete is successful. False otherwise
        """
        if os.path.isfile(full_path):
            os.remove(full_path)
            for x in range(0, cls.timeout):
                if not os.path.isfile(full_path):
                    return True
            return cls.error("File not deleted from the host")
        return cls.error("File not found on the host")

    # KH Trying out
    @classmethod
    def open_new_tab(cls):
        """Opens a new tab and then switches to it.
        :return:
        """
        url = Environment.get_osc_url() + "/web/"
        w1 = cls.return_window_handles()
        cls.web_driver.execute_script("window.open('%s')" % url)
        return cls.switch_to_new_tab(w1)
        # cls.web_driver.execute_script("window.open('https://osc-dev.vistraworldwide.com/stg/web/')")
        # cls.web_driver.switch_to.window(cls.web_driver.window_handles[-1])

    @classmethod
    def switch_to_old_tab(cls):
        """Switches to the first tab
        :return:
        """
        return cls.switch_to_tab(0)

    # KH Trying out
    @classmethod
    def switch_to_tab(cls, tab_num=-1):
        """ Switches to the tab indicated by tab_num. By default it will go to the latest tab
        :param tab_num:
        :return:
        """
        for x in range(0, cls.retries):
            cls.hard_wait(cls.delay)
            try:
                cls.web_driver.switch_to.window(cls.web_driver.window_handles[tab_num])
            except (WebDriverException, StaleElementReferenceException):
                cls.hard_wait(1)
            except UnexpectedAlertPresentException:
                cls.wait_for_and_accept_alert()
            else:
                return True

        return cls.error("Old tab not found")
