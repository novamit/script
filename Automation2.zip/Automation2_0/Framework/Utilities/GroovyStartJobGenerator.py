import jenkins
import unicodedata
import sys

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    view = "Daily_Run"
    report_job = "Daily_Run_Report"

    i = 0
    for arg in sys.argv:
        if "-view=" in arg:
            view = arg[6:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-report=" in arg:
            report_job = arg[8:]
            sys.argv.remove(arg)
            break
        i += 1

    path = """C:\\QA\\Automation2_0\\Tests\\Jenkins Jobs\\""" + view + ".groovy"

    server = jenkins.Jenkins('http://10.131.20.110:8080', username='sleboeuf', password='Password1')
    jobs = server.get_jobs(view_name=view)
    with open(path, 'w') as groovy_file:
        groovy_file.writelines("""import jenkins.model.Jenkins\n\n"""
                               "\n"
                               "parallel(")

        for job in jobs:

            if not job['fullname'] == jobs[0]['fullname']:
                groovy_file.writelines(",")
            job_string = "\n\t'%s': {testWrapper('%s')\n}" % (job['fullname'], job['fullname'])
            groovy_file.writelines(job_string)

        groovy_file.writelines(")\n"
                               "\ndef testWrapper(test_name){\n"
                               "\ttry{\n"
                               "\t\tretry(3){\n"
                               "\t\t\tif(browser == 'default'){\n"
                               "\t\t\t\tresult = build job: test_name, parameters: [[$class: 'StringParameterValue', name: 'env', value: env_flag]], propagate: false\n"
                               "\t\t\t}\n"
                               "\t\t\telse{\n"
                               "\t\t\t\tresult = build job: test_name, parameters: [[$class: 'StringParameterValue', name: 'env', value: env_flag], [$class: 'StringParameterValue', name: 'browser', value: browser]], propagate: false\n"
                               "\t\t\t}\n"
                               "\t\t\tif(result.result != 'SUCCESS'){\n"
                               "\t\t\t\terror 'test'\n"
                               "\t\t\t}\n"
                               "\t\t}\n"
                               "\t} catch(error) {\n"
                               """\t\techo "test failed 3 times"\n"""
                               "\t}\n"
                               "}")
