import requests
import time
from Framework.Utilities.DatabaseManager import DatabaseManager
from Framework.Utilities.Environment import Environment


class ShiEventHelper(object):
    """ This class wraps db functions for easy use """

    # repair_url = Environment.get_osc_url() + "/eventacquisition/api/EventAcquisition/Repair/%s"
    # reg_event_url = Environment.get_osc_url() + "/eventacquisition/api/EventAcquisition/RegisterEvent/"
    repair_url = "%s/eventacquisition/api/EventAcquisition/Repair/%s"
    reg_event_url = "%s/eventacquisition/api/EventAcquisition/RegisterEvent/"

    def __init__(self):
        pass

    @classmethod
    def repair_event(cls, event_id):
        return requests.get(cls.repair_url % (Environment.get_osc_url(), event_id))

    @classmethod
    def register_salesforce_process_advisory_opportunity(cls, sf_id):
        url_p1 = cls.reg_event_url % Environment.get_osc_url()
        sf_url = url_p1 + "/Salesforce/ProcessAdvisoryOpportunity/%s/AU" % sf_id
        return requests.get(sf_url)

    @classmethod
    def wait_for_event_complete(cls, shi_id, repair=False, wait_time=50):
        db_env = Environment.get_db_env()
        db_name = "Shi%s" % db_env
        sql = """Select Id, WorkflowIsComplete, PrimaryKey, CommandTypeId, CurrentWorkflowStepId, 
        WorkflowStepStatusTypeId, ParentShiEventId
        From ShiEvent
        Where Id = %s
        Order by Id desc""" % shi_id

        is_completed = 0
        for x in range(0, wait_time):
            is_completed = DatabaseManager.fetchall_query(sql, db_name)[0][1]
            if is_completed == 0:
                time.sleep(20)
                if repair:
                    requests.get(cls.repair_url % (Environment.get_osc_url(), shi_id))
            else:
                break
        return is_completed == 1
