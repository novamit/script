import pyodbc
import time
import keyring


class DatabaseManager:
    """ This class wraps db functions for easy use """

    db_server = None
    connection = None
    cursor = None

    def __init__(self):
        pass

    @classmethod        
    def setup(cls, db_env):
        """ Responsible for the initial setup of the server name and database name appender based on the requested
        environment.
        :param db_env: (str) Indicates what environment's databases we want to access
        :return: None
        """
        cls.db_server = ""
        cls.connection = None
        cls.cursor = None
        if db_env is None:
            cls.db_server = "No environment specified."
        elif db_env.lower() == 'prod':
            cls.db_server = "radiusprodsqlserver.database.windows.net"
        elif db_env.lower() == 'smoke':
            cls.db_server = "radiussmtsqlserver.database.windows.net"
        else:
            cls.db_server = "DEVSQL01"

    @classmethod
    def __open(cls, db=None):
        """Responsible for opening the connection to the requested server and creating a cursor """
        retry_count = 3
        backoff = 10
        count = 0
        while count < retry_count:
            try:
                if cls.db_server == "DEVSQL01":
                    cls.connection = pyodbc.connect(DRIVER='{SQL Server}',
                                                    SERVER=cls.db_server,
                                                    DATABASE=db,
                                                    UID="qateam",
                                                    PWD=keyring.get_password("dev", "qateam"))
                elif cls.db_server == "radiussmtsqlserver.database.windows.net":
                    cls.connection = pyodbc.connect(DRIVER='{SQL Server}',
                                                    SERVER=cls.db_server,
                                                    DATABASE=db,
                                                    UID="smkdbadmin",
                                                    PWD=keyring.get_password("smoke", "smkdbadmin"))
                elif cls.db_server == "radiusprodsqlserver.database.windows.net":
                    cls.connection = pyodbc.connect(DRIVER='{SQL Server}',
                                                    SERVER=cls.db_server,
                                                    DATABASE=db,
                                                    UID="prddbreader",
                                                    PWD=keyring.get_password("prod", "prddbreader"))
                else:
                    cls.connection = pyodbc.connect(DRIVER='{SQL Server}',
                                                    SERVER=cls.db_server,
                                                    Trusted_Connection='yes')
                cls.cursor = cls.connection.cursor()
                return

            except Exception:
                time.sleep(backoff)
                count += 1
        if retry_count == 3:
            raise Exception("\nUnable to connect to Database ('%s') after 3"
                            " retries." % cls.db_server)

    @classmethod
    def fetchall_query(cls, query, db=None, params=None):
        """ Responsible for returning results from a basic SELECT query
        :param query: (str) This is the query to be executed
        :param params: (list)(str) This is the list of parameters to execute the query with
        :param db: (str) This is the name of the database we should connect to. Needed for Azure DBs
        :return: (list) (str) A multidimensional array representing the returned rows of the query
        """
        cls.__open(db)
        if params is None:
            cls.cursor.execute(query)
        else:
            cls.cursor.execute(query, params)

        rows = cls.cursor.fetchall()
        cls.__close()
        return rows

    @classmethod
    def fetchall_multiple_results(cls, query, db=None, params=None):
        """ Responsible for returning results from a basic SELECT query
        :param query: (str) This is the query to be executed
        :param params: (list)(str) This is the list of parameters to execute the query with
        :param db: (str) This is the name of the database we should connect to. Needed for Azure DBs
        :return: (list) (str) A multidimensional array representing the returned rows of the query
        """
        cls.__open(db)

        results = list()
        if params is None:
            cls.cursor.execute(query)
        else:
            cls.cursor.execute(query, params)

        a = True
        while a:
            try:
                results.append(cls.cursor.fetchall())
            except pyodbc.ProgrammingError:
                pass
            a = cls.cursor.nextset()

        cls.__close()
        return results

    @classmethod
    def execute_query(cls, query, db=None, params=None):
        """ Responsible for executing a query that will manipulate data in the database (INSERT, UPDATE, DELETE)
        :param query: (str) This is the query to be executed
        :param params: (list)(str) This is the list of parameters to execute the query with
        :param db: (str) This is the name of the database we should connect to. Needed for Azure DBs
        :return: None
        """
        cls.__open(db)
        if params is None:
            cls.cursor.execute(query)
        else:
            cls.cursor.execute(query, params)
        cls.connection.commit()
        cls.__close()

    @classmethod
    def __close(cls):
        """Responsible for closing the connection to the requested server and the created cursor """
        cls.cursor.close()
        cls.connection.close()
        cls.connection = None
        cls.cursor = None
