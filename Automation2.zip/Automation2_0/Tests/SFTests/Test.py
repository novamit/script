import os
import sys
print(sys.path.c)