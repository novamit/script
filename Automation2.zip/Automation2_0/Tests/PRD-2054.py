import unittest
import sys
import os
import json
from Tests.BaseTest import BaseTest
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Utilities.Driver import Driver
from Framework.Utilities.Environment import Environment
from Framework.Pages.ComplianceTrackerPages.CountryEventsPage import CountryEventsPage
from Framework.Utilities.DatabaseManager import DatabaseManager
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Pages.ComplianceTrackerPages.HomePage import HomePage
from Framework.Pages.ComplianceTrackerPages.ClientEventsPage import ClientEventsPage

environment_flag = "stg"
browser_flag = "Chrome"
workspace = "C:\\temp_automation_downloads"


class OscCtDocs(BaseTest):

    json_file = "C:\\QA\\Automation2_0\\Tests\\ComplianceTrackerTest\\ClientEvents\\Data\\AddEditClientEvent.json"
    ce_json_file = "C:\\QA\\Automation2_0\\Tests\\ComplianceTrackerTest\\ClientEvents\\Data\\BasicCountryEvents.json"

    def setUp(self):
        global environment_flag
        global browser_flag
        super(OscCtDocs, self).begin(environment_flag, browser_flag)

        db = 'Compliance%s' % Environment.get_db_env()
        sql = 'select count(*) from CountryEventSummary where CountryEventName like ?'
        ce = "AUTO_No_Recurrence_Event"
        no_rec_count = DatabaseManager.fetchall_query(sql, params=[ce], db=db)[0][0]
        if no_rec_count == 0:
            with open(self.ce_json_file) as event_data:
                ce_data = json.load(event_data)
            self.__add_country_event(ce_data["No_Recurrence"]["Country_Event"])
        ce = "AUTO_Recurrence_Event"
        rec_count = DatabaseManager.fetchall_query(sql, params=[ce], db=db)[0][0]
        if rec_count == 0:
            with open(self.ce_json_file) as event_data:
                ce_data = json.load(event_data)
            self.__add_country_event(ce_data["Recurrence"]["Country_Event"])

        LoginPage.go_to("internal")
        self.assertTrue(OsCDashboardPage.is_at_dashboard())

    def tearDown(self):
        """ Closes the browser """
        super(OscCtDocs, self).tearDown()

    def __delete_existing_events(self, event_filter):
        db = 'Compliance%s' % Environment.get_db_env()
        sql = 'select count(*) from ClientEventSummary where CountryEventName = ?'
        ce = event_filter["Country_Event"]
        event_count = DatabaseManager.fetchall_query(sql, params=[ce], db=db)[0][0]

        if event_count > 0:
            print("INFO: Event from a previous test found. Attempting to delete")

            username = "hsp\\svc_qa_jenkins"
            password = "Password0"

            LoginPage.login_as(username) \
                .with_password(password) \
                .go_to('internal', alt_user=True)

            self.assertTrue(OsCDashboardPage.is_at_dashboard())

            self.assertTrue(HomePage.go_to_homepage(),
                            "Navigation to the CT homepage")
            self.assertTrue(HomePage.go_to_client_events(),
                            "Navigation to the Client Events page")
            search_result = ClientEventsPage.select_overview_result()
            self.assertTrue(search_result,
                            "Overview Search")
            self.assertTrue(ClientEventsPage.delete_client_event(event_filter),
                            "Deletion of Client Event")
            Driver.restart_browser()

    def __add_country_event(self, country_event):
        username = "hsp\\svc_qa_jenkins"
        password = "Password0"

        LoginPage.login_as(username) \
            .with_password(password) \
            .go_to('internal', alt_user=True)

        self.assertTrue(OsCDashboardPage.is_at_dashboard())

        self.assertTrue(HomePage.go_to_homepage(),
                        "Navigation to the CT homepage")
        self.assertTrue(HomePage.go_to_country_events(),
                        "Navigation to the Country Events page")

        self.assertTrue(CountryEventsPage.add_country_event(basic_info=country_event["Basic_Info"],
                                                            details=country_event["Details"],
                                                            milestones=country_event["Milestones"]),
                        "Adding a country event")

        Driver.restart_browser()

    def test_ct_upload(self):
        # TC#1, 5 & 6 - Uploaded doc in CT >> available in OSC, lock

        first_upload_file_path = "C:\\QA\\Upload_Test_Files\\doc_file.doc"
        first_upload_file_name = "doc_file.doc"

        second_upload_file_path = "C:\\QA\\Upload_Test_Files\\pdf_file.pdf"
        second_upload_file_name = "pdf_file.pdf"

        third_upload_file_path = "C:\\QA\\Upload_Test_Files\\docx_file.docx"
        third_upload_file_name = "docx_file.docx"

        with open(self.json_file) as event_data:
            data = json.load(event_data)

        client_event = data["Country_Client_Event_Recurrence"]["Client_Event"]

        event_filter = dict()
        event_filter["Client_Entity"] = client_event["Basic_Info"]["Client_Entity"]
        event_filter["Country"] = "United States"
        if "Event_Title" in client_event["Basic_Info"].keys():
            event_filter["Country_Event"] = client_event["Basic_Info"]["Event_Title"] + " (Independent)"
        else:
            event_filter["Country_Event"] = client_event["Basic_Info"]["Country_Event"]
        if "Compliance_Group" in event_filter.keys():
            event_filter["Compliance_Group"] = client_event["Basic_Info"]["Compliance_Group"]

        self.__delete_existing_events(event_filter)

        self.assertTrue(HomePage.go_to_homepage(),
                        "Navigation to the CT homepage")
        self.assertTrue(HomePage.go_to_client_events(),
                        "Navigation to the Client Events page")

        search_result = ClientEventsPage.select_overview_result()
        self.assertTrue(search_result,
                        "Overview Search")

        self.assertTrue(ClientEventsPage.add_client_event(basic_info=client_event["Basic_Info"],
                                                          details=client_event["Details"],
                                                          milestones=client_event["Milestones"]),
                        "Adding Client Event")

        result = None
        for x in range(0, 4):
            result = ClientEventsPage.advanced_search(event_filter)
            if result is not None:
                break
        self.assertTrue(result is not None,
                        "Selecting the newly created country event")

        # filters = dict()
        # filters["Country"] = "United States"
        # filters["Client_Entity"] = "QA Payroll Automation Customer - USA (SU)"
        # filters["Fiscal_Year"] = "2017"
        # filters["Country_Event"] = "KH_Automation_Test"

        self.assertTrue(ClientEventsPage.select_client_event(event_filter, occurrence=True),
                        "Selecting the client event")

        # Uploading Shared Doc
        self.assertTrue(ClientEventsPage.upload_doc(doc_type="Compliance",
                                                    doc_date="10/05/2017",
                                                    permission="shared",
                                                    file=first_upload_file_path),
                        "Uploading client event doc")

        self.assertTrue(ClientEventsPage.verify_file(first_upload_file_name),
                        "Verifying the file uploaded in the client event")

        # Uploading Radius Internal Doc
        self.assertTrue(ClientEventsPage.upload_doc(doc_type="Compliance",
                                                    doc_date="10/05/2017",
                                                    permission="radius internal",
                                                    file=second_upload_file_path),
                        "Uploading client event doc")

        self.assertTrue(ClientEventsPage.verify_file(second_upload_file_name),
                        "Verifying the file uploaded in the client event")

        self.assertTrue(ClientEventsPage.close_client_event_details(),
                        "Closing client event")

        self.assertTrue(LoginPage.go_to("internal"),
                        "Returning to OsC")

        # Navigate to OsC Global tab for Customer
        self.assertTrue(OsCNavigation.change_client("QA Payroll Automation Customer"),
                        "Navigation to client")

        self.assertTrue(OsCDashboardPage.document_search(name=first_upload_file_name,
                                                         app="Compliance",
                                                         country="United States"),
                        "Searching for doc uploaded in the client event")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=first_upload_file_name,
                                                             permission_icon="blank",
                                                             doc_type="Compliance"),
                        "Verifying the doc uploaded in the client event")

        self.assertTrue(OsCDashboardPage.document_search(name=second_upload_file_name,
                                                         app="Compliance",
                                                         country="United States"),
                        "Searching for internal only doc uploaded in the client event")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=second_upload_file_name,
                                                             permission_icon="internal",
                                                             doc_type="Compliance"),
                        "Verifying the internal only doc uploaded in the client event")

        # Navigate to OsC Entity tab for Customer
        self.assertTrue(OsCNavigation.navigate_to_entity("United States"),
                        "Navigation to US entity")

        self.assertTrue(OsCDashboardPage.document_search(name=first_upload_file_name,
                                                         app="Compliance"),
                        "Searching for client event uploaded doc")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=first_upload_file_name,
                                                             permission_icon="blank",
                                                             doc_type="Compliance"),
                        "Verifying the client event doc")

        self.assertTrue(OsCDashboardPage.document_search(name=second_upload_file_name,
                                                         app="Compliance"),
                        "Searching for internal only client event doc")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=second_upload_file_name,
                                                             permission_icon="internal",
                                                             doc_type="Compliance"),
                        "Verifying internal only doc")

        # Navigate to OsC other Entity tab for Customer - Doc not found
        self.assertTrue(OsCNavigation.navigate_to_entity("United Kingdom"),
                        "Navigation to UK entity")

        self.assertTrue(OsCDashboardPage.document_search(name=first_upload_file_name,
                                                         app="Compliance"),
                        "Searching for client event doc")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name="AUTO_ENV.txt",
                                                             permission_icon="blank",
                                                             doc_type="Compliance",
                                                             expect_results=False),
                        "Verifying client event doc isn't found")

        # Login as External User
        Driver.restart_browser()
        self.assertTrue(LoginPage.go_to(user_type="external"),
                        "Navigation to OsC external user login")
        self.assertTrue(LoginPage.login("Auto_Payroll_Admin", "Password1"),
                        "Log in as external user")

        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "Arrived at OsC dashboard")

        self.assertTrue(OsCNavigation.navigate_to_entity("United States"),
                        "Navigation to US entity")

        self.assertTrue(OsCDashboardPage.document_search(name=first_upload_file_name,
                                                         app="Compliance"),
                        "Searching for client event uploaded doc")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=first_upload_file_name,
                                                             permission_icon="blank",
                                                             doc_type="Compliance"),
                        "Verifying client event uploaded doc")

        self.assertTrue(OsCDashboardPage.document_search(name=second_upload_file_name,
                                                         app="Compliance"),
                        "Searching for internal only client event doc")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=second_upload_file_name,
                                                             permission_icon="internal",
                                                             doc_type="Compliance",
                                                             expect_results=False),
                        "Verifying internal only doc is not seen by the external user")

        # TC#2 Uploading doc in OsC >> Not available in CT
        Driver.restart_browser()
        self.assertTrue(LoginPage.go_to("internal"),
                        "Login as internal user")

        # Navigate to OsC Global tab for Customer
        self.assertTrue(OsCNavigation.change_client("QA Payroll Automation Customer"),
                        "Navigation to client")
        self.assertTrue(OsCNavigation.navigate_to_entity("United States"),
                        "Navigation to US entity")
        docs = list()
        docs.append(third_upload_file_path)
        self.assertTrue(OsCDashboardPage.upload_docs(doc_type="Compliance",
                                                     application="Compliance",
                                                     docs=docs),
                        "OsC file upload")

        self.assertTrue(HomePage.go_to_homepage(), "Navigation to the CT homepage")

        self.assertTrue(HomePage.go_to_client_events(), "Navigation to the Client Events page")

        self.assertTrue(ClientEventsPage.select_overview_result(), "Overview Search")

        self.assertTrue(ClientEventsPage.select_client_event(event_filter, occurrence=True),
                        "Selecting the client event")

        self.assertTrue(ClientEventsPage.verify_file(third_upload_file_name, expect_results=False),
                        "Verifying the file uploaded is not seen in the client event")

        # TC#3 - Delete doc in CT >> Not available in OSC

        # Navigate to CT Client Events List page
        # self.assertTrue(HomePage.go_to_homepage(), "Navigation to the CT homepage")
        #
        # self.assertTrue(HomePage.go_to_client_events(), "Navigation to the Client Events page")
        #
        # self.assertTrue(ClientEventsPage.select_overview_result(), "Overview Search")
        #
        # ClientEventsPage.select_client_event(event_filter, occurrence=True)

        # Deleting uploaded file in CT
        ClientEventsPage.delete_file(first_upload_file_name)

        ClientEventsPage.close_client_event_details()

        LoginPage.go_to("internal")

        # Navigate to OsC Global tab for Customer
        self.assertTrue(OsCNavigation.change_client("QA Payroll Automation Customer"),
                        "Navigation to client")

        self.assertTrue(OsCDashboardPage.document_search(name=first_upload_file_name,
                                                         app="Compliance",
                                                         country="United States"),
                        "Searching for deleted doc")

        Driver.hard_wait(2)
        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=first_upload_file_name,
                                                             permission_icon="blank",
                                                             doc_type="Compliance",
                                                             expect_results=False),
                        "Verifying deleted doc not found")

        # Navigate to OsC Entity tab for Customer
        self.assertTrue(OsCNavigation.navigate_to_entity("United States"),
                        "Navigation to US entity")

        self.assertTrue(OsCDashboardPage.document_search(name=first_upload_file_name,
                                                         app="Compliance"),
                        "Searching for deleted doc")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=first_upload_file_name,
                                                             permission_icon="blank",
                                                             doc_type="Compliance",
                                                             expect_results=False),
                        "Verifying deleted doc not found")

    # TC#4 - Delete event in CT >> Doc not available in OSC
        # Navigate to CT Client Events List page
        self.assertTrue(HomePage.go_to_homepage(), "Navigation to the CT homepage")

        self.assertTrue(HomePage.go_to_client_events(), "Navigation to the Client Events page")

        self.assertTrue(ClientEventsPage.select_overview_result(), "Overview Search")

        self.assertTrue(ClientEventsPage.select_client_event(event_filter, occurrence=True),
                        "Selecting client event")

        self.assertTrue(ClientEventsPage.upload_doc(doc_type="Compliance",
                                                    doc_date="10/05/2017",
                                                    permission="shared",
                                                    file=first_upload_file_path),
                        "Uploading shared doc in client event")

        self.assertTrue(ClientEventsPage.verify_file(first_upload_file_name),
                        "Verifying the file uploaded in the client event")

        self.assertTrue(ClientEventsPage.close_client_event_details(),
                        "Closing client event")

        # Deleting Client Event
        self.assertTrue(ClientEventsPage.delete_client_event(event_filter),
                        "Deleting the client event")

        self.assertTrue(LoginPage.go_to("internal"),
                        "Returning to OsC")

        # Navigate to OsC Global tab for Customer
        self.assertTrue(OsCNavigation.change_client("QA Payroll Automation Customer"),
                        "Navigation to client")

        self.assertTrue(OsCDashboardPage.document_search(name=first_upload_file_name,
                                                         app="Compliance",
                                                         country="United States"),
                        "Searching for doc from the deleted client event")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=first_upload_file_name,
                                                             permission_icon="blank",
                                                             doc_type="Compliance",
                                                             expect_results=False),
                        "Verifying doc from deleted client event is not found")

        # Navigate to OsC Entity tab for Customer
        self.assertTrue(OsCNavigation.navigate_to_entity("United States"),
                        "Navigation to US entity")

        self.assertTrue(OsCDashboardPage.document_search(name=first_upload_file_name,
                                                         app="Compliance"),
                        "Searching for doc from the deleted client event")

        self.assertTrue(OsCDashboardPage.verify_uploaded_doc(name=first_upload_file_name,
                                                             permission_icon="blank",
                                                             doc_type="Compliance",
                                                             expect_results=False),
                        "Verifying doc from deleted client event is not found")

        # def test_some_test(self):
        #  pass

    # TC1 - Upload doc in CT >> Available in OSC Global & Entity. Not available for other Entity.
        # Go to CT >> Client Events. (Internal User)
        # Go to Countries tab. Search for Australia in Client Events Overview Screen.
        # Go to Client Events List Screen by clicking on the Australia
        # Perform Advanced Search - Client Entity = A10 Networks, Country = Australia, Status = Completed, FY = 2017.
        # Verify docs icon avb next to client events record.
        # Click to open any client event occurrence with docs attached. Copy the document name.
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Global >> Docs section.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Entity >> Docs section.
        # Go to OsC >> A10 Networks >> India >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is not available in OsC Entity >> Docs section.

    # TC2 - Upload doc in OsC >> Not available in CT.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Click on Upload button.
        # Upload a document for Country = Australia, Application = Compliance, Doc Type = Compliance
        # Doc upload is successful.
        # Go to CT >> Client Events. (Internal User)
        # Go to Countries tab. Search for Australia in Client Events Overview Screen.
        # Go to Client Events List Screen by clicking on the Australia
        # Perform Advanced Search - Client Entity = A10 Networks, Country = Australia, Status = Completed, FY = 2017.
        # Verify docs icon avb next to client events record.
        # Click to open any client event occurrence with docs attached.
        # Verify that the document attached in OsC is not available in the client event occurrence.

    # TC3 - Delete doc in CT >> Not available in OSC Global & Entity.
        # Go to CT >> Client Events. (Internal User)
        # Go to Countries tab. Search for Australia in Client Events Overview Screen.
        # Go to Client Events List Screen by clicking on the Australia
        # Perform Advanced Search - Client Entity = A10 Networks, Country = Australia, Status = Completed, FY = 2017.
        # Verify docs icon avb next to client events record.
        # Click to open any client event occurrence with docs attached. Copy the document name.
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Global >> Docs section.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Entity >> Docs section.
        # Go to CT >> Client Events >> Occurrence. Delete the attached doc. (Internal User)
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is not available in OsC Global >> Docs section.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is not available in OsC Australia >> Docs section.

    # TC4 - Delete event in CT >> Doc not available in OSC Global & Entity.
        # Go to CT >> Client Events. (Internal User)
        # Go to Countries tab. Search for Australia in Client Events Overview Screen.
        # Go to Client Events List Screen by clicking on the Australia
        # Add Client Event for Client-Entity = A10 Networks, Country = Australia, FY = 2017.
        # Perform Advanced Search - Client Entity = A10 Networks, Country = Australia, Status = Open, FY = 2017.
        # Verify that the newly added client event is available in the list.
        # Click to open client event occurrence & attach doc - Doc Type = Compliance, Doc Date = Any,
        #   Permission = Shared.
        # Copy the document name.
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Global >> Docs section.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Entity >> Docs section.
        # Go to CT >> Client Events >> Occurrence. Delete the newly added event. (Internal User)
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is not available in OsC Global >> Docs section.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is not available in OsC Australia >> Docs section.

    # TC5 - Internal docs - Internal Users only "lock", External Users - not available.
        # Go to CT >> Client Events. (Internal User)
        # Go to Countries tab. Search for Australia in Client Events Overview Screen.
        # Go to Client Events List Screen by clicking on the Australia
        # Add Client Event for Client-Entity = A10 Networks, Country = Australia, FY = 2017.
        # Perform Advanced Search - Client Entity = A10 Networks, Country = Australia, Status = Open, FY = 2017.
        # Verify that the newly added client event is available in the list.
        # Click to open client event occurrence & attach doc - Doc Type = Compliance,
        #   Doc Date = Any, Permission = Radius Internal.
        # Copy the document name.
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Global >> Docs section with a lock sign.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Entity >> Docs section with a lock sign.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section.(External User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is not available in OsC Global >> Docs section.

    # TC6 - Shared docs - Internal Users & External Users, no lock.
        # Go to CT >> Client Events. (Internal User)
        # Go to Countries tab. Search for Australia in Client Events Overview Screen.
        # Go to Client Events List Screen by clicking on the Australia
        # Add Client Event for Client-Entity = A10 Networks, Country = Australia, FY = 2017.
        # Perform Advanced Search - Client Entity = A10 Networks, Country = Australia, Status = Open, FY = 2017.
        # Verify that the newly added client event is available in the list.
        # Click to open client event occurrence & attach doc - Doc Type = Compliance,
        #   Doc Date = Any, Permission = Shared.
        # Copy the document name.
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Global >> Docs section without a lock sign.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Entity >> Docs section without a lock sign.
        # Go to OsC >> A10 Networks >> Global >> Documents Section.(External User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Global >> Docs section without a lock sign.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (External User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Entity >> Docs section without a lock sign.

    # TC7 - Hiding Compliance Group – Earlier available doc should not be available in
        #   OsC Global & Entity but is available in CT.
        # Go to CT >> Client Events. (Internal User)
        # Go to Countries tab. Search for Australia in Client Events Overview Screen.
        # Go to Client Events List Screen by clicking on the Australia
        # Perform Advanced Search - Client Entity = A10 Networks, Country = Australia, Status = Completed, FY = 2017.
        # Verify docs icon avb next to client events record.
        # Click to open any client event occurrence with docs attached. Copy the document name.
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Global >> Docs section.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is available in OsC Entity >> Docs section.
        # Go to CT >> Compliance Groups. Hide the CG of the doc attached event. (Internal User)
        # Go to CT >> Client Events. (Internal User)
        # Go to Countries tab. Search for Australia in Client Events Overview Screen.
        # Go to Client Events List Screen by clicking on the Australia
        # Perform Advanced Search - Client Entity = A10 Networks, Country = Australia, Status = Completed, FY = 2017.
        # Verify docs symbol avb next to client events record considered earlier.
        # Click to open client event occurrence. Doc should be avb. Copy the document name.
        # Go to OsC >> A10 Networks >> Global >> Documents Section. (Internal User)
        # Perform search in Docs - Country = Australia, App = Compliance, Search = paste the copied doc name.
        # Verify that the document is not available in OsC Global >> Docs section.
        # Go to OsC >> A10 Networks >> Australia >> Documents Section. (Internal User)
        # Perform search in Docs - App = Compliance, Search = paste the copied doc name.
        # Verify that the document is not available in OsC Australia >> Docs section.

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(OscCtDocs, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
