import unittest
import subprocess
from Framework.Utilities.Environment import Environment
from Framework.Utilities.Driver import Driver
#from Framework.Utilities.DatabaseManager import DatabaseManager
from ddt import ddt


@ddt
class BaseTest(unittest.TestCase):

    def __init__(self, method_name='runTest', env=None, browser=None, ws=None):
        super(BaseTest, self).__init__(method_name)
        self.env = env
        self.browser = browser
        self.ws = ws

    def setUp(self):
        pass

    def tearDown(self):
        # subprocess.call('cmdkey.exe /delete:adfs.hsp.com')
        # subprocess.call('cmdkey.exe /delete:adfs.nairco.loc')
        Driver.quit()

    # @staticmethod
    # def begin(env, browser="chrome"):
    #     Environment.setup(env=env)
    #     Driver.setup(browser)
    #     DatabaseManager.setup(Environment.get_url_env())
    @staticmethod
    def begin(browser="chrome"):
        Driver.setup(browser)



    @staticmethod
    def parametrize(testcase_klass, env=None, browser=None, ws=None):
        """ Create a suite containing all tests taken from the given
            subclass, passing them the parameter 'param'.
        """
        testloader = unittest.TestLoader()
        testnames = testloader.getTestCaseNames(testcase_klass)
        suite = unittest.TestSuite()
        for name in testnames:
            suite.addTest(testcase_klass(name, env=env, browser=browser, ws=ws))
        return suite

    def assertTrue(self, expr, msg="", pass_msg=""):
        if hasattr(self, 'parent_test'):
            test_name = self.parent_test
        else:
            test_name = self._testMethodName

        if pass_msg == "":
            pass_msg = msg
        if not expr:
            ss = self.ws + "\\" + test_name + ".png"
            Driver.failure(msg, ss=ss)
            raise self.failureException(msg)
        else:
            Driver.success(pass_msg)

    def assertTrue1(self, expr, element,msg="", pass_msg=""):
        if hasattr(self, 'parent_test'):
            test_name = self.parent_test
        else:
            test_name = self._testMethodName

        if pass_msg == "":
            pass_msg = msg
        if not expr:
            ss = self.ws + "\\" + test_name + ".png"
            Driver.failure1(msg,element, ss=ss)
            raise self.failureException(msg)
        else:
            Driver.success(pass_msg)

    def assertFalse(self, expr, msg="", pass_msg=""):
        self.assertTrue(not expr, msg, pass_msg)

    def assertIsNotNone(self, expr, msg="", pass_msg=""):
        self.assertTrue(expr is not None, msg, pass_msg)
