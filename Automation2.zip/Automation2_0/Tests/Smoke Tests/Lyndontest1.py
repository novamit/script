import unittest
import sys
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Framework.Utilities.Driver import Driver
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Pages.SecurityAdminPages.UsersPage import UsersPage
from Framework.Utilities.DummyDataGenerator import DummyDataGenerator
from Framework.Pages.SecurityAdminPages.RolesPage import RolesPage

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class Lyndontest1(BaseTest):
    def setUp(self):
        global environment_flag
        global browser_flag
        username = "automationadmin"
        password = "Password0"
        super(Lyndontest1, self).begin(environment_flag, browser_flag)

        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "External OsC user login")

    def tearDown(self):
        super(Lyndontest1, self).tearDown()

    def test_role_lyndon(self):
        role_name = "QAR_" + DummyDataGenerator.random_name()
        role_description = DummyDataGenerator.random_name()

        rights = list()
        rights.append(["Financials", "Documents", "Upload Documents"])
        rights.append(["Expenses", "Documents", "View Only"])

        self.assertTrue(OsCDashboardPage.navigate_to_sec_admin(),
                        "Navigation to security admin")
        self.assertTrue(RolesPage.navigate_to_roles(),
                        "Navigation to roles section")

        result = RolesPage.create(role_name=role_name,
                                  description=role_description,
                                  rights=rights)

        self.assertTrue(result,
                        "Role creation")

        # Search for role and verify it returns
        self.assertTrue(RolesPage.search_for_role(role_name),
                        "Search for role")

        self.create_user_lyndon(role_name)

    def create_user_lyndon(self, role_name):
        first_name = DummyDataGenerator.random_name()
        last_name = DummyDataGenerator.random_name()
        username = first_name + last_name
        email = "sleboeuf@hsp.com"  # Needed because of white list stuff blocking welcome emails
        office_number = DummyDataGenerator.random_number()
        mobile_number = DummyDataGenerator.random_number()
        skype_id = DummyDataGenerator.random_name()

        roles_dict = dict()
        roles_dict["Wildcard_Choice"] = "DiffRolesDiffEntities"
        roles_dict["Entity_Roles"] = dict()
        roles_dict["Entity_Roles"]["United States"] = [role_name]

        # Navigate to Sec Admin. Defaults to Users section
        # self.assertTrue(OsCDashboardPage.navigate_to_sec_admin(),
        #                "Navigation to security admin")

        self.assertTrue(RolesPage.navigate_to_users(),
                        "Navigation to users sections")

        result = UsersPage.create_user(username=username,
                                       first_name=first_name,
                                       last_name=last_name,
                                       email=email,
                                       office_number=office_number,
                                       mobile_number=mobile_number,
                                       skype=skype_id,
                                       roles=roles_dict)

        self.assertTrue(result,
                        "Creation of user")

        # Search for user and verify it returns
        Driver.hard_wait(1)
        self.assertTrue(UsersPage.search_for_user(username),
                        "User found in search")

        self.assertTrue(UsersPage.delete_top_user(),
                        "Deletion of user")

        # Search for user and verify it does not return
        self.assertTrue(UsersPage.search_for_user(username, results=False),
                        "Search for deleted user")

        # Navigate to roles again
        self.assertTrue(RolesPage.navigate_to_roles(),
                        "Navigation to roles section")

        # Search for role and verify it returns
        self.assertTrue(RolesPage.search_for_role(role_name),
                        "Search for role")

        self.assertTrue(RolesPage.delete_top_role(),
                        "Role deletion")

        # Search for role and verify it does not return
        self.assertTrue(RolesPage.search_for_role(role_name, results=False),
                        "Search for deleted role")



# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(Lyndontest1, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
