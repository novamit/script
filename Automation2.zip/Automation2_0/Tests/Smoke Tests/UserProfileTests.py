import unittest
import sys
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Framework.Utilities.DummyDataGenerator import DummyDataGenerator
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Pages.SecurityAdminPages.UserProfilePage import UserProfilePage

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class UserProfileTests(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        self.username = "stevenewuser"
        self.password = "Password1"
        super(UserProfileTests, self).begin(environment_flag, browser_flag)

        LoginPage.go_to()
        LoginPage.login(username=self.username, password=self.password)

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "External OsC user login")

        UserProfilePage.set_user_id(self.username)

    def tearDown(self):
        """ Closes the browser """
        super(UserProfileTests, self).tearDown()

    def test_user_info_edit(self):

        # Navigate to the user profile tab
        self.assertTrue(OsCDashboardPage.navigate_to_user_profile(),
                        "Navigation to the user profile section")

        email = DummyDataGenerator.random_name() + DummyDataGenerator.current_datetime() + \
            DummyDataGenerator.random_email_suffix()

        result = UserProfilePage.edit_user_info(first_name=DummyDataGenerator.random_name(),
                                                last_name=DummyDataGenerator.random_name(),
                                                username="EDT_" + self.username,
                                                email=email,
                                                job_title=DummyDataGenerator.random_title(),
                                                office_number=DummyDataGenerator.random_number(),
                                                mobile_number=DummyDataGenerator.random_number(),
                                                skype=DummyDataGenerator.random_name())
        self.assertTrue(result,
                        "User update")

        self.assertTrue(UserProfilePage.edit_username(self.username),
                        "Username reset")

    def test_user_password_edit(self):
        old_password = "Password1"
        new_password = "Password0"

        # Navigate to the user profile tab
        self.assertTrue(OsCDashboardPage.navigate_to_user_profile(),
                        "Navigation to the user profile section")

        self.assertTrue(UserProfilePage.change_password(old_password=old_password, new_password=new_password),
                        "Password update")

        self.assertTrue(UserProfilePage.change_password(old_password=new_password, new_password=old_password),
                        "Password reset")

    def test_user_question_edit(self):

        # Navigate to the user profile tab
        self.assertTrue(OsCDashboardPage.navigate_to_user_profile(),
                        "Navigation to the user profile section")

        result = UserProfilePage.change_question(DummyDataGenerator.random_title())

        self.assertTrue(result,
                        "Question update")

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(UserProfileTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
