import sys
import unittest
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.NextgenPages.NextgenExpensePage import NextgenExpensePage
from Framework.Pages.OsCPages.OsCExpensePage import OsCExpensePage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Utilities.DatabaseManager import DatabaseManager
from Framework.Utilities.Driver import Driver
from Framework.Utilities.Environment import Environment
from Tests.BaseTest import BaseTest

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class ExpenseConfigTests(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        username = "automationadmin"
        password = "Password0"
        super(ExpenseConfigTests, self).begin(environment_flag, browser_flag)

        self.db_env = Environment.get_db_env()

        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify if the browser loads into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "External OsC user login")

    def tearDown(self):

        super(ExpenseConfigTests, self).tearDown()

    def test_expense_config(self):

        vat_location = "United States"
        gl_account = "12345"
        exp_type_name = "Breakfast"

        p_approver_1 = "Automation Admin"
        b_approver_1 = "boin boin"

        # Navigate to an entity's expense tab
        # self.assertTrue(OsCNavigation.navigate_to_entity("United Kingdom"),
        #                 "Navigation to UK entity")
        self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name="United Kingdom"),
                        "Navigation to the UK Entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_EXPENSES),
                        "Navigation to the Expenses application")

        # Click the expense config button
        self.assertTrue(OsCExpensePage.navigate_to_expense_config(),
                        "Open expense config")

        # Go to vat section and make an edit
        self.assertTrue(NextgenExpensePage.go_to_vat(),
                        "Navigation to the vat section")
        Driver.hard_wait(3)

        update_result = NextgenExpensePage.vat_update(location=vat_location,
                                                      indirect_tax=True,
                                                      gl_account=gl_account)
        self.assertTrue(update_result,
                        "VAT update")

        self.assertTrue(NextgenExpensePage.vat_save(),
                        "Save vat section")

        vat_db_data = NextgenExpensePage.vat_db_data()

        for row in vat_db_data:
            if vat_location in row[0]:
                self.assertTrue(row[1],
                                "DB validation of indirect tax enabled")
                self.assertTrue(gl_account in (row[3] + " : " + row[4]),
                                "DB validation of selected gl account")
                break

        # Reset vat
        update_result = NextgenExpensePage.vat_update(location=vat_location,
                                                      indirect_tax=False,
                                                      gl_account=gl_account)

        self.assertTrue(update_result,
                        "VAT reset update")

        self.assertTrue(NextgenExpensePage.vat_save(),
                        "Save vat section")

        vat_db_data = NextgenExpensePage.vat_db_data()

        for row in vat_db_data:
            if vat_location in row[0]:
                self.assertFalse(row[1],
                                 "DB validation of indirect tax disabled")
                break

        # Go to expense types section and make an edit
        self.assertTrue(NextgenExpensePage.go_to_exp_types(),
                        "Navigation to the exp types section")

        result = NextgenExpensePage.exp_type_update(gl_account=gl_account,
                                                    exp_type=exp_type_name)
        self.assertTrue(result,
                        "Update exp types")

        self.assertTrue(NextgenExpensePage.exp_type_save(),
                        "Save exp type section")

        exp_type_db_data = NextgenExpensePage.exp_type_db_data()
        for row in exp_type_db_data:

            if exp_type_name in row[0]:
                self.assertTrue(gl_account in (row[1] + " : " + row[2]),
                                "DB validation of expense type update")
                break

        result = NextgenExpensePage.exp_type_update(gl_account="Not Used",
                                                    exp_type="Breakfast")
        self.assertTrue(result,
                        "Update exp types")

        self.assertTrue(NextgenExpensePage.exp_type_save(),
                        "Save exp type section after reset")

        # Go to edit approvers section and change approvers. Then change them back
        self.assertTrue(NextgenExpensePage.go_to_approvers(),
                        "Navigation to approvers section")

        result = NextgenExpensePage.primary_approver_update(location="All",
                                                            primary_approver=p_approver_1)
        self.assertTrue(result,
                        "Primary approver update")

        # Remove all backup approvers
        result = NextgenExpensePage.backup_approver_remove(location="All",
                                                           backup_approver="All")
        self.assertTrue(result,
                        "Backup approver removal")

        Driver.hard_wait(3)
        # Add backup approver
        result = NextgenExpensePage.backup_approver_add(backup_approver=b_approver_1)
        self.assertTrue(result,
                        "Backup approver update")

        self.assertTrue(NextgenExpensePage.approver_save(),
                        "Approver section save")

        db_env = Environment.get_db_env()
        db_name = "Main%s" % db_env
        query = """Select Id
            From Person
            Where FirstName='%s' and LastName='%s'"""

        split_name = p_approver_1.split(" ")
        p_person_id = DatabaseManager.fetchall_query(query % (split_name[0], split_name[1]), db_name)[0][0]

        split_name = b_approver_1.split(" ")
        b_person_id = DatabaseManager.fetchall_query(query % (split_name[0], split_name[1]), db_name)[0][0]

        db_name = "Identity%s" % db_env
        query = """Select Id
            From [User]
            Where PersonId=%s"""

        p_user_id = DatabaseManager.fetchall_query(query % p_person_id, db_name)[0][0]
        b_user_id = DatabaseManager.fetchall_query(query % b_person_id, db_name)[0][0]

        db_name = "ExpenseReporting%s" % db_env
        query = """select distinct SecurityPersonId, ApproverOrder
            from CustomerEntityExpenseApprover
            where CustomerEntityId in
                (select Id from CustomerEntity where CustomerId=%s)""" % NextgenExpensePage.get_exp_customer_id()

        fetchall = DatabaseManager.fetchall_query(query, db_name)

        for row in fetchall:

            if row[1] == 1:
                self.assertTrue(p_user_id == row[0],
                                "DB validation of primary approver update")
            else:
                self.assertTrue(b_user_id == row[0],
                                "DB validation of backup approver update")

        # Reset Approvers
        result = NextgenExpensePage.primary_approver_update(location="All",
                                                            primary_approver="new user")
        self.assertTrue(result, "Primary approver update")

        # Remove all backup approvers
        result = NextgenExpensePage.backup_approver_remove(location="All",
                                                           backup_approver="All")
        self.assertTrue(result, "Backup approver removal")

        Driver.hard_wait(3)
        # Add backup approver
        result = NextgenExpensePage.backup_approver_add(backup_approver="new person")
        self.assertTrue(result,
                        "Backup approver update")

        self.assertTrue(NextgenExpensePage.approver_save(),
                        "Unable to save approver section")

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(ExpenseConfigTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
