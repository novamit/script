import sys
import unittest
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCExpensePage import OsCExpensePage
from Tests.BaseTest import BaseTest

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class NexoniaSSOTests(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        username = "stevetest11"
        password = "Password1"
        super(NexoniaSSOTests, self).begin(self.env, self.browser)

        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify that you load into OsC
        self.assertTrue(OsCExpensePage.is_at_dashboard(),
                        "External OsC user login")

    def tearDown(self):
        """ Closes the browser """
        super(NexoniaSSOTests, self).tearDown()

    def test_nexonia_sso(self):
        # Navigate to an entity's expense tab
        # self.assertTrue(OsCNavigation.navigate_to_entity("AU"),
        #                 "Navigation to AU entity")
        self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name="AU"),
                        "Navigation to the AU Entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_EXPENSES),
                        "Navigation to the Expenses application")

        # Verify that you made it to nexonia
        if self.env == 'prod':
            self.assertTrue(OsCExpensePage.launch_expense_reporting(),
                            "Nexonia SSO")
        else:
            self.assertTrue(OsCExpensePage.launch_expense_reporting(login_success=False),
                            "Nexonia SSO")

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(NexoniaSSOTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
