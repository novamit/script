import unittest
import sys
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Framework.Utilities.Driver import Driver
from Framework.Pages.LoginPage import LoginPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Pages.OsCPages.OsCHrPage import OsCHrPage
from Framework.Pages.NextgenPages.ReportsPage import ReportsPage

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class ReportsTests(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        username = "stevetest11"
        password = "Password1"
        super(ReportsTests, self).begin(environment_flag, browser_flag)

        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "External OsC user login")

    def tearDown(self):
        """ Closes the browser """
        super(ReportsTests, self).tearDown()

    def test_report_smoke(self):

        # self.assertTrue(OsCNavigation.navigate_to_entity("United Kingdom"),
        #                 "Navigation to UK entity")
        self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name="United Kingdom"),
                        "Navigation to the UK Entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_HR),
                        "Navigation to the Hr application")

        self.assertTrue(OsCHrPage.navigate_to_reports(),
                        "Loading reports page")

        result = ReportsPage.view_report(report=ReportsPage.Reports.HR_CENSUS,
                                         period=ReportsPage.Period.CUSTOM_DATES,
                                         from_date="08/31/2010",
                                         to_date="08/31/2015")

        self.assertTrue(result,
                        "Loading HR Census report")

    def report_all(self):
        success_flag = True

        # self.assertTrue(OsCNavigation.navigate_to_entity("US"),
        #                 "Navigation to US entity")
        self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name="US"),
                        "Navigation to the US Entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_HR),
                        "Navigation to the Hr application")

        self.assertTrue(OsCHrPage.navigate_to_reports(),
                        "Loading reports page")

        for report in ReportsPage.Reports.LIST:

            result = ReportsPage.view_report(report=ReportsPage.Reports.HR_CENSUS,
                                             payroll_definition="Salaried Employees",
                                             period=ReportsPage.Period.CUSTOM_DATES,
                                             from_date="08/31/2010",
                                             to_date="08/31/2015")
            if result:
                Driver.success("No errors seen for %s" % report)
            else:
                success_flag = False
                Driver.failure("failed to load %s" + report)

            self.assertTrue(ReportsPage.return_to_report_list(),
                            "Return to report list")

        self.assertTrue(success_flag,
                        "One or more reports failed to load",
                        "All reports loaded successfully")

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(ReportsTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
