import unittest
import sys
import os
import json
from Tests.BaseTest import BaseTest
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Pages.DxpPlatformPages.LoginPage import LoginPage
from Framework.Pages.DxpPlatformPages.VistraApplicationsPage import VistraApplicationsPage
from Framework.Pages.DxpPlatformPages.MyFundsPages.MyFundsNavigation import MyFundsNavigation
from ddt import ddt, file_data

environment_flag = "prod"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


@ddt
class MyFundsLoginTests(BaseTest):
    json = "C:\\QA\\Automation2_0\\Tests\\MyFundsTests\\Data\\Users_MyFunds.json"
    json_sl = "C:\\QA\\Automation2_0\\Tests\\MyFundsTests\\Data\\vFundsUsers.json"

    def setUp(self):
        global environment_flag
        global browser_flag
        super(MyFundsLoginTests, self).begin(environment_flag, browser_flag)

    # TODO: SL Note - The workflow for logging in is the same regardless of user type. We can just use one test that
    # TODO: loops through the json data of users available in the environment
    @file_data(json)
    def est_admin_user_login(self, value):

        if environment_flag == 'prod':
            user_details = value["Prod_Users"]["admin"]
        else:
            user_details = value["QA_Users"]["admin"]
        username = user_details["username"]
        password = user_details["password"]
        environment = environment_flag

        # Navigate to the My Funds login page
        self.assertTrue(LoginPage.go_to(),
                        "Navigated to the My Funds Login page")

        # Login to My Funds
        self.assertTrue(LoginPage.login(username=username, password=password, environment=environment),
                        "Logged in as Admin user")

        # Enter 2FA code
        self.assertTrue(LoginPage.enter_2fa_code(environment=environment, username=username),
                        "Entered 2FA code successfully")

        # Verify if at application page
        self.assertTrue(VistraApplicationsPage.is_at(),
                        "Navigated to Vistra Applications page")

        # Logout as Fund Manager user
        self.assertTrue(MyFundsNavigation.sign_out(),
                        "Logged out from My Funds")

    @file_data(json)
    def est_multi_investor_user_login(self, value):

        if environment_flag == 'prod':
            user_details = value["Prod_Users"]["multiinvestor"]
        else:
            user_details = value["QA_Users"]["multiinvestor"]

        username = user_details["username"]
        password = user_details["password"]
        environment = environment_flag
        # Navigate to the My Funds login page
        self.assertTrue(LoginPage.go_to(),
                        "Navigated to the My Funds Login page")

        # Login to My Funds
        self.assertTrue(LoginPage.login(username=username, password=password, environment=environment),
                        "Logged in as Mini Fund user")

        # Enter 2FA code
        self.assertTrue(LoginPage.enter_2fa_code(environment=environment, username=username),
                        "Entered 2FA code successfully")

        # Verify if at application page
        self.assertTrue(VistraApplicationsPage.is_at(),
                        "Navigated to Vistra Applications page")

        # Logout from My Funds
        self.assertTrue(MyFundsNavigation.sign_out(),
                        "Logged out from My Funds")

    # TODO: SL Edit - See notes above. Below test is environment and user agnostic.
    @file_data(json_sl)
    def test_user_login(self, value):
        username = value["username"]
        password = value["password"]

        if environment_flag in value["envs"]:
            # Navigate to the My Funds login page
            self.assertTrue(LoginPage.go_to(),
                            "Navigated to the My Funds Login page")

            # Login to My Funds
            self.assertTrue(LoginPage.login(username=username, password=password),
                            "Logged in as Admin user")

            # Enter 2FA code
            self.assertTrue(LoginPage.enter_2fa_code(username=username),
                            "Entered 2FA code successfully")

            # Verify if at application page
            self.assertTrue(VistraApplicationsPage.is_at(),
                            "Navigated to Vistra Applications page")

            # Logout as Fund Manager user
            self.assertTrue(MyFundsNavigation.sign_out(),
                            "Logged out from My Funds")
        else:
            self.assertTrue(True,
                            "%s not available in %s env" % (value["username"], environment_flag))

    def test_fail_user_login(self):
        username = "username"
        password = "password"

        # Navigate to the My Funds login page
        self.assertTrue(LoginPage.go_to(),
                        "Navigated to the My Funds Login page")

        # Attempt to login to My Funds
        self.assertFalse(LoginPage.login(username=username, password=password),
                         "Login failed due to incorrect credentials")

    def tearDown(self):
        """ Closes the browser """
        super(MyFundsLoginTests, self).tearDown()


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(MyFundsLoginTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
