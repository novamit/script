import unittest
import sys
import os
from Framework.Utilities.Driver import Driver
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from ddt import ddt, file_data

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


@ddt
class UploadTests(BaseTest):

    json_file = "Data/Upload_Files.json"

    def setUp(self):
        global environment_flag
        global browser_flag
        username = "automationadmin"
        password = "Password0"
        super(UploadTests, self).begin(environment_flag, browser_flag)

        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "External OsC user login")

    def tearDown(self):
        """ Closes the browser """
        super(UploadTests, self).tearDown()

    @file_data(json_file)
    def test_allowed_upload(self, value):

        file_folder = value["File_Folder"]
        allowed_files = value["Allowed_Files"]
        file_types = allowed_files.keys()

        # self.assertTrue(OsCNavigation.navigate_to_entity("United Kingdom"),
        #                 "Navigation to UK entity")
        self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name="United Kingdom"),
                        "Navigation to the UK Entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_ADVISORY),
                        "Navigation to the Advisory application")
        pass_flag = True
        for file_type in file_types:
            docs = list()
            if file_type in 'foreign_chars':
                allowed_files[file_type] = "foreign_charsääü.doc"
            docs.append(file_folder + allowed_files[file_type])

            upload_result = OsCDashboardPage.upload_docs(doc_type="Advisory",
                                                         docs=docs)

            if upload_result:
                Driver.success(file_type + " upload")
                Driver.hard_wait(2)
                verify_result = OsCDashboardPage.verify_doc_download(allowed_files[file_type])
                if verify_result is not None:
                    Driver.success(file_type + " download")
                else:
                    Driver.failure(file_type + " download")
                    pass_flag = False

                delete_result = OsCDashboardPage.delete_document(allowed_files[file_type])
                if delete_result:
                    Driver.success(file_type + " deletion")
                else:
                    Driver.failure(file_type + " deletion")
                    pass_flag = False
            else:
                Driver.failure(file_type + " upload")
                pass_flag = False
            # self.assertTrue(upload_result,
            #                 file_type + " upload")

            # Driver.hard_wait(2)
            #
            # self.assertIsNotNone(OsCDashboardPage.verify_doc_download(allowed_files[file_type]),
            #                      file_type + " download")
            #
            #
            # self.assertTrue(delete_result,
            #                 file_type + " deletion")
        self.assertTrue(pass_flag, "One or more file type uploads failed", "All file uploads")

    @file_data(json_file)
    def test_restricted_upload(self, value):

        file_folder = value["File_Folder"]
        restricted_files = value["Restricted_Files"]
        file_types = restricted_files.keys()

        # self.assertTrue(OsCNavigation.navigate_to_entity("United Kingdom"),
        #                 "Navigation to UK entity")
        self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name="United Kingdom"),
                        "Navigation to the UK Entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_ADVISORY),
                        "Navigation to the Advisory application")

        pass_flag = True
        for file_type in file_types:

            docs = list()
            docs.append(file_folder + restricted_files[file_type])

            upload_result = OsCDashboardPage.upload_docs(doc_type="Advisory",
                                                         docs=docs,
                                                         success=False)
            if upload_result:
                Driver.success("Restrict upload of doc type %s" % file_type)
            else:
                pass_flag = False
                Driver.failure(file_type + " file uploaded successfully")
                delete_result = OsCDashboardPage.delete_document(restricted_files[file_type])
                if delete_result:
                    Driver.success(file_type + " deletion")
                else:
                    Driver.failure(file_type + " deletion")

        self.assertTrue(pass_flag, "One or more restricted file types uploaded successfully", "All files restricted")


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(UploadTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
