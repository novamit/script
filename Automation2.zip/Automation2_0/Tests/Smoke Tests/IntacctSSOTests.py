import unittest
import sys
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.FinancialsPage import FinancialsPage
from Framework.Navigation.OsCNavigation import OsCNavigation

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class IntacctSSOTests(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        username = "stevetest11"
        password = "Password1"
        super(IntacctSSOTests, self).begin(environment_flag, browser_flag)

        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify that you load into OsC
        self.assertTrue(FinancialsPage.is_at_dashboard(),
                        "External OsC user login")

    def tearDown(self):
        """ Closes the browser """
        super(IntacctSSOTests, self).tearDown()

    def test_intacct_sso(self):
        # Navigate to an entity's financials tab
        # self.assertTrue(OsCNavigation.navigate_to_entity("United Kingdom"),
        #                 "Navigation to UK entity")
        self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name="United Kingdom"),
                        "Navigation to the UK Entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_FINANCIALS),
                        "Navigation to the Financials application")

        # Verify that you made it to nexonia
        self.assertTrue(FinancialsPage.navigate_to_intacct(),
                        "Intacct SSO")

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(IntacctSSOTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
