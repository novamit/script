import unittest
import sys
import os
from Tests.BaseTest import BaseTest
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Pages.ComplianceTrackerPages.HomePage import HomePage
from Framework.Pages.ComplianceTrackerPages.ComplianceGroupsPage import ComplianceGroupsPage
from Framework.Pages.ComplianceTrackerPages.CountryEventsPage import CountryEventsPage
from Framework.Pages.ComplianceTrackerPages.ClientEventsPage import ClientEventsPage
from Framework.Pages.ComplianceTrackerPages.ReportsPage import ReportsPage
from Framework.Pages.ComplianceTrackerPages.CalendarPage import CalendarPage
from Framework.Pages.ComplianceTrackerPages.MappingPage import MappingPage
from Framework.Pages.ComplianceTrackerPages.EntitiesPage import EntitiesPage
from Framework.Pages.ComplianceTrackerPages.MilestoneTemplatesPage import MilestoneTemplatesPage
from Framework.Pages.ComplianceTrackerPages.MyTasksPage import MyTasksPage

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class CT2BasicTest(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        super(CT2BasicTest, self).begin(environment_flag, browser_flag)

        username = "hsp\\svc_qa_jenkins"
        password = "Password0"

        LoginPage.login_as(username) \
            .with_password(password) \
            .go_to('internal', alt_user=True)

        # LoginPage.go_to("internal")
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "Internal OsC user login")

    def tearDown(self):
        """ Closes the browser """
        super(CT2BasicTest, self).tearDown()

    def test_ct_homepage(self):

        # Navigate to the Compliance Tracker home page
        HomePage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading to the Home page")

        # Navigate to the Country Events page
        HomePage.go_to_country_events()
        self.assertTrue(CountryEventsPage.is_at(),
                        "Loading to the Country Events page")

        # Navigate back to the Home page
        CountryEventsPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

        # Navigate to the Client Events page
        HomePage.go_to_client_events()
        self.assertTrue(ClientEventsPage.is_at(),
                        "Loading to the Client Events page")

        # Navigate back to the Home page
        ClientEventsPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

        # Navigate to the Reports page
        HomePage.go_to_reports()
        self.assertTrue(ReportsPage.is_at(),
                        "Loading to the Reports page")

        # Navigate back to the Home page
        ReportsPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

        # Navigate to the My Tasks page
        HomePage.go_to_my_tasks()
        self.assertTrue(MyTasksPage.is_at(),
                        "Loading to the My Tasks page")

        # Navigate back to the Home page
        MyTasksPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

        # Navigate to the Milestone Templates page
        HomePage.go_to_milestone_templates()
        self.assertTrue(MilestoneTemplatesPage.is_at(),
                        "Loading to the Milestone Templates page")

        # Navigate back to the Home page
        MilestoneTemplatesPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

        # Navigate to the Calendar page
        HomePage.go_to_calendar()
        self.assertTrue(CalendarPage.is_at(),
                        "Loading to the Calendar page")

        # Navigate back to the Home page
        CalendarPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

        # Navigate to the Mapping page
        HomePage.go_to_mapping()
        self.assertTrue(MappingPage.is_at(),
                        "Loading to the Mapping page")

        # Navigate back to the Home page
        MappingPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

        # Navigate to the Entities Page
        HomePage.go_to_entities()
        self.assertTrue(EntitiesPage.is_at(),
                        "Loading to the Entities page")

        # Navigate back to the Home page
        EntitiesPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

        # Navigate to the Compliance Groups page
        HomePage.go_to_compliance_groups()
        self.assertTrue(ComplianceGroupsPage.is_at(),
                        "Loading to the Compliance Group page")

        # Navigate back to the Home page
        ComplianceGroupsPage.go_to_homepage()
        self.assertTrue(HomePage.is_at(),
                        "Loading back to the Home page")

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(CT2BasicTest, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
