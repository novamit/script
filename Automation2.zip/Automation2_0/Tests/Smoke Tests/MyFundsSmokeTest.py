import unittest
import sys
import os
import json
from Tests.BaseTest import BaseTest
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Pages.DxpPlatformPages.LoginPage import LoginPage
from Framework.Pages.DxpPlatformPages.VistraApplicationsPage import VistraApplicationsPage
from Framework.Pages.DxpPlatformPages.MyFundsPages.LandingOverviewPage import LandingOverviewPage
from Framework.Pages.DxpPlatformPages.MyFundsPages.FundSummaryPage import FundSummaryPage
from Framework.Pages.DxpPlatformPages.MyFundsPages.SoiPage import SoiPage
from Framework.Pages.DxpPlatformPages.MyFundsPages.MyFundsFilter import MyFundsFilter
from Framework.Pages.DxpPlatformPages.MyFundsPages.MyFundsNavigation import MyFundsNavigation
from ddt import ddt

environment_flag = "prod"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


@ddt
class MyFundsSmokeTest(BaseTest):
    json = "C:\\QA\\Automation2_0\\Tests\\MyFundsTests\\Data\\Users_MyFunds.json"

    def setUp(self):
        global environment_flag
        global browser_flag
        super(MyFundsSmokeTest, self).begin(environment_flag, browser_flag)

    def test_my_funds_pages_as_admin(self):
        user_type = "admin"

        self.my_funds_login(user_type)

        # Go to Landing Overview page
        self.assertTrue(VistraApplicationsPage.navigate_to_my_funds(),
                        "Navigated to My Funds Landing Overview page")

        # Verify if at Landing Overview page
        self.assertTrue(LandingOverviewPage.is_at(),
                        "Currently at My Funds Landing Overview page")

        # Verify Fund Overview section
        self.assertTrue(LandingOverviewPage.check_fund_overview_highlights(),
                        "All highlights are visible within Fund Overview section")
        self.assertTrue(LandingOverviewPage.check_fund_overview_grid(),
                        "Grid shown correctly in Fund Overview section")
        self.assertTrue(LandingOverviewPage.check_fund_overview_more_details_link_visible(),
                        "More Details' link visible in Fund Overview")

        # Verify SOI Overview section
        self.assertTrue(LandingOverviewPage.check_soi_overview_graphs_visible(),
                        "All graphs are visible within SOI Overview")
        self.assertTrue(LandingOverviewPage.check_soi_overview_grid(),
                        "Grid shown correctly in SOI Overview")
        self.assertTrue(LandingOverviewPage.check_soi_overview_more_details_link_visible(),
                        "More Details' link visible in SOI Overview")

        # Go to Fund Summary page
        self.assertTrue(LandingOverviewPage.navigate_to_fund_summary(),
                        "Navigated to Fund Summary page")

        # Check if filter is visible within Fund Summary
        self.assertTrue(MyFundsFilter.check_fund_summary_filter(user=user_type),
                        "Filter is shown in Fund Summary page")

        # Check if left graph, middle component and right graph are visible within Fund Summary
        self.assertTrue(FundSummaryPage.check_fund_summary_graphs(),
                        "Left graph, middle component and right graph are visible within Fund Summary")

        # Check if grid is visible within Fund Summary
        self.assertTrue(FundSummaryPage.check_fund_summary_grid(),
                        "Grid shown correctly in Fund Summary page")

        # Go to Fund Summary Investor page
        self.assertTrue(FundSummaryPage.navigate_to_fund_summary_investor(),
                        "Navigated to Fund Summary Investor page")

        # check if filter is visible within Fund Summary Investor
        self.assertTrue(MyFundsFilter.check_fund_summary_investor_filter(),
                        "Filter is shown in Fund Summary Investor page")

        # Check if left graph, middle component and right graph are visible within Fund Summary Investor
        self.assertTrue(FundSummaryPage.check_fund_summary_investor_graphs_visible(),
                        "Left graph, middle component and right graph are visible within Fund Summary Investor")

        # Check if grid is visible within Fund Summary Investor
        self.assertTrue(FundSummaryPage.check_fund_summary_investor_grid(),
                        "Grid shown correctly in Fund Summary Investor page")

        # Go to Fund Drilldown page
        self.assertTrue(FundSummaryPage.navigate_to_fund_drilldown(user=user_type),
                        "Navigated to Fund Drilldown page")

        # check if filter is visible within Fund Drilldown
        self.assertTrue(MyFundsFilter.check_fund_drilldown_filter(user=user_type),
                        "Filter is shown in Fund Drilldown page")

        # Check if left graph, middle component and right graph are visible within Fund Drilldown
        self.assertTrue(FundSummaryPage.check_fund_drilldown_graphs_visible(),
                        "Left graph, middle component and right graph are visible within Fund Drilldown")

        # Check if grid is visible within Fund Drilldown
        self.assertTrue(FundSummaryPage.check_fund_drilldown_grid(),
                        "Grid is shown correctly in Fund Drilldown page")

        # Navigate to SOI page
        self.assertTrue(FundSummaryPage.navigate_to_schedule_of_investments(from_page="fund drilldown"),
                        "Navigated to SOI page")

        # check if filter is visible within SOI
        self.assertTrue(MyFundsFilter.check_soi_filter(),
                        "Filter is shown in SOI page")

        # Check if left graph, middle component and right graph are visible within SOI
        self.assertTrue(SoiPage.check_soi_graphs_visible(),
                        "Left graph, middle component and right graph are visible within SOI page")

        # Check if grid is visible within SOI
        self.assertTrue(SoiPage.check_soi_grid_visible(),
                        "Grid is shown correctly in SOI page")

        # Navigate to SOI Drilldown
        self.assertTrue(SoiPage.navigate_to_soi_drilldown(),
                        "Navigated to SOI Drilldown page")

        # check if filter is visible within SOI Drilldown
        self.assertTrue(MyFundsFilter.check_soi_drilldown_filter(),
                        "Filter is shown in SOI Drilldown page")

        # Check if left graph, middle component and right graph are visible within SOI
        self.assertTrue(SoiPage.check_soi_drilldown_graphs_visible(),
                        "Left graph, middle component and right graph are visible within SOI Drilldown page")

        # Check if grid is visible within SOI Drilldown
        self.assertTrue(SoiPage.check_soi_drilldown_grid_visible(),
                        "Grid is shown correctly in SOI Drilldown page")

        # Sign out from My Funds
        self.assertTrue(MyFundsNavigation.sign_out(),
                        "Logged out from My Funds")

    def test_my_funds_pages_as_multi_investor(self):
        user_type = "multiinvestor"

        self.my_funds_login(user_type)

        # Go to Landing Overview page
        self.assertTrue(VistraApplicationsPage.navigate_to_my_funds(),
                        "Navigated to My Funds Landing Overview page")

        # Verify if at Landing Overview page
        self.assertTrue(LandingOverviewPage.is_at(),
                        "Currently at My Funds Landing Overview page")

        # Verify Fund Overview section
        self.assertTrue(LandingOverviewPage.check_fund_overview_highlights(),
                        "All highlights are visible within Fund Overview section")
        self.assertTrue(LandingOverviewPage.check_fund_overview_grid(),
                        "Grid shown correctly in Fund Overview section")
        self.assertTrue(LandingOverviewPage.check_fund_overview_more_details_link_visible(),
                        "More Details' link visible in Fund Overview")

        # Verify SOI Overview section
        self.assertTrue(LandingOverviewPage.check_soi_overview_graphs_visible(),
                        "All graphs are visible within SOI Overview")
        self.assertTrue(LandingOverviewPage.check_soi_overview_grid(),
                        "Grid shown correctly in SOI Overview")
        self.assertTrue(LandingOverviewPage.check_soi_overview_more_details_link_visible(),
                        "More Details' link visible in SOI Overview")

        # Go to Fund Summary page
        self.assertTrue(LandingOverviewPage.navigate_to_fund_summary(),
                        "Navigated to Fund Summary page")

        # Check if filter is visible within Fund Summary
        self.assertTrue(MyFundsFilter.check_fund_summary_filter(user=user_type),
                        "Filter is shown in Fund Summary page")

        # Check if left graph, middle component and right graph are visible within Fund Summary
        self.assertTrue(FundSummaryPage.check_fund_summary_graphs(),
                        "Left graph, middle component and right graph are visible within Fund Summary")

        # Check if grid is visible within Fund Summary
        self.assertTrue(FundSummaryPage.check_fund_summary_grid(),
                        "Grid shown correctly in Fund Summary page")

        # Go to Fund Summary Investor page
        self.assertTrue(FundSummaryPage.navigate_to_fund_summary_investor(),
                        "Navigated to Fund Summary Investor page")

        # check if filter is visible within Fund Summary Investor
        self.assertTrue(MyFundsFilter.check_fund_summary_investor_filter(),
                        "Filter is shown in Fund Summary Investor page")

        # Check if left graph, middle component and right graph are visible within Fund Summary Investor
        self.assertTrue(FundSummaryPage.check_fund_summary_investor_graphs_visible(),
                        "Left graph, middle component and right graph are visible within Fund Summary Investor")

        # Check if grid is visible within Fund Summary Investor
        self.assertTrue(FundSummaryPage.check_fund_summary_investor_grid(),
                        "Grid shown correctly in Fund Summary Investor page")

        # Go to Fund Drilldown page
        self.assertTrue(FundSummaryPage.navigate_to_fund_drilldown(user=user_type),
                        "Navigated to Fund Drilldown page")

        # check if filter is visible within Fund Drilldown
        self.assertTrue(MyFundsFilter.check_fund_drilldown_filter(user=user_type),
                        "Filter is shown in Fund Drilldown page")

        # Check if left graph, middle component and right graph are visible within Fund Drilldown
        self.assertTrue(FundSummaryPage.check_fund_drilldown_graphs_visible(),
                        "Left graph, middle component and right graph are visible within Fund Drilldown")

        # Check if grid is visible within Fund Drilldown
        self.assertTrue(FundSummaryPage.check_fund_drilldown_grid(),
                        "Grid is shown correctly in Fund Drilldown page")

        # Navigate to SOI page
        self.assertTrue(FundSummaryPage.navigate_to_schedule_of_investments(from_page="fund drilldown"),
                        "Navigated to SOI page")

        # check if filter is visible within SOI
        self.assertTrue(MyFundsFilter.check_soi_filter(),
                        "Filter is shown in SOI page")

        # Check if left graph, middle component and right graph are visible within SOI
        self.assertTrue(SoiPage.check_soi_graphs_visible(),
                        "Left graph, middle component and right graph are visible within SOI page")

        # Check if grid is visible within SOI
        self.assertTrue(SoiPage.check_soi_grid_visible(),
                        "Grid is shown correctly in SOI page")

        # Navigate to SOI Drilldown
        self.assertTrue(SoiPage.navigate_to_soi_drilldown(),
                        "Navigated to SOI Drilldown page")

        # check if filter is visible within SOI Drilldown
        self.assertTrue(MyFundsFilter.check_soi_drilldown_filter(),
                        "Filter is shown in SOI Drilldown page")

        # Check if left graph, middle component and right graph are visible within SOI
        self.assertTrue(SoiPage.check_soi_drilldown_graphs_visible(),
                        "Left graph, middle component and right graph are visible within SOI Drilldown page")

        # Check if grid is visible within SOI Drilldown
        self.assertTrue(SoiPage.check_soi_drilldown_grid_visible(),
                        "Grid is shown correctly in SOI Drilldown page")

        # Sign out from My Funds
        self.assertTrue(MyFundsNavigation.sign_out(),
                        "Logged out from My Funds")

    @staticmethod
    def get_user_details(value, user_type):

        if environment_flag == 'prod':
            user_details = value["Test"]["Prod_Users"][user_type]
        else:
            user_details = value["Test"]["QA_Users"][user_type]

        return user_details

    def my_funds_login(self, user_type):

        with open(self.json) as data:
            value = json.load(data)

        user_details = self.get_user_details(value, user_type)

        username = user_details["username"]
        password = user_details["password"]
        environment = environment_flag

        # Navigate to the My Funds login page
        self.assertTrue(LoginPage.go_to(),
                        "Navigated to the My Funds Login page")

        # Login to My Funds
        self.assertTrue(LoginPage.login(username=username, password=password, environment=environment),
                        "Logged in as Fund Manager user")

        # Enter 2FA code
        self.assertTrue(LoginPage.enter_2fa_code(environment=environment, username=username),
                        "Entered 2FA code successfully")

        # Verify if at application page
        self.assertTrue(VistraApplicationsPage.is_at(),
                        "Navigated to Vistra Applications page")

    def tearDown(self):
        """ Closes the browser """
        super(MyFundsSmokeTest, self).tearDown()


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(MyFundsSmokeTest, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
