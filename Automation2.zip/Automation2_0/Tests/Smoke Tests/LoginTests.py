import unittest
import sys
import os
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Framework.Pages.EssPages.EssPage import EssPage
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Tests.BaseTest import BaseTest

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class LoginTests(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        super(LoginTests, self).begin(environment_flag, browser_flag)

    def tearDown(self):
        """ Closes the browser """
        super(LoginTests, self).tearDown()

    def test_external_user_login_osc(self):
        username = "automationadmin"
        password = "Password0"

        # Navigate to the external Login page
        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "External OsC user login")

    def test_internal_user_login(self):

        # Navigate to the internal Login
        LoginPage.go_to("internal")

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "Internal OsC user login")

    def test_external_user_login_ess(self):
        username = "test-withpayr@test.com"
        password = "Password1"

        # Navigate to the external Login page
        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify that you load into OsC
        self.assertTrue(EssPage.is_at(),
                        "External ESS user login")


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(LoginTests, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
