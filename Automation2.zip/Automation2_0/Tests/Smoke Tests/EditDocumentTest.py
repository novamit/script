import unittest
import sys
import os
from Framework.Utilities.Driver import Driver
import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Framework.Pages.LoginPage import LoginPage
from Framework.Pages.OsCPages.OsCDashboardPage import OsCDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation

environment_flag = "stg"
browser_flag = "chrome"
workspace = "C:\\temp_automation_downloads"


class EditDocumentTest(BaseTest):

    def setUp(self):
        global environment_flag
        global browser_flag
        super(EditDocumentTest, self).begin(environment_flag, browser_flag)

    def tearDown(self):
        """ Closes the browser """
        super(EditDocumentTest, self).tearDown()

    def test_some_test(self):
        username = "automationadmin"
        password = "Password0"

        # Sign in to OsC
        LoginPage.go_to()
        LoginPage.login(username=username, password=password)

        # Verify that you load into OsC
        self.assertTrue(OsCDashboardPage.is_at_dashboard(),
                        "External OsC user login")

        # TODO: Navigate to some country entity tab

        # TODO: Navigate to some application tab

        # TODO: Upload a file for this entity and application

        # TODO: Search for the file after upload to verify that it was successful

        # TODO: Click the file's edit icon

        # TODO: Change the country and application. Save.

        # TODO: Navigate to the new country entity tab

        # TODO: Navigate to the new application tab

        # TODO: Search for the file to verify that the edit was successful the file is in the correct location

        # TODO: Delete the file


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    suite.addTest(BaseTest.parametrize(EditDocumentTest, environment_flag, browser_flag, workspace))
    t = runner.run(suite)

    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
