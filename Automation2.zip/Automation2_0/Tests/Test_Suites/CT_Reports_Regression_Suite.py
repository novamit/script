import unittest
import os
import sys
sys.path.append(os.getcwd())

import Framework.Utilities.HTMLTestRunner as HTMLTestRunner
from Tests.BaseTest import BaseTest
from Tests.SFTests.VerifyingInternalReferralSourceError import Create_Account1
from Tests.SFTests.CreateAccountAffiliate import Create_Account2
folder=os.getcwd()+"\\Screenshots"
folder1=os.getcwd()
def delete_screenshot(folder):
    test = os.listdir(folder)
    for images in test:
        if images.endswith(".png"):
            os.remove(os.path.join(folder, images))
delete_screenshot(folder)

environment_flag = "stg"
browser_flag = "chrome"
workspace = os.getcwd()+"\\Screenshots"

# ---------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':

    i = 0
    for arg in sys.argv:
        if "-env=" in arg:
            environment_flag = arg[5:]
            sys.argv.remove(arg)
            break
        i += 1
    i = 0
    for arg in sys.argv:
        if "-browser=" in arg:
            browser_flag = arg[9:]
            sys.argv.remove(arg)
            break
        i += 1
    for arg in sys.argv:
        if "-ws=" in arg:
            workspace = arg[4:]
            sys.argv.remove(arg)
            break
        i += 1

    name = os.path.basename(__file__).split(".")[0]
    file_name = str(name) + "_RESULTS.html"
    workspace = workspace.replace('"', '')
    report_location = workspace + "\\" + file_name
    fp = open(report_location, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title=str(name) + ' Tests',
        description='This is the result of the ' + str(name) + ' tests.'
    )

    suite = unittest.TestSuite()
    #suite.addTest(BaseTest.parametrize(Create_Account2,environment_flag, browser_flag, workspace))
    suite.addTest(BaseTest.parametrize(Create_Account1, environment_flag, browser_flag, workspace))

    # suite.addTest(BaseTest.parametrize(ReportUiVerification, environment_flag, browser_flag, workspace))

    t = runner.run(suite)
    delete_screenshot(folder1)
    if not t.wasSuccessful():
        raise AssertionError("\nFAIL")
