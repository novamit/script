import time
from Tests.BaseTest import BaseTest
from Framework.Utilities.Driver import Driver
from Framework.Pages.PatPages.PatPage import PatPage
from Framework.Pages.PatPages.SelectEntityPage import SelectEntityPage
from Framework.Pages.PatPages.DataFieldsPage import DataFieldsPage
from Framework.Pages.PatPages.UsagesPage import UsagesPage
from Framework.Pages.PatPages.CalendarPage import CalendarPage
from Framework.Pages.OsCPages.OsCPayrollPage import OsCPayrollPage
from Framework.Pages.OsCPages.OsCHrPage import OsCHrPage
from Framework.Pages.NextgenPages.NextgenHrPage import NextgenHrPage
from Framework.Pages.NextgenPages.NextgenPayrollPage import NextgenPayrollPage
from Framework.Pages.NextgenPages.AffiliateDashboardPage import AffiliateDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Navigation.NextgenNavigation import NextgenNavigation
from Framework.Utilities.PayrollCalendarManager import PayrollCalendarManager
from Framework.Pages.LoginPage import LoginPage


class EmployeeCreationTestHelper(BaseTest):

    def __init__(self, env, browser, ws, parent, method_name='runTest'):
        super(EmployeeCreationTestHelper, self).__init__(method_name=method_name, env=env, browser=browser)
        self.parent_test = parent
        self.ws = ws
        # self.pt_helper = pt_helper

    def employee_creation(self, value):
        entity_data = value["Entity_Data"]
        employee_info = value["Employee_Info"]

        # Navigate to Nextgen Hr
        self.hr_navigation(entity_data)

        # Create employee
        print("\nINFO: ----------Starting Employee Creation-----------")
        self.create_employee(employee_info)

    def hr_navigation(self, entity_data, internal=True):
        # Navigate to OsC entity HR tab
        Driver.hard_wait(2)
        if internal:
            self.assertTrue(
                OsCNavigation.new_tb_change_client_location(entity_data["Company_Name"], entity_data["Country"]),
                "Navigation to client entity")
        else:
            self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name=entity_data["Country"]),
                            "Navigation to entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_HR),
                        "Navigation to Hr")

        # Navigate to Nextgen Hr entity and payroll definition tab
        self.assertTrue(OsCHrPage.navigate_to_nextgen_hr(),
                        "Hr application navigation")
        nav_result = NextgenNavigation.new_tb_change_client_location(location_name=entity_data["Country"],
                                                                     payroll_definition=entity_data["Payroll_Definition"])
        self.assertTrue(nav_result,
                        "Navigation to " + entity_data["Country"] + " " + entity_data["Payroll_Definition"])

    def create_employee(self, employee_info):

        # Add a new employee based on the info from json file
        add_result = NextgenHrPage.with_employee_info(employee_info)\
            .add_employee()
        self.assertTrue(add_result,
                        "Adding employee")
        # self.assertTrue(NextgenHrPage.wait_for_shi_complete_employee(), "Shi workflow complete")
        # Verify that the newly added employee is returned in the search
        search_result = NextgenHrPage.employee_search(first_name=employee_info["Personal"]["First Name"],
                                                      last_name=employee_info["Personal"]["Last Name"],
                                                      status_filter=NextgenHrPage.Filter.ALL_EMPLOYEES)
        self.assertIsNotNone(search_result,
                             "Employee search")

        result = NextgenHrPage.with_employee_info(employee_info) \
            .wait_for_employee_active()
        self.assertTrue(result,
                        "Employee active status (Limit: 50 minutes)")
