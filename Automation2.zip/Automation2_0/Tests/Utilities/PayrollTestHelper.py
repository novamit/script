import time
from Tests.BaseTest import BaseTest
from Framework.Utilities.Driver import Driver
from Framework.Pages.PatPages.PatPage import PatPage
from Framework.Pages.PatPages.SelectEntityPage import SelectEntityPage
from Framework.Pages.PatPages.DataFieldsPage import DataFieldsPage
from Framework.Pages.PatPages.UsagesPage import UsagesPage
from Framework.Pages.PatPages.CalendarPage import CalendarPage
from Framework.Pages.OsCPages.OsCPayrollPage import OsCPayrollPage
from Framework.Pages.OsCPages.OsCHrPage import OsCHrPage
from Framework.Pages.NextgenPages.NextgenHrPage import NextgenHrPage
from Framework.Pages.NextgenPages.NextgenPayrollPage import NextgenPayrollPage
from Framework.Pages.NextgenPages.AffiliateDashboardPage import AffiliateDashboardPage
from Framework.Navigation.OsCNavigation import OsCNavigation
from Framework.Navigation.NextgenNavigation import NextgenNavigation
from Framework.Utilities.PayrollCalendarManager import PayrollCalendarManager


class PayrollTestHelper(BaseTest):

    def __init__(self, env, browser, ws, parent_test, method_name='runTest'):
        super(PayrollTestHelper, self).__init__(method_name=method_name, env=env, browser=browser)
        self.parent_test = parent_test
        self.ws = ws

    def payroll_navigation(self, entity_data, internal=True):
        self.payroll_calendar = PayrollCalendarManager(entity_data["Calendar"])

        if internal:
            # self.assertTrue(OsCNavigation.change_client(entity_data["Company_Name"]),
            #                 "Navigation to client %s" % entity_data["Company_Name"])
            self.assertTrue(
                OsCNavigation.new_tb_change_client_location(entity_data["Company_Name"], entity_data["Country"]),
                "Navigation to client entity")
        # self.assertTrue(OsCNavigation.navigate_to_entity(entity_data["Country"]),
        #                 "Navigation to country %s" % entity_data["Country"])
        # self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name=entity_data["Country"]),
        #                 "Navigation to entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_PAYROLL),
                        "Navigation to payroll tab")

        self.assertTrue(OsCPayrollPage.navigate_to_nextgen_payroll(),
                        "Navigation to payroll application")
        # nav_result = NextgenNavigation.navigate(entity=entity_data["Country"],
        #                                         payroll_definition=entity_data["Payroll_Definition"],
        #                                         page="Payroll")
        nav_result = NextgenNavigation.new_tb_change_client_location(location_name=entity_data["Country"],
                                                                     payroll_definition=entity_data["Payroll_Definition"])
        self.assertTrue(nav_result,
                        "Navigation to " + entity_data["Country"] + " " + entity_data["Payroll_Definition"])

    def configure_client_entity(self, value):
        entity_data = value["Entity_Data"]
        affiliate_data = value["Affiliate_Data"]
        full_title = entity_data["Name"] + " : " + entity_data["Payroll_Definition"]

        # Make sure we're on the client-entity tab and create a new payroll definition
        self.assertTrue(PatPage.navigate_to_tab(PatPage.Tabs.CLIENT_ENTITY_CONFIGURATION),
                        "Navigation to Client Entity section")

        self.assertTrue(SelectEntityPage.create_payroll_definition(entity=entity_data["Name"],
                                                                   payroll_definition=entity_data["Payroll_Definition"],
                                                                   affiliate=affiliate_data["Name"],
                                                                   payroll_type=entity_data["Payroll_Type"]),
                        "Entity selection and definition creation")

        self.assertTrue(SelectEntityPage.save(),
                        "Select entity section save")

        # 2. Verify data field title
        self.assertTrue(DataFieldsPage.return_title_text() == full_title,
                        "Data Fields affiliate name")

        # 3. Save data fields section
        self.assertTrue(DataFieldsPage.save(),
                        "Data field section save")

        # 4. Verify usage title
        self.assertTrue(UsagesPage.return_title_text() == full_title,
                        "Usages affiliate name")

        # 5. Configure usages
        self.assertTrue(UsagesPage.configure_usages(entity_data["Usages"]),
                        "Usage configuration")

        # 6. Save usages section
        self.assertTrue(UsagesPage.save(),
                        "Usages section save")

        # 9 Verify Calendar title
        self.assertTrue(CalendarPage.return_title_text() == full_title,
                        "Calendar affiliate name")

        # 9 Configure and complete setup
        self.assertTrue(CalendarPage.configure_calendar(entity_data["Calendar"]),
                        "Calendar section save")

    def hr_navigation(self, entity_data, internal=True):
        # Navigate to OsC entity HR tab
        Driver.hard_wait(2)
        if internal:
            self.assertTrue(
                OsCNavigation.new_tb_change_client_location(entity_data["Company_Name"], entity_data["Country"]),
                "Navigation to client entity")
        else:
            self.assertTrue(OsCNavigation.new_tb_change_client_location(location_name=entity_data["Country"]),
                            "Navigation to entity")
        self.assertTrue(OsCNavigation.navigate_to_application(OsCNavigation.APP_HR),
                        "Navigation to Hr")

        # Navigate to Nextgen Hr entity and payroll definition tab
        self.assertTrue(OsCHrPage.navigate_to_nextgen_hr(),
                        "Hr application navigation")
        nav_result = NextgenNavigation.new_tb_change_client_location(location_name=entity_data["Country"],
                                                                     payroll_definition=entity_data["Payroll_Definition"])
        self.assertTrue(nav_result,
                        "Navigation to " + entity_data["Country"] + " " + entity_data["Payroll_Definition"])

    def create_employee(self, employee_info):

        # Add a new employee based on the info from json file
        add_result = NextgenHrPage.with_employee_info(employee_info)\
            .add_employee()
        self.assertTrue(add_result,
                        "Adding employee")
        # self.assertTrue()
        # Verify that the newly added employee is returned in the search
        search_result = NextgenHrPage.employee_search(first_name=employee_info["Personal"]["First Name"],
                                                      last_name=employee_info["Personal"]["Last Name"],
                                                      status_filter=NextgenHrPage.Filter.ALL_EMPLOYEES)
        self.assertIsNotNone(search_result,
                             "Employee search")
        self.assertTrue(NextgenHrPage.with_employee_info(employee_info).wait_for_employee_active(),
                        "Employee active status (Limit: 50 minutes)")

    def payroll_submit(self, value, period):
        entity_data = value["Entity_Data"]
        self.payroll_calendar = PayrollCalendarManager(entity_data["Calendar"])
        current_period = self.payroll_calendar.return_period(period)

        self.assertTrue(NextgenPayrollPage.is_step_open("Submit"),
                        "Arrival at Submit workflow step")

        # Verify title, status, open, due, late warning, fields not editable
        payroll_title = entity_data["Country"] + " - " + entity_data["Payroll_Definition"] + ": Period " +\
            current_period[0] + " - " + current_period[10]

        self.assertTrue(NextgenPayrollPage.return_title_text() == payroll_title,
                        "Payroll title")

        # Verify displayed submission dates
        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.SUBMISSION_STATUS)
        self.assertTrue(time.strftime("%m/%d/%Y") in temp,
                        "Submit Status date")

        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.SUBMISSION_OPEN)
        self.assertTrue(temp == current_period[0],
                        "Submit Open date")

        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.SUBMISSION_DUE)
        self.assertTrue(temp == current_period[1],
                        "Submit Due date")

        result = NextgenPayrollPage.verify_column_names(entity_data["Usages"]["OsC Payroll Interface"])
        self.assertTrue(result,
                        "Columns matching what was set in the usages section")

        # Enter values into fields and Submit
        data_field = value["Affiliate_Data"]["Data_Fields"]["Field1"]["Field_Name"]
        edit_result = NextgenPayrollPage.edit_cell(search_column="Employee Id",
                                                   search_value=value["Employee_Info"]["Personal"]["Employee Id"],
                                                   edit_column=data_field,
                                                   edit_value='123.22')
        self.assertTrue(edit_result, "Editing the desired cell")
        Driver.hard_wait(3)

        self.assertTrue(NextgenPayrollPage.submit_payroll(),
                        "Payroll submission")

    def affiliate_actions(self, value, period, delta=True, file_type="csv"):
        # Test Case 2: Affiliate Dashboard: Overview and Submit a payroll
        entity_data = value["Entity_Data"]
        self.payroll_calendar = PayrollCalendarManager(entity_data["Calendar"])

        file_upload_path = "C:\\QA\\Upload_Test_Files\\doc_file.doc"
        file_upload_name = "doc_file.doc"
        current_period = self.payroll_calendar.return_period(period)
        entity_data = value["Entity_Data"]
        affiliate_data = value["Affiliate_Data"]
        emp_id = value["Employee_Info"]["Personal"]["Employee Id"]

        affiliate_period = entity_data["Payroll_Definition"] + "-" + current_period[0] + "-" + current_period[10]

        # Steps 1 - 8
        select_result = AffiliateDashboardPage.select_payroll(affiliate=affiliate_data["Name"],
                                                              client_entity=entity_data["Name"],
                                                              payroll_definition=affiliate_period)

        self.assertTrue(select_result,
                        "Selecting affiliate, client, and payroll")

        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to the process payroll section")

        AffiliateDashboardPage.close_g2n_modal()

        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.FILE_HISTORY),
                        "Navigation to the file history section")

        AffiliateDashboardPage.close_g2n_modal()

        # Verify Title
        affiliate_client = entity_data["Name"] + ": "


        # Step 10 - 12
        # Verify all payroll documents were created
        self.assertTrue(AffiliateDashboardPage.verify_payroll_documents(affiliate_period, delta=delta),
                        "Verifying creation of all payroll documents")

        # Step 13 - 15
        # Verify payroll calendar
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to process payroll section")
        result = AffiliateDashboardPage.verify_payroll_calendar(current_period)
        self.assertTrue(result,
                        "Payroll Calendar values")

        # # Verify columns
        # result = NextgenPayrollPage.verify_column_names(entity_data["Usages"]["LSP Dashboard"])
        # self.assertTrue(result,
        #                 "\nFAIL: Columns don't match what was set in the usages section")
        # print("\nPASS: Columns match what was set in the usages section")

        # Step 16 - 20
        self.assertTrue(AffiliateDashboardPage.verify_g2n_template_download(file_type=file_type),
                        "Download of " + file_type + " g2n template")

        # Step 21 - 23
        # Select G2N template
        # Click Import and verify tostr response
        if file_type == "csv":
            result = AffiliateDashboardPage.import_g2n_template(affiliate_data["G2N_Template"]["File"])
            self.assertTrue(result,
                            "CSV G2N file import")
        else:
            result = AffiliateDashboardPage.import_g2n_template(affiliate_data["G2N_Template"]["Excel_File"])
            self.assertTrue(result,
                            "Excel G2N file import")

        # Step 24 - 28
        # Open Payroll related files modal and upload file
        self.assertTrue(AffiliateDashboardPage.upload_file(file_upload_path),
                        "Document upload")

        # Step 29
        # Verify file upload in File History
        result = AffiliateDashboardPage.verify_uploaded_document(affiliate=affiliate_data["Name"],
                                                                 doc_name=file_upload_name,
                                                                 payroll_period=affiliate_period)
        self.assertTrue(result,
                        "Presence of uploaded file with the correct values in file history")

        # Step 30
        # Verify G2N data in Process Payroll
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to process payroll tab")

        if not AffiliateDashboardPage.is_at_process_payroll():
            Driver.hard_wait(1)
            self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                            "Navigation to process payroll tab")

        Driver.hard_wait(2)
        keys = affiliate_data["G2N_Template"]["Fields"].keys()
        for key in keys:
            cell_value = AffiliateDashboardPage.get_cell_value(search_column="Employee Id",
                                                               search_value=emp_id,
                                                               cell_column=key)

            self.assertTrue(affiliate_data["G2N_Template"]["Fields"][key] in cell_value,
                            "Veification of field value with the value from the G2N file")
            self.assertTrue(AffiliateDashboardPage.verify_column_total(key),
                            "Total verification for " + key)

        # Step 31
        # Enter a value in spreadsheet cell
        # Enter values into fields and Submit
        # data_field = value["Affiliate_Data"]["Data_Fields"]["Field3"]["Field_Name"]
        # edit_result = AffiliateDashboardPage.edit_cell(search_column="Employee Id",
        #                                                search_value=emp_id,
        #                                                edit_column=data_field,
        #                                                edit_value='223.22')
        # self.assertTrue(edit_result,
        #                 "Editing the desired cell")
        Driver.hard_wait(3)

        # Step 32 - 33
        # Submit and verify tostr
        self.assertTrue(AffiliateDashboardPage.submit_payroll(),
                        "Payroll submission")

        # Step 34
        # Verify File History again
        # Verify all payroll documents were created
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.FILE_HISTORY),
                        "Navigation to file history section")
        self.assertTrue(AffiliateDashboardPage.verify_payroll_documents(affiliate_period, delta=delta),
                        "Verification of all payroll documents")

        # Verify file upload in File History
        result = AffiliateDashboardPage.verify_uploaded_document(affiliate=affiliate_data["Name"],
                                                                 doc_name=file_upload_name,
                                                                 payroll_period=affiliate_period)
        self.assertTrue(result,
                        "Presence of uploaded file with the correct values in file history")

        # Step 35
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to process payroll section")

        # Verify G2N data in Process Payroll
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to process payroll section")

        keys = affiliate_data["G2N_Template"]["Fields"].keys()
        for key in keys:
            cell_value = AffiliateDashboardPage.get_cell_value(search_column="Employee Id",
                                                               search_value=emp_id,
                                                               cell_column=key)

            self.assertTrue(affiliate_data["G2N_Template"]["Fields"][key] in cell_value,
                            "Verification of Field value matching the value from the G2N file")
            self.assertTrue(AffiliateDashboardPage.verify_column_total(key),
                            "Verification of total for " + key)

    def new_ode_affiliate_actions(self, value, period, delta=True, file_type="csv"):
        # Test Case 2: Affiliate Dashboard: Overview and Submit a payroll
        entity_data = value["Entity_Data"]
        self.payroll_calendar = PayrollCalendarManager(entity_data["Calendar"])

        file_upload_path = "C:\\QA\\Upload_Test_Files\\doc_file.doc"
        file_upload_name = "doc_file.doc"
        current_period = self.payroll_calendar.return_period(period)
        entity_data = value["Entity_Data"]
        affiliate_data = value["Affiliate_Data"]
        emp_data = value["Employee_Info"]

        # Steps 1 - 8
        select_result = AffiliateDashboardPage.select_payroll(affiliate=affiliate_data["Name"],
                                                              client_entity=entity_data["Name"],
                                                              payroll_definition=entity_data["Payroll_Definition"])

        self.assertTrue(select_result,
                        "Selecting affiliate, client, and payroll")

        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to the process payroll section")

        AffiliateDashboardPage.close_g2n_modal()

        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.FILE_HISTORY),
                        "Navigation to the file history section")

        AffiliateDashboardPage.close_g2n_modal()

        # Verify Title
        affiliate_client = entity_data["Name"] + ": "
        affiliate_period = entity_data["Payroll_Definition"] + "-" + current_period[0] + "-" + current_period[10]

        # Step 10 - 12
        # Verify all payroll documents were created
        self.assertTrue(AffiliateDashboardPage.verify_payroll_documents(affiliate_period, delta=delta),
                        "Verifying creation of all payroll documents")

        # Step 13 - 15
        # Verify payroll calendar
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to process payroll section")
        result = AffiliateDashboardPage.verify_payroll_calendar(current_period)
        self.assertTrue(result,
                        "Payroll Calendar values")

        # # Verify columns
        # result = NextgenPayrollPage.verify_column_names(entity_data["Usages"]["LSP Dashboard"])
        # self.assertTrue(result,
        #                 "\nFAIL: Columns don't match what was set in the usages section")
        # print("\nPASS: Columns match what was set in the usages section")

        # Step 16 - 20
        self.assertTrue(AffiliateDashboardPage.verify_g2n_template_download(file_type=file_type, delete_flag=True),
                        "Download of " + file_type + " g2n template")

        # Step 21 - 23
        # Select G2N template
        # Click Import and verify tostr response
        if file_type == "csv":
            result = AffiliateDashboardPage.import_g2n_template(affiliate_data["G2N_Template"]["File"])
            self.assertTrue(result,
                            "CSV G2N file import")
        else:
            # facing issue here
            result = AffiliateDashboardPage.import_g2n_template(affiliate_data["G2N_Template"]["Excel_File"])
            self.assertTrue(result,
                            "Excel G2N file import")

        # Step 24 - 28
        # Open Payroll related files modal and upload file
        self.assertTrue(AffiliateDashboardPage.upload_file(file_upload_path),
                        "Document upload")

        # Step 29
        # Verify file upload in File History
        result = AffiliateDashboardPage.verify_uploaded_document(affiliate=affiliate_data["Name"],
                                                                 doc_name=file_upload_name,
                                                                 payroll_period=affiliate_period)
        self.assertTrue(result,
                        "Presence of uploaded file with the correct values in file history")

        # Step 30
        # Verify G2N data in Process Payroll
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to process payroll tab")

        if not AffiliateDashboardPage.is_at_process_payroll():
            Driver.hard_wait(1)
            self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                            "Navigation to process payroll tab")

        Driver.hard_wait(2)
        keys = affiliate_data["G2N_Template"]["Fields"].keys()
        for each_emp in emp_data:
            emp_id = each_emp["Personal"]["Employee Id"]
            for key in keys:
                cell_value = AffiliateDashboardPage.get_cell_value(search_column="Employee Id",
                                                                   search_value=emp_id,
                                                                   cell_column=key)

                self.assertTrue(affiliate_data["G2N_Template"]["Fields"][key] in cell_value,
                                "Veification of field value with the value from the G2N file")
                self.assertTrue(AffiliateDashboardPage.verify_column_total(key),
                                "Total verification for " + key)

        # Step 31
        # Enter a value in spreadsheet cell
        # Enter values into fields and Submit
        data_field = value["Affiliate_Data"]["Data_Fields"]["Field3"]["Field_Name"]
        for each_emp in emp_data:
            emp_id = each_emp["Personal"]["Employee Id"]
            edit_result = AffiliateDashboardPage.edit_cell(search_column="Employee Id",
                                                           search_value=emp_id,
                                                           edit_column=data_field,
                                                           edit_value='223.22')
            self.assertTrue(edit_result,
                            "Editing the desired cell")
        Driver.hard_wait(3)

        # Step 32 - 33
        # Submit and verify tostr
        self.assertTrue(AffiliateDashboardPage.submit_payroll(),
                        "Payroll submission")

        # Step 34
        # Verify File History again
        # Verify all payroll documents were created
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.FILE_HISTORY),
                        "Navigation to file history section")
        self.assertTrue(AffiliateDashboardPage.verify_payroll_documents(affiliate_period, delta=delta),
                        "Verification of all payroll documents")

        # Verify file upload in File History
        result = AffiliateDashboardPage.verify_uploaded_document(affiliate=affiliate_data["Name"],
                                                                 doc_name=file_upload_name,
                                                                 payroll_period=affiliate_period)
        self.assertTrue(result,
                        "Presence of uploaded file with the correct values in file history")

        # Step 35
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to process payroll section")

        # Verify G2N data in Process Payroll
        self.assertTrue(AffiliateDashboardPage.navigate_to_tab(AffiliateDashboardPage.Tabs.PROCESS_PAYROLL),
                        "Navigation to process payroll section")

        keys = affiliate_data["G2N_Template"]["Fields"].keys()
        for each_emp in emp_data:
            emp_id = each_emp["Personal"]["Employee Id"]
            for key in keys:
                cell_value = AffiliateDashboardPage.get_cell_value(search_column="Employee Id",
                                                                   search_value=emp_id,
                                                                   cell_column=key)

                self.assertTrue(affiliate_data["G2N_Template"]["Fields"][key] in cell_value,
                                "Verification of Field value matching the value from the G2N file")
                self.assertTrue(AffiliateDashboardPage.verify_column_total(key),
                                "Verification of total for " + key)

    def payroll_completion(self, entity_data, period, internal=True):
        self.payroll_calendar = PayrollCalendarManager(entity_data["Calendar"])
        current_period = self.payroll_calendar.return_period(period)

        if internal:
            self.assertTrue(NextgenPayrollPage.release_results(),
                            "Release results step")

        # Verify displayed approval dates
        self.assertTrue(NextgenPayrollPage.is_step_open("Approval"),
                        "Workflow moving to Approval step")

        # Verify columns
        self.assertTrue(NextgenPayrollPage.verify_column_names(entity_data["Usages"]["Gross to Net Calculation"]),
                        "Columns matching what was set in the usages section")
        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.APPROVAL_STATUS)
        self.assertTrue(time.strftime("%m/%d/%Y") in temp,
                        "Verification of Approval Status containing today's date")
        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.APPROVAL_RESULTS_DUE)
        self.assertTrue(temp == current_period[2],
                        "Results Due matching csv file")
        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.APPROVAL_APPROVAL_DUE)
        self.assertTrue(temp == current_period[3],
                        "Approval Due matching csv file")

        self.assertTrue(NextgenPayrollPage.approve_payroll(),
                        "Payroll Approval")

        # Verify displayed funding dates
        self.assertTrue(NextgenPayrollPage.is_step_open("Funding"),
                        "Payroll moving to Funding step")
        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.FUNDING_STATUS)
        self.assertTrue(time.strftime("%m/%d/%Y") in temp,
                        "Verification of Funding Status containing today's date")
        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.FUNDING_APPROVAL)
        self.assertTrue(temp == current_period[4],
                        "Funding Approval matching csv file")
        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.FUNDING_FUNDS_AVAILABLE)
        self.assertTrue(temp == current_period[4],
                        "Funds Available matching csv file")

        self.assertTrue(NextgenPayrollPage.approve_funding(),
                        "Funding approval")

        # Verify displayed complete dates
        # self.assertTrue(NextgenPayrollPage.is_step_open("Complete"),
        #                 "Workflow moving to completed step")

    def next_period(self, value, period):
        entity_data = value["Entity_Data"]
        self.payroll_calendar = PayrollCalendarManager(entity_data["Calendar"])
        next_period = self.payroll_calendar.return_period(period)

        self.assertTrue(NextgenPayrollPage.is_step_open("Submit"),
                        "Payroll arrival at submit step")

        # Verify title, status, open, due, late warning, fields not editable
        payroll_title = entity_data["Country"] + " - " + entity_data["Payroll_Definition"] + ": Period " + \
            next_period[0] + " - " + next_period[10]
        self.assertTrue(NextgenPayrollPage.return_title_text() == payroll_title,
                        "Payroll title")

        # Verify displayed submission dates
        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.SUBMISSION_STATUS)
        self.assertTrue(time.strftime("%m/%d/%Y") in temp,
                        "Verification of Submit Status containing today's date")

        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.SUBMISSION_OPEN)
        self.assertTrue(temp == next_period[0],
                        "Submit Open matching csv file")

        temp = NextgenPayrollPage.return_payroll_text(NextgenPayrollPage.SUBMISSION_DUE)
        self.assertTrue(temp == next_period[1],
                        "Submit Due matching csv file")

        self.assertTrue(NextgenPayrollPage.verify_column_names(entity_data["Usages"]["OsC Payroll Interface"]),
                        "Columns matching what was set in the usages section")

    def reopen_payroll(self, entity, payroll_definition):

        self.assertTrue(NextgenPayrollPage.reopen_payroll(),
                        "Reopen payroll")

        Driver.hard_wait(10)
        # nav_result = NextgenNavigation.navigate(entity=entity,
        #                                         payroll_definition=payroll_definition)
        nav_result = NextgenNavigation.new_tb_change_client_location(location_name=entity,
                                                                     payroll_definition=payroll_definition)
        if not nav_result:
            Driver.hard_wait(10)
            # nav_result = NextgenNavigation.navigate(entity=entity,
            #                                         payroll_definition=payroll_definition)
            nav_result = NextgenNavigation.new_tb_change_client_location(location_name=entity,
                                                                         payroll_definition=payroll_definition)
        self.assertTrue(nav_result,
                        "Navigation to " + entity + " " + payroll_definition)

        self.assertTrue(NextgenPayrollPage.is_step_open("Submit"),
                        "Reopened at submit step")
